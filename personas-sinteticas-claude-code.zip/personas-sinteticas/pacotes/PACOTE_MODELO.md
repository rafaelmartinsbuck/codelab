# PACOTE DE v0 — sessão E<N>
STATUS: INCOMPLETO

## 1. Contrato do capítulo (uma linha)

## 2. Fichas do arsenal (verbatim)

## 3. Saída real do corpus

## 4. As duas mensagens-âncora

## 5. Slot de figura (frame · legenda afirmativa · alt-text ≤140)

## 6. Último parágrafo do capítulo anterior

## 7. Linhas autorizadas do Banco de Campo (0 a 2)
