---
description: Constrói e roda o Laboratório, produzindo o corpus de saídas reais
---
Construa o Laboratório em `lab/` e rode-o de verdade. Nada de mock, nada de saída simulada.

1. Leia `docs/ESTRUTURA_7_CAPITULOS.md` (seção do Apêndice) e `docs/DECISOES_F0.md`.
2. Crie sete blocos, um por capítulo, partições de no máximo 25 linhas cada, mais `lab/plots.py`:
   1 extrair persona de conversa real · 2 gerar os cinco arquétipos · 3 spec anti-drift ·
   4 painel de cinco personas · 5 juiz de três métricas · 6 loop diagnóstico→fix→re-teste ·
   7 dashboard + gate.
3. Dependências fixadas em `lab/requirements.txt`. Usa `ANTHROPIC_API_KEY` do ambiente.
4. **Rode.** Arquive em `corpus/`: transcrições em `.md` e os sete gráficos em `.png` a 300 dpi, paleta petróleo `#0F4C5C` e cinza, sem grade pesada.
5. Grave `corpus/INDICE.md` mapeando cada saída ao capítulo que a usa.

Critério de aceitação: rodar tudo do zero, numa máquina limpa, sem erro. Se um bloco depende de saída do anterior, isso tem que estar explícito no notebook e no índice.
