---
description: Monta o Pacote de v0 de uma sessão (obrigatório antes de escrever)
argument-hint: <número da sessão E1..E12>
---
Monte o Pacote de v0 da sessão **$1** e grave em `pacotes/PACOTE_$1.md`.

Leia antes: `docs/ESTRUTURA_7_CAPITULOS.md`, `docs/ARSENAL_VERIFICADO_v2_3.md`, `docs/CONJUNTO_ANCORA.md`, `docs/CONTEXT_BLOCK.md`, `docs/BANCO_DE_CAMPO.md`, e o conteúdo de `corpus/`.

O pacote tem exatamente estes sete itens, nesta ordem:

1. **Contrato do capítulo** — uma linha: o que o leitor sabe no fim que não sabia no começo. Se não couber em uma linha, o capítulo não está pronto para ser escrito: diga isso e pare.
2. **Fichas do arsenal** citadas por este capítulo, **copiadas verbatim**, só elas. Não parafraseie ficha.
3. **SAÍDA real do corpus** deste capítulo: caminho do arquivo, transcrição colada e os números que vão aparecer no texto. Se faltar, escreva `[FALTA SAÍDA: ...]` e marque o pacote como incompleto.
4. **As duas mensagens-âncora** deste capítulo, copiadas de `docs/CONJUNTO_ANCORA.md`. Se não estiverem lá, o pacote está incompleto.
5. **Slot de figura**: qual frame, a legenda afirmativa e o alt-text em ≤140 caracteres.
6. **Último parágrafo aprovado do capítulo anterior**, copiado do manuscrito.
7. **Linhas do Banco de Campo autorizadas** para este capítulo — zero, uma ou duas. Fora dessas, primeira pessoa é proibida.

No fim, escreva `STATUS: COMPLETO` ou `STATUS: INCOMPLETO` com a lista do que falta. Não escreva o capítulo.
