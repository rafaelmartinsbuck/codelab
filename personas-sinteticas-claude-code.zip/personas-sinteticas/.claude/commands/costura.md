---
description: Passada de costura sobre o manuscrito inteiro (só depois de E1..E11)
---
Passada de costura. Não reescreva capítulo: costure.

1. Concatene tudo em `manuscrito/LIVRO_COMPLETO.md` na ordem: E1 prefácio · E1 antes de começar · E2 introdução · E3..E9 capítulos 1-7 · E10 apêndice · E11 back matter.
2. Confira e corrija: pontes entre capítulos (o último parágrafo de um antecipa o próximo sem anunciá-lo); ordem canônica das três métricas idêntica em todas as ocorrências; faixas de progresso 1 a 7 presentes e corretas; nomes das sete Capacidades idênticos em toda menção; glossário respeitado.
3. Rode `bash gates/rodar_gates.sh manuscrito/LIVRO_COMPLETO.md` e, em seguida, `python3 gates/hunt_g3_voz.py` passando os sete capítulos de uma vez, para checar a **amplitude entre capítulos**. Capítulos parecidos demais reprovam mesmo aprovados isoladamente.
4. Leia as 14 mensagens-âncora em sequência, fora do texto. Se não formarem um resumo útil do método, aponte quais trocar.
5. Leia as 8 legendas em sequência. Se sozinhas não ensinarem o método, aponte quais reescrever.
