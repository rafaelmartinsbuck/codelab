---
description: Auditoria de honestidade sobre um capítulo já aprovado nos gates
argument-hint: <caminho do .md>
---
Releia `$1` como um head de engenharia cético que já comprou três livros ruins sobre avaliação de agentes e não quer comprar o quarto.

Liste, sem suavizar e sem elogiar nada:
1. Toda afirmação que não tem ficha em `docs/ARSENAL_VERIFICADO_v2_3.md` nem saída em `corpus/`.
2. Todo parágrafo que soaria exatamente igual se o assunto fosse outro — troque mentalmente "persona sintética" por "teste unitário" e veja se o parágrafo sobrevive. Se sobreviver, ele é vazio.
3. O ponto exato onde esse leitor larga o livro, e por quê.
4. Toda promessa que o capítulo abre e não paga.
5. Se aplicável: onde o capítulo pisa no escopo do Livro 3 (`docs/FRONTEIRA_LIVRO_3.md`).

Não corrija nada nesta rodada. Grave o resultado em `manuscrito/<nome>_AUDITORIA.md`. Se a lista do item 2 tiver mais de três parágrafos, o capítulo precisa voltar para reescrita, não para ajuste.
