---
description: Fecha o pacote para lapidação na outra máquina
---
Monte `ENTREGA/` com:
- `LIVRO_COMPLETO.md`
- `RELATORIO_DE_LAPIDACAO.md`: todas as marcas `[LAPIDAR]`, `[FALTA]` e `[DECISÃO RAFAEL]` do livro inteiro, agrupadas por capítulo, cada uma com o trecho de contexto e o que seria necessário para resolver
- `METRICAS.md`: saída dos três gates por capítulo, mais a tabela de amplitude entre capítulos
- `FICHAS_DE_FIGURA.md`: as 26 fichas (o que a figura afirma, rótulos verbatim, legenda afirmativa, alt-text ≤140)
- `CORPUS/`: as saídas reais usadas, com o índice
- `CONTEXT_BLOCK.md` final

Depois, imprima um resumo em tela: contagem de palavras por capítulo, total de marcas por tipo, e os três pontos que você considera mais frágeis no manuscrito. Seja específico e não elogie o próprio trabalho.
