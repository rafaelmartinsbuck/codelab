---
description: Escreve um capítulo/sessão da v0, do começo ao fim, numa passada
argument-hint: <número da sessão E1..E12>
---
Escreva a sessão **$1**.

**Pré-condição:** `pacotes/PACOTE_$1.md` existe e tem `STATUS: COMPLETO`. Se não, pare e diga o que falta. Não improvise o pacote.

Antes de escrever, leia nesta ordem: `CLAUDE.md`, `docs/FICHA_DE_VOZ_RAFAEL_GODOY_v1.md`, `.claude/skills/personas-sinteticas-rewriter/SKILL.md`, `pacotes/PACOTE_$1.md`, `docs/CONTEXT_BLOCK.md`.

Regras da passada:
- Escreva do começo ao fim, em `manuscrito/$1_<nome-curto>.md`. Uma passada. Não escreva esboço e depois expanda.
- Esqueleto resultado-first do `CLAUDE.md`. Abertura Sinek nos ímpares, Clear nos pares.
- Toda caixa de PROMPT/CÓDIGO seguida de caixa de SAÍDA real do corpus. Sem saída, `[FALTA SAÍDA: ...]`.
- As duas mensagens-âncora vêm do pacote, em páginas diferentes, fora de caixa.
- Marque `[LAPIDAR: ...]` onde falta material em vez de encher. Máximo 8 por capítulo.
- Nada de "nós", conectivo abrindo frase, `—`, exclamação, reticências, pergunta retórica no fecho.

Depois de escrever, rode `bash gates/rodar_gates.sh manuscrito/$1_<nome>.md`, corrija só BLOQUEIO e falha de envelope, e repita até passar.

Por fim, grave `manuscrito/$1_RELATORIO.md` com: métricas finais dos três gates, lista de `[LAPIDAR]`, lista de `[FALTA]`, itens de REVISAR do G1 que você decidiu não mexer e por quê. Atualize `docs/CONTEXT_BLOCK.md` em ≤300 tokens.
