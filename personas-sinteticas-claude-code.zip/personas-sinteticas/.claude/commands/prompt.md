---
description: Escreve e TESTA um dos 7 prompts do Simulador em três perfis
argument-hint: <número da Capacidade 1..7>
---
Trabalhe o **Prompt — Capacidade $1** do Simulador.

1. Leia o rascunho que já existe em `docs/GABARITO_MASTER_v3.md`, seção "Prompt — Capacidade $1". Ele é o ponto de partida, não um sugestão: preserve a estrutura e o vocabulário, melhore o que estiver frouxo.
2. Verifique os quatro critérios de engenharia de prompt: **formação** (o prompt diz quem a IA é e o que ela produz), **minimalismo** (nenhuma instrução que não muda a saída), **parâmetro no topo** (os `[_____]` que o leitor preenche vêm antes das instruções), **groundedness** (toda afirmação sobre o usuário exige trecho-fonte; sem evidência, marca HIPÓTESE).
3. **Rode o prompt três vezes**, com três perfis diferentes de leitor:
   - técnico: engenheiro que já tem agente em produção
   - meio-técnico: PM que sabe ler JSON mas não escreve Python
   - não-técnico: pessoa de suporte ou vendas
   Use inputs plausíveis e distintos para cada um. Arquive as três saídas em `corpus/prompt_cap$1_<perfil>.md`.
4. Avalie e relate:
   - a saída dos três perfis é utilizável, ou só a do técnico?
   - o prompt é **autocontido**? Rode-o sem que o modelo tenha visto a Capacidade $1-1. Se não funciona isolado, ele depende de contexto que o leitor não terá.
   - alguma saída inventou dado que o input não continha? Isso reprova o prompt.
5. Se reprovar em qualquer ponto, corrija o prompt e rode de novo. Grave a versão final em `docs/PROMPTS_FINAIS.md` com as três saídas de exemplo abaixo dela.

Não escreva capítulo aqui. Este comando produz prompt testado e corpus.
