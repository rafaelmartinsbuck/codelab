---
description: Roda os três gates sobre um arquivo do manuscrito
argument-hint: <caminho do .md>
---
Rode `bash gates/rodar_gates.sh $1`.

Depois: para cada BLOQUEIO do G1, monte a tabela `padrão | trecho | reescrita` e aplique. Para cada métrica do G3 fora da faixa, diga qual trecho causou e como vai corrigir — lembrando que frase média alta se conserta acrescentando frase curta, não mutilando as longas. Itens de REVISAR você lista, não corrige.

Rode de novo até `TODOS OS GATES PASSARAM`.
