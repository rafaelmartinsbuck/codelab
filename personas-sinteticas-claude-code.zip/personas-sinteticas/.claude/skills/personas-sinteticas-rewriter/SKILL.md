---
name: personas-sinteticas-rewriter
description: Reescreve capitulos do livro Personas Sinteticas (Rafael Godoy) - como testar, melhorar e confiar em agentes de IA antes da producao. Produto: o Simulador (suite de personas sinteticas + juiz de 3 metricas + dashboard + gate de CI/CD) construido em Colab capitulo a capitulo. Tese: metodologia referencia (DeepMind, Stanford, Sierra, Microsoft, Anthropic) aplicada num produto pratico. 7 capitulos + Apendice (o mapa de 12 do outline original saiu na F0 v2). Zero guru-speak e marcas de IA; abertura Sinek ou Clear; desenvolvimento Andrew Ng; codigo particionado testado; casos reais SO com fonte verificada no arsenal. Use SEMPRE que o usuario pedir: reescrever/revisar capitulo do livro de personas sinteticas, passar pela skill, proximo capitulo, livro 2 do Rafael, ou ao detectar texto colado deste livro.
---

# Personas Sintéticas — Rewriter Skill (v4)
**Livro:** *Personas Sintéticas — Como testar, melhorar e confiar em agentes de IA antes de colocar em produção* (livro + curso; **7 capítulos + Apêndice**; Kindle + Colab).
**Fonte de estrutura:** o Outline único Livro+Curso do Rafael. Este arquivo é o motor de produção; o `ARSENAL_VERIFICADO` é a fonte única de fatos.

## A TESE (em três camadas — toda abertura e fechamento respira isso)
1. **Metodologia referência:** o que DeepMind (Persona Generators/AlphaEvolve), Stanford (agentes generativos, 1.000 pessoas), Sierra (tau-bench), Microsoft (evaluators do Azure AI Foundry) e Anthropic (system prompts de produção, persona vectors) já fazem — destilado em método reproduzível.
2. **Produto prático (como no Profissional Exponencial):** o leitor constrói **o Simulador** — personas sintéticas que estressam o agente dele + juiz de 3 métricas + dashboard + gate de CI/CD. Cada capítulo produz uma peça de código funcional; o Cap 12 compõe tudo no notebook final entregável. **O notebook É o produto** — o equivalente do "prompt é o produto" do livro 1.
3. **Casos da indústria:** cada capítulo ancora em pelo menos um caso REAL do arsenal (com fonte). O fio narrativo recorrente é ficcional e declarado (nota do autor na abertura): um time de engenharia compondo os padrões que os casos reais documentam. **Proibido atribuir fato inventado a empresa real** — o "Toast Inc." do outline original não verificou e está banido; o arsenal traz substitutos verificados.

## Prioridades
- **P0 — O produto é o Simulador.** Capítulo sem peça de código funcional testada = reprovado, por melhor que seja a prosa.
- **P1 — PROMPT/CÓDIGO → RESULTADO (o padrão dominante do livro).** A unidade didática canônica de cada capítulo tem quatro tempos: (1) conceito curto em prosa; (2) caixa de PROMPT ou CÓDIGO; (3) caixa de RESULTADO — o output REAL da execução (transcrição do CORPUS, e plot real quando houver métrica); (4) leitura do resultado em 2-3 parágrafos ("o que isso prova"). O leitor vê a prova antes de ser convidado a agir; a promessa do livro é reproduzível: rodou na IA ou no Jupyter, viu o mesmo tipo de saída. **O exercício perde destaque:** vira "Sua vez" — faixa curta de 3-4 linhas após o resultado, sem caixa grande. Todo bloco de código roda no Colab antes de entrar no texto (Sonnet executa; log e PNGs arquivados). Partições ≤25 linhas. Limites de output nos prompts do Simulador sempre com cláusula condicional: "máximo X (Y se o material anexado for extenso)" — transcrições e logs longos são exatamente o input do leitor sênior.
- **P2 — Um capítulo = uma peça do Simulador = um ganho.** Cadeia: o notebook N ingere o artefato do N-1 (o cadeado de valor do livro 1).
- **P3 — Descoberta, não veredito.** Cada capítulo fecha com o que o leitor agora SABE sobre o agente dele que não sabia (ex.: "passa no ground truth e falha com o usuário impaciente").
- **P4 — Honestidade estrutural (a marca da casa):** personas sintéticas encontram falhas antes e mais barato; não substituem teste com usuários reais nem provam ausência de falha. O gap sim2real é nomeado com fonte (arsenal §A9). Seção "O que o método não entrega" obrigatória (Cap 12). Essa seção carrega a **cena que não termina bem** (obrigatória, herdada do lapidário PE): meia página, figura ilustrativa fora do fio canônico — a suíte cobria dezenas de perfis, todas as métricas passaram, e um usuário real quebrou o agente na primeira semana com um comportamento que nenhuma persona simulava. Sem laço no final; o valor entregue é informação (o Simulador não elimina o desconhecido — encurta o tempo até nomeá-lo e virá-lo persona nova); zero métrica inventada.
- **P5 — Internacional.** Domínios de exemplo universais (atendimento, vendas, suporte, RH); zero jurisdição local.
- **P6 — Comprador sênior na Parte 1 (lapidário PE v61).** O livro tem dois leitores: quem roda o notebook e quem decide se o agente vai para produção. O Head/Diretor que compra para o time precisa se ver endereçado em 2-3 passagens de prosa nos Caps 1-3 — o custo do agente ruim em produção é dele, não do engenheiro. Teste: um Head lendo o Cap 1 não pode concluir "isso é para o meu time, não para mim".

- **P7 — Público e privado (transposto da Prioridade 3b do PE).** O resultado do método tem duas metades e elas se comportam de forma oposta: **pública** — o dashboard de uma página e o gate, visual, apresentável numa reunião, do tipo que o leitor mostra ao time e ao chefe; **privada** — a tabela de falhas encontradas no agente dele, escrita, detalhada, iterativa. Ninguém publica o bug; todo mundo publica o gate que agora protege a produção. Marcar explicitamente o que é qual nos Caps 5 e 7, que carregam o gatilho de compartilhamento.

## GLOSSÁRIO CANÔNICO (não desviar)
- **Persona sintética** — usuário simulado por LLM que estressa um agente em teste. NÃO usar como sinônimos: "avatar", "bot de teste", "usuário fake".
- **O Simulador** — o produto final: população de personas + juiz de 3 métricas + dashboard + gate. Sempre com maiúscula.
- **Os cinco arquétipos** — padrões comportamentais que quebram agentes de formas diferentes (escalador B2B, descritor de sintoma, desafiador de política, trocador de contexto, risco de abandono). Base verificada: arsenal §A5 + §A4. Sempre comportamento observável, nunca demografia.
- **As três métricas** — sempre nesta ordem, por extenso na primeira menção do capítulo: **Resolução de Intenção** (a IA entendeu o que o usuário quer? — evaluator padrão da indústria, Azure AI Foundry), **Aderência à Tarefa** (o agente seguiu instruções e política? — idem), **Resolutividade** (o usuário voltaria? — a métrica própria do livro, o diferencial). Duas da indústria + uma nossa: a assimetria é tese, não acidente.
- **Cobertura comportamental** — o que importa não é quantas personas, é quantos failure modes distintos (support coverage vs. density matching — a distinção do paper da DeepMind, §A1). Conceito-âncora nº 1.
- **Persona drift** — a persona que esquece quem é depois do turno 2.
- **pass^k** — definição exata (§A4): a tarefa só conta como passada se o agente passa em TODAS as k tentativas independentes do mesmo cenário. Números canônicos citáveis: gpt-4o <50% das tarefas; pass^8 <25% em retail (τ-bench).
- **Vetos** — "jornada" (herdado); "revolucionário"/"game-changer"; prometer que simulação substitui usuário real; qualquer estatística sem ficha no arsenal.

## CONCEITOS-ÂNCORA (reforçados 1x por capítulo, sempre com mecanismo + fonte)
1. **Cobertura vence média.** Testar só o usuário provável constrói falsa robustez; o outlier derruba o sistema em produção. (§A1)
2. **Acurácia em input limpo é a métrica mais perigosa que existe.** 100% no ground truth mede o teste, não o agente. (§A4/§A6)
3. **Persona é especificação de comportamento, não biografia.** O system prompt do Claude é uma spec de milhares de linhas onde cada regra estranhamente específica parece um incidente corrigido — é assim que persona de produção se escreve. (§A10)
4. **Melhoria sem diagnóstico documentado é superstição.** O loop failure→fix→re-teste com change log separa iterar de chutar. (§A7)
5. **A persona passou quarenta anos muda; em 2023 ela começou a responder.** Duas linhagens que se encontram: a do design (Cooper → data-driven → Park, §A13) e a da engenharia (Eckert 1997 → Schatzmann 2007 agenda-based → τ-bench 2024, §A20). O livro é o ponto de encontro — e é essa genealogia dupla que o torna citável por arquitetos e por gente de produto ao mesmo tempo.
6. **O agente testado é ReAct; a persona que o testa não é.** Persona é ator + rastreador de estado; o painel escala em orchestrator-worker — o mesmo padrão que a Anthropic publicou com 90,2% sobre single-agent. (§A18, §A14)

## MAPA CANÔNICO — 7 capítulos + Apêndice (estrutura vigente; o outline de 12 é histórico)
Cada capítulo entrega UMA Capacidade que encaixa na anterior. Cadeia: conversa real → persona mínima → arquétipo → spec → painel → juiz → loop → Simulador.

| Cap | Título | Capacidade | O que o leitor descobre | Âncoras |
|---|---|---|---|---|
| 1 | O teste que passa em tudo | **1 — O Caso Real**: a persona mínima extraída de UMA conversa real que deu errado | acurácia em input limpo mede o teste, não o agente | §A4 · §A11 · §A24b |
| 2 | Os cinco jeitos de quebrar | **2 — O Arquétipo**: os 5 arquétipos adaptados ao domínio dele | comportamento quebra agente; demografia não | §A5 · §A27 · §A23 |
| 3 | A persona que não desmonta | **3 — A Spec**: identidade + réguas + condição de saída, anti-drift | persona de produção se escreve como system prompt de produção | §A10 · §A9 · §A17/§A15/§A16 · **§A39** |
| 4 | O painel que discorda | **4 — O Painel**: 5 personas cobrindo failure modes DISTINTOS | cobertura vence média; pedir "personas diversas" produz clones | §A1 · §A2 · §A14 · §A30 |
| 5 | As três perguntas | **5 — O Juiz**: avaliador de 3 métricas com evidência | duas métricas são da indústria; a Resolutividade é a que decide se o cliente volta | §A3 · §A4 · §A21 · §A24a |
| 6 | Da falha ao conserto | **6 — O Change Log**: loop diagnóstico→fix→re-teste | melhoria sem diagnóstico documentado é superstição | §A3 · §A7 · §A24c |
| 7 | O Simulador | **7 — Ativação**: comando completo + notebook + dashboard + ritual quinzenal | as 7 peças viram sistema; e o que o método NÃO entrega | §A25 · §A31 · §A9 · §A6 |
| Ap. | O Laboratório | os 7 blocos + plots.py, espelhando os capítulos | reprodutibilidade: `Run all` refaz todas as figuras | — |

**Colabs:** um por capítulo (01–07) + o notebook final. As referências a "Colab 08–12" do outline antigo estão mortas.

## PROVA VISUAL (plots reais — a convicção do leitor técnico e do executivo)
Cada capítulo carrega ≥1 evidência de execução real, gerada pelo notebook do CORPUS (matplotlib, estilo sóbrio, sem grid pesado) e inserida como figura: radar de traços da persona vs. transcrição-fonte (Cap 3), mapa de divergência do painel (Cap 4), barras das 3 métricas com evidência (Cap 5), antes/depois do fix + consistência pass^k (Cap 6), dashboard do gate (Cap 7). Regra: **nenhum plot decorativo** — todo gráfico impresso nasceu de uma execução arquivada e o leitor reproduz com o Apêndice. Plots são a segunda linguagem visual do livro (a primeira é o traço hand-drawn conceitual); nunca misturar as duas na mesma figura.

## APÊNDICE OBRIGATÓRIO — "O Laboratório" (para o leitor técnico)
Apêndice em Python/Jupyter que reconstrói o Simulador de ponta a ponta: os 6 blocos do código (spec → simulação → juiz → pass^k → painel/gate → relatório) + as funções de plot que geram todas as evidências visuais do livro + instruções de execução no Colab. O apêndice espelha os capítulos bloco a bloco (a costura livro↔código é literal) e é referenciado ao fim de cada capítulo numa linha única: "No Laboratório (Apêndice), este passo em código: Bloco N."

## REGRAS DE VOZ (herdadas integrais do livro 1)

### O envelope medido (NOVO — fonte: corpo do PE v131, 27.066 palavras)
A voz não é adjetivo, é distribuição. Estas são as marcas mensuráveis da prosa que já passou, e o `hunt_g3_voz.py` as verifica:
- **Travessão curto.** A casa usa `–` com espaços, não `—`. No v131: 524 contra 105. É a marca tipográfica mais visível de texto de LLM não revisado.
- **Conectivo de abertura é quase inexistente:** 0,36% das frases. Nada de *Portanto / Assim / Além disso / No entanto / Ou seja / Dessa forma / Nesse sentido / Em resumo / Por fim / Vale ressaltar / É importante destacar*. A relação entre as frases se faz pela ordem delas, não por rótulo.
- **Ritmo irregular por construção:** frase média 16,4 palavras com desvio de 11,6 (burstiness 0,70). 14% das frases têm até 5 palavras; 30% passam de 21. Parágrafo de uma frase só é 37% dos parágrafos.
- **Quase nenhum ponto e vírgula** (0,92/1000) e **zero exclamação e zero reticências**.
- **Segunda pessoa, não primeira do plural:** "você" 10,8/1000; "nós/nosso/a gente" **zero**. Primeira pessoa do singular racionada a 1,8/1000 — e só a partir do Banco de Campo.
- **Capítulos variam entre si:** no v131, a frase média oscila de 13,9 a 21,1 palavras entre seções. Capítulo idêntico a capítulo é família de cheiro de IA; escrever tudo no mesmo ritmo é o erro.
Detalhe completo em `FICHA_DE_VOZ_RAFAEL_GODOY_v1.md`, que entra no Pacote de v0 de toda sessão.

### "nomear" — regra de três níveis (importada do PE)
1. **PROIBIDO — moldura.** Frase cujo trabalho é avisar que algo será nomeado: `(vale|cabe|convém|é importante|importa|vamos|precisamos)\s+nomear`. Corte a moldura e diga a coisa.
2. **PROIBIDO — sinônimo preguiçoso.** Se *dizer, citar, descrever, apontar, registrar, traduzir* couber, o verbo concreto ganha.
3. **PERMITIDO COM TETO — rótulo técnico.** "failure mode nomeado", "arquétipo nomeado": **máximo 1 por capítulo** fora das caixas.

Abertura alterna **Sinek** (tensão: dois times, mesmo agente, resultados opostos) e **Clear** (cena concreta primeiro); desenvolvimento **Andrew Ng** (um conceito por vez, exemplo antes da abstração, código logo depois do conceito). Storytelling acima de tutorial. Zero marcas de IA, zero guru-speak. Final de capítulo fecha em descoberta, nunca em pergunta retórica.

### LISTA DE CAÇA (sweep executável ANTES de propor qualquer capítulo — é o G1)
**BLOQUEIO (zero matches):** fórmulas de LLM (`vale ressaltar` · `é importante destacar` · `diante disso` · `nesse sentido` · `dito isso,`); falsa profundidade (`não se trata de` · `a verdade é que` · `no fim do dia`); clichês de IA (`no mundo de hoje` · `em um cenário cada vez mais` · `vamos mergulhar` · `em resumo` como fechamento · trios de adjetivos decorativos · `desbloquear o potencial` · `elevar ao próximo nível`); guru-speak (`zona de conforto` · `game-changer` · `revolucionário` · urgência fabricada); vetos de canon (`jornada` · `avatar` · promessa de substituir usuário real); frase "que eu não diria" (segunda metade rebuscada — teste: Rafael falaria isso numa mentoria técnica?).
**REVISAR (não reprova; decisão humana item a item):** a família da antítese de reversão (`Não é X. É Y.` · `Não era X – era Y` · `A diferença não estava em X. Estava em Y.`) — no v131 ela aparece seis vezes em construções autorais defensáveis, e regex nenhum separa a negação que estabelece FATO narrativo da que só prepara o reveal; trio decorativo fechando frase; advérbio vazio (`simplesmente`, `genuinamente`); transição explicativa no início de frase.
**TETO:** rótulo técnico com particípio (`arquétipo nomeado`, `failure mode nomeado`) — máximo 1 por capítulo fora das caixas.
**Permitidos (voz autoral):** `não X, mas Y` inline simples; tricolons staccato; frases curtas ancoradas em mecanismo.
**Protocolo:** sweep no rascunho → tabela `padrão | trecho | reescrita` → só então propor → varredura final grep-ável no manuscrito completo antes do docx.
**Três baldes (importado do PE — a lista única reprovava texto bom):** `BLOQUEIO` reprova em qualquer ocorrência; `REVISAR` é decisão humana item a item (negação que estabelece FATO narrativo é legítima; a que só prepara o reveal, não); `TETO` admite no máximo 1 por capítulo fora das caixas. Zero falso positivo tolerado no balde BLOQUEIO: se um editor sério consegue defender o achado, o padrão desce para REVISAR.
**O trio de caça:** `hunt_g1_marcas.py` (padrão vetado) · `hunt_g2_ecos.py` (repetição verbatim) · `hunt_g3_voz.py` (ritmo e densidade). Os três rodam a cada versão, nesta ordem.

## MULTIPERSONA COMO PAPEL SISTÊMICO — escopo travado [DECISÃO F0-9]
O campo tem duas linhas: **role-playing**, em que a persona é atribuída ao modelo (é o que este livro faz — a persona atua como usuário para testar), e **personalization**, em que o modelo cuida da persona do usuário para adaptar a experiência (§A39, Tseng et al., EMNLP Findings 2024). O livro **declara qual das duas ele é** e aproveita exatamente um pedaço da outra — nada além:
- **Cap 3, um parágrafo:** a taxonomia com fonte, e a frase que fecha a porta — a mesma spec que testa, virada do avesso, é a definição de segmento que o agente do leitor precisa atender.
- **Cap 5, a Matriz de Adaptação (2 páginas):** ler o plot 3×5 que já existe **por coluna** em vez de por linha. Nota média alta com variância alta entre personas não é problema de qualidade, é problema de adaptação. Amarra na Resolutividade, que é a métrica proprietária.
- **Cap 7, uma linha do dashboard:** "menor nota entre personas" ao lado da média — o gate olha o pior caso, coerente com o conceito-âncora nº 1 e com o critério de diversidade do DeepTest/ICSE (§A30).
- **Sexto aprendizado em "O que o método não entrega":** adaptação medida em simulação é teto otimista; personalização sem histórico do usuário é falha aberta e medida do campo (§A41, PrefDisco).
**Vetado:** capítulo novo, promessa de personalização na capa, qualquer coisa que empurre o livro para o escopo do Livro 3 (`AI_METRICS_FRAMEWORK_ref.md`).

## CANON DO JUIZ (Cap 5 — o capítulo que revisor sênior ataca primeiro)
1. **Duas filosofias de avaliação, sempre as duas:** por **estado final** (τ-bench: compara o banco ao fim da conversa com a meta anotada — usar quando existe meta verificável no ambiente) e por **juiz** (LLM-as-judge: qualidade conversacional — o método do livro). O livro diz QUANDO usar cada uma; apresentar só o juiz = reprovado.
2. **Vieses do juiz declarados com mitigação (§A21):** position bias → o Juiz avalia conversa única com âncoras de escala, nunca comparação pareada; verbosity bias → evidência citada ANTES da nota; self-enhancement → juiz de modelo/família diferente do agente testado quando possível. Estes três parágrafos são obrigatórios no Cap 5.
3. **Siconfância nomeada com fonte (§A23):** o motivo mecânico de persona ingênua não estressar nada.

## CANON DE ARQUITETURA (termos fixos; errar = reprovação)
**Orquestrador do Simulador** (líder, grava plano) · **Ator de persona** (mantém caráter) · **Rastreador de estado** (mantém a tarefa) · **Juiz** (3 métricas) · **Gate** (decisão de deploy). O agente do leitor é referido como **"seu agente"** e, quando a arquitetura importa, como agente ReAct (pensa→age→observa, §A18). Vetado chamar a persona de "agente ReAct". Definições de método SEMPRE verbatim do arsenal — Opus não reescreve definição de memória (antialucinação).

## REGRA DE CASOS (a resposta definitiva ao "inventar cases")
- **Empresa/instituição nomeada** → só com ficha no `ARSENAL_VERIFICADO` (claim exato · fonte · URL · data de verificação). Sem ficha, não existe no livro.
- **Fio narrativo** → ficcional e declarado em nota do autor ("os times e engenheiros nomeados neste livro são compostos ficcionais; os estudos e empresas citados têm fonte nas Referências"). Nunca dar nome de empresa real ao fio ficcional.
- **Números** → todo número tem fonte no arsenal OU nasce do próprio Colab do livro (rodado e arquivado no CORPUS). "Vi equipes que passaram de 2 dias para 8 minutos" só entra se medido no corpus próprio — senão, reescrever sem o número. **Casa canônica (lapidário PE):** toda métrica tem UMA casa — a ficha do arsenal + a primeira ocorrência estruturada no livro — e no máximo UMA ocorrência plena no payoff narrativo; referência intermediária aponta sem re-citar número.

## QUALITY GATE por capítulo (G1-G11)
- **G1** — sweep da lista de caça: zero matches (executável, não opinião).
- **G2** — ≥1 caso/dado do arsenal citado letra por letra conforme a ficha.
- **G3** — abre por história/cena, nunca por definição.
- **G4** — todo PROMPT/CÓDIGO impresso é seguido da caixa de RESULTADO com output real do CORPUS (e plot quando há métrica); zero saída inventada, zero bloco sem prova.
- **G5** — a peça se encaixa no Simulador: declara o que ingere do capítulo anterior e o que entrega ao próximo.
- **G6** — fecha em descoberta, sem `?` na última frase.
- **G7** — a faixa 'Sua vez' (3-4 linhas) é executável pelo leitor no domínio DELE em uma sessão, na IA (todos os perfis) e no Jupyter (perfil técnico, via Apêndice).
- **G8** — reforça ≥1 conceito-âncora com mecanismo + fonte; as três métricas sempre na ordem canônica.
- **G9 — tipografia (importado do PE, REGRA 6):** exatamente **2 mensagens-âncora por capítulo**, nenhuma dentro de caixa, em páginas diferentes; itálico só em fala curta, título de obra, estrangeirismo na 1ª aparição e legenda; **proibido** negrito em número, em nome de métrica, em nome de Capacidade e em heading; nunca negrito+itálico; nunca CAIXA ALTA de ênfase fora das caixas de código. Verificação: contar runs `<w:b/>` e `<w:i/>` fora de estilos de heading.
  **Teste de aceitação das âncoras:** extraia as 14 mensagens (7 × 2) e leia em sequência. Se não formarem um resumo útil do método, as frases estão erradas — não a regra. Elas são o canal dos negritos do parecer editorial e são **escolhidas antes da sessão**, não descobertas durante.
- **G10 — ecos verbatim (lapidário PE):** rodar `hunt_g2_ecos.py <texto_extraído> --whitelist whitelist_ecos_ps.txt` DEPOIS do sweep G1, a cada versão. ECO fora da whitelist exige decisão (corrigir ou whitelist com comentário). Semente da whitelist: as três métricas na ordem canônica; "Cole no Template do seu Simulador"; a linha do Apêndice "No Laboratório (Apêndice), este passo em código".
- **G11 — envelope de voz (NOVO):** rodar `hunt_g3_voz.py <texto_extraído> --ref`. É o gate que pega o que regex não pega: ritmo chapado, frase longa demais, conectivo de abertura, ponto e vírgula de LLM, travessão errado. Faixas medidas no corpo do Profissional Exponencial v131 e documentadas na `FICHA_DE_VOZ_RAFAEL_GODOY_v1.md`. Fora da faixa não é erro automático — é obrigação de abrir o trecho e decidir.

## GATE DE DOMÍNIO (fundido nesta skill — 5 critérios; roda no código+capítulo antes de propor)
Persona do avaliador: **eng sênior de evals de agentes (calibre dos times de evaluation de Sierra/Microsoft/Anthropic)**. Teste decisivo: *"eu colocaria este gate no CI do meu time?"*
1. **Reprodutível** — outro leitor roda o notebook sem te ligar (dependências fixadas, seeds, dados de exemplo inclusos).
2. **Falha visível** — o capítulo mostra o agente FALHANDO com a persona antes de mostrar o fix (sem falha exibida, não há prova de valor).
3. **Métrica que se move** — antes/depois documentado no formato de change log do Cap 8.
4. **Cobertura, não volume** — personas novas cobrem failure modes novos; redundância é cortada com critério.
5. **Honesto** — nenhuma célula promete o que o gap sim2real desmente.

## TESTE DE VALOR — o Gate do CI
O notebook final vale o preço se um time que o adote substitui dias de teste manual exploratório por um gate automatizado — o critério é o leitor conseguir apresentá-lo numa reunião de stakeholders E commitá-lo no repositório do time. Se o avaliador de domínio diria "isso é demo de tutorial, não gate de produção", o capítulo reprova.

## PRODUÇÃO (workflow por capítulo — herda as travas do livro 1)
0. Pré-condições: ARSENAL fechado; **Pacote de v0 montado** (fichas citadas + SAÍDA do corpus + 2 mensagens-âncora aprovadas + slot de figura com legenda e alt-text + último parágrafo do capítulo anterior + Context Block + linhas autorizadas do Banco de Campo + contrato do capítulo em uma linha); os 7 Colabs esqueletados e RODANDO (CORPUS de execução arquivado — cenas de output do texto são transcrição do corpus, nunca invenção).
1. Rascunho pela skill (Fable/Opus) → 2. G1-G11 + gate de domínio → 3. `book-editor-humanizer` → 4. `guardian-conteudo` → 5. Aprovação do Rafael (siga/avance) → 6. Versão Kindle (docx a partir do template v49 do livro 1) + Colab final.
Skill congela após o Cap 1 aprovado; patch só por evidência de falha recorrente.
**Gate final pré-KDP — Protocolo Buck (lapidário PE):** com o manuscrito completo, leitura sintética integral por persona de comprador real — head de engenharia de fintech, cético, que já viu chatbot passar no QA e cair em produção — entregando: veredito reembolso/leitura + momentos wow; simulação do output de cada Colab/prompt com os dados da persona; gatilhos de compartilhamento; teste de preço; melhorias separadas. Achados viram plano de edições cirúrgicas, nunca regeneração.
**Checklist de pack:** `docProps/core.xml` + `app.xml` presentes e registrados; auditoria dedicada da última página (tolerância zero a eco); "Sobre o Autor" = v3 (fonte única da série). **Calendário:** o termo "personas sintéticas" está em valorização no BR e sem livro concorrente — este título tem prioridade de publicação na série.
Figuras: duas linguagens — (a) traço conceitual da linha, desenhado no **Excalidraw** (26 frames; `exc2livro.py` → SVG com texto em contorno → PNG 400 DPI → docx pareado por alt-text) e (b) plots reais do CORPUS (matplotlib, 300 dpi). **Nunca misturar as duas na mesma figura.** Gemini saiu do pipeline de traço na F0 v2.
**Gramática visual travada:** frame 700×420 e o desenho NUNCA vaza dele (vazar derruba a letra de todas as figuras); régua de fonte 24/32/40 px = 8,4/11,2/14,0 pt impressos; preto + acento #0F4C5C em no máximo dois elementos; `ESCALA_PADRAO` travada após a primeira diagramação.
**Três textos, três funções (regra do v131):** o **rótulo** vive dentro do desenho; a **legenda** vive no `.docx`, afirma alguma coisa ("Volume não é cobertura") e nunca descreve ("As cinco personas"); o **alt-text** descreve o que se vê em ≤140 caracteres. Legenda dentro do desenho é silêncio no Virtual Voice e no leitor de tela — erro que custou uma rodada no livro 1.
**Paleta do livro (substitui o azul do PE):** títulos H1/H2 em **verde-petróleo #0F4C5C**; caixa de produto e faixas de destaque em **#EAF4F2**; caixa de PROMPT/CÓDIGO em terminal escuro **#1E1E1E** (texto #FFFFFF, placeholders #7FD8C4); caixa de RESULTADO em **#F4F7F6** com borda fina #C9D6D2, fonte mono #222222, cabeçalho 'SAÍDA — execução real' em #0F4C5C; plots com paleta petróleo/cinza. Alternativa aprovável em P0: terracota #9C4221 + #FBEEE6. Sem faixa lateral em nenhuma caixa (decisão v49). Quatro elementos visuais e só: produto, prompt/código, resultado, faixa 'Sua vez'.
