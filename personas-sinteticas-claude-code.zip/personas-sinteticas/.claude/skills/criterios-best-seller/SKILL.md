---
name: criterios-best-seller
description: Checklist de 18 critérios estruturais derivados de best-sellers internacionais (Sinek, Clear, Brown, Ries, Newport) para gate de qualidade de capítulos e introduções do livro Profissional Exponencial. Cada critério é PASS/FAIL, todos 18 obrigatórios. Cobre: abertura (hook, resultado inesperado, empatia), narrativa (múltiplos domínios, framework como descoberta, show don't tell, sem seções didáticas na introdução), voz (ritmo, zero IA, zero guru-speak, voz do autor), valor (Teste R$150, exercício nasce da narrativa), internacionalização, originalidade, autenticidade (verificabilidade, cap funciona sozinho) e coesão lógica. Use SEMPRE que um capítulo, introdução ou trecho do Profissional Exponencial precisar de revisão editorial antes de publicação ou de entrada no notebook de evals. Dispara com: "passa pelo checklist de best-seller", "avalia este capítulo", "gate editorial", "os critérios de best-seller", "C1..C18", ou ao receber qualquer trecho do livro pedindo feedback de qualidade.
---

# Critérios de Best-Seller — Checklist v2

Baseado na análise estrutural de Start With Why (Sinek), Atomic Habits (Clear),
Daring Greatly (Brown), The Lean Startup (Ries), So Good They Can't Ignore You (Newport).

Cada critério PASS/FAIL. Todos 18 obrigatórios.

---

## ABERTURA (primeiras 2 páginas)

**C1 - Hook em 3 parágrafos.** Conflito, personagem, resultado inesperado.
Teste: leia os 3 primeiros parágrafos a alguém. Se não perguntar "e depois?", falhou.

**C2 - Resultado inesperado.** O desfecho contradiz a expectativa.
Wright vs. Langley: o favorito perde. British Cycling: últimos viram campeões.

**C15 - Empatia em 3 parágrafos.** O leitor se identifica com ou torce pelo
protagonista. CEO bilionário não gera empatia. Profissional preterido gera.

## NARRATIVA (corpo)

**C3 - Múltiplos domínios, mesmo padrão.** Mínimo 3 histórias de mundos diferentes
que criam o MESMO padrão. O leitor vê a conexão sozinho.

**C4 - Framework como DESCOBERTA.** O conceito aparece DEPOIS das histórias
criarem tensão. O leitor chega ao conceito antes do autor nomeá-lo.

**C5 - Show, don't tell.** Cada conceito demonstrado por cena ou dado.
Nunca afirmação direta do autor.

**C6 - Sem seções didáticas na introdução.** Zero subheadings (##) quebrando
a narrativa da introdução. Prosa corrida. O Cap 1 pode ter seções porque
inclui o exercício.

## VOZ

**C7 - Ritmo de frase.** Frases curtas que socam + parágrafos que respiram.
Teste: leia em voz alta. Se tudo soa igual, falhou.

**C8 - Zero marcas de IA.** Nenhuma frase default de LLM.
Verificação mecânica: `hunt_g1.py` com balde BLOQUEIO zerado. Inclui "nomear"
como verbo de moldura ("vale nomear", "é importante nomear") e "É aqui que".
O balde REVISAR não reprova — é decisão humana, item a item.

**C9 - Zero guru-speak.** Nenhuma frase motivacional vazia.

**C9b - Destaque tipográfico.** Exatamente 2 mensagens-âncora em negrito por
capítulo, verificáveis, fora das caixas, a >= 3 páginas uma da outra. Itálico só
para fala embutida, título de obra, estrangeirismo na 1ª aparição e legenda de
figura. Nunca negrito+itálico. Nunca itálico como ênfase.
Teste: as 14 mensagens-âncora do livro, lidas em sequência, formam um resumo
coerente do método. Se não formam, as mensagens estão erradas.

**C10 - Voz do autor presente.** Experiência pessoal, opinião fundamentada,
"acompanhei", "vi", "apliquei". Credencial de quem observou, não ego.

## VALOR

**C11 - Teste R$150.** Só com a introdução + cap 1, o leitor sente que valeu.
Lente nova + exercício com resultado.

**C12 - Exercício nasce da narrativa.** O leitor QUER fazer porque a história
criou a pergunta "e eu, onde estou?" — não porque o autor mandou.

## INTERNACIONALIZAÇÃO

**C13 - Nomes e contextos universais.** Nomes funcionam em qualquer idioma.
Zero termos jurídicos locais (CLT, PJ, MEI). Fontes globais.

## ORIGINALIDADE

**C14 - História de abertura original.** Não é de outro livro famoso do gênero.

## AUTENTICIDADE (NOVOS)

**C16 - Verificabilidade.** As histórias são declaradas como baseadas em casos
reais ("nomes alterados para preservar privacidade") OU são fatos públicos
verificáveis. Persona sintética sem disclaimer não passa.

**C17 - Cap funciona sozinho.** Se publicar o capítulo como artigo de blog
ou newsletter, funciona como peça independente com começo-meio-fim.
Geraria compartilhamento.

**C18 - Coesão lógica sem não-sequiturs.** Cada parágrafo decorre do anterior.
Cada afirmação tem sujeito + predicado completos — sem fragmentos que parecem
tópicos soltos. Nenhum salto geográfico ou factual não preparado ("quatro
continentes" quando são quatro países; "três coisas" listadas como frases
incompletas). Teste: isole qualquer parágrafo — ele deve fazer sentido lógico
completo sem depender de contexto implícito não estabelecido antes.
Falha automática: (a) frase sem predicado usada como afirmação de peso;
(b) número ou categoria que não confere com o conteúdo listado;
(c) transição entre histórias sem fio condutor explícito.

---

## Como aplicar este checklist

Ao receber um trecho do livro para avaliação:

1. **Tabela de critérios:** C | Nome | PASS/FAIL | Evidência (trecho) | Correção cirúrgica se FAIL.
2. **Veredito:** APROVADO (todos 18 PASS) ou REPROVADO (lista dos que falharam com número do critério).
3. **Reescrita cirúrgica:** para cada FAIL, a frase ou parágrafo exato a reescrever — sem alterar o que está correto.
4. **Prioridade de correção:** C1, C18 e C8 primeiro (impacto maior na percepção de qualidade); depois C7, C9, C10.

Nunca aprove com "PASS condicional" — ou passa ou não passa. Se faltar contexto para julgar um critério (ex.: C3 requer ver outras histórias do capítulo), sinalize explicitamente e peça o trecho necessário antes de emitir veredito.

---

## MODO MESA

**Desacoplado do livro:** os 18 critérios valem para qualquer manuscrito da linha, não só o
Profissional Exponencial. Nenhuma referência a título específico.

**Cedido:** `hunt_g1.py` migra para `mesa-ms-metrics` como fonte única de marcas de IA. Em modo
mesa você **lê** o resultado do dossiê; não recalcula. Três implementações da mesma grandeza
produzem três números e destroem o gate G5.

**Mapeamento para dimensões:**
| Critérios | Dimensão |
|---|---|
| C1, C2, C15 (hook, resultado inesperado, internacionalização) | D1 |
| C3, C4, C5 (múltiplos domínios, framework como descoberta, show don't tell) | D0.A |
| C6, C13, C14 (exercício nasce da narrativa, verificabilidade, cap. sozinho) | D4 |
| C7–C12 (ritmo, zero IA, zero guru-speak, voz) | D5 |
| C16–C18 (originalidade, autenticidade, coesão) | D3 |

**Referencial obrigatório:** cada critério deixa de ser PASS/FAIL isolado e passa a sair com
percentil contra o CANON quando houver corpus. Sem corpus, reporte o booleano e marque
`percentil: null`.

**Proibido:** score global, veredicto.
