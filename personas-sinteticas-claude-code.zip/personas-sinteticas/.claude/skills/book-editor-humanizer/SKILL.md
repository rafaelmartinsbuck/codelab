---
name: book-editor-humanizer
description: >
  Analisa e corrige iterativamente trechos ou capítulos de livros para remover marcas de escrita com IA, adotar voz humana autêntica, aplicar estrutura narrativa de Simon Sinek ou James Clear para abertura e Andrew Ng para desenvolvimento didático, ativar gatilhos psicológicos de aspiração e compartilhamento, e preservar o número de palavras e estrutura narrativa originais. Use SEMPRE que o usuário pedir para revisar, humanizar, reescrever, corrigir, editar ou melhorar um trecho de livro, capítulo, texto editorial ou conteúdo de não-ficção profissional. Também dispara ao mencionar: "humanizar texto", "remover IA do texto", "reescrever como humano", "estilo Sinek", "estilo James Clear", "estilo Andrew Ng", "texto de livro", "capítulo de livro", "edição editorial", "voz humana".
---

# Book Editor & Humanizer

Skill de edição iterativa de trechos/capítulos de livros de não-ficção profissional.  
Objetivo: texto 100% indistinguível de escrita humana, com estrutura narrativa comprovada e gatilhos psicológicos de compartilhamento.

---

## PROCESSO OBRIGATÓRIO (execute em sequência)

### PRÉ-REQUISITO — Livro Context Block

Se um **LIVRO CONTEXT BLOCK** (gerado pela skill `book-context-block`) estiver presente no prompt:

1. Leia as seções A, B, C e D antes de qualquer diagnóstico
2. Adicione o critério **C0 — Coesão com o livro** ao diagnóstico e à reescrita:
   - **C0a:** Nenhuma ancoragem, cena, dado ou relato da seção A pode ser reutilizado
   - **C0b:** Estrutura de abertura da seção B não pode se repetir — se o trecho anterior usou Clear, este usa Sinek, e vice-versa, salvo justificativa explícita
   - **C0c:** Voz, pessoa gramatical e formatação devem ser consistentes com a seção C
   - **C0d:** Baseline Anchors da seção D já foram estabelecidos — não repita a validação, apenas avance

Se **não houver** Context Block, sinalize: *"Nenhum Context Block detectado. Se este não for o primeiro trecho do livro, gere o Context Block com a skill `book-context-block` antes de continuar."*

---

### FASE 0 — Diagnóstico antes de reescrever

Antes de qualquer reescrita, produza um **Relatório de Diagnóstico** com:

1. **Score por critério** (0–10 cada):
   - C0: Coesão com o livro (só se Context Block presente)
   - C1: Ausência de marcas de IA e guru-speak
   - C2: Ancoragem em realidade de mercado (pesquisa verificável)
   - C3: Voz humana autêntica
   - C4: Abertura Sinek/Clear correta
   - C5: Desenvolvimento Andrew Ng correto
   - C6: Gatilhos psicológicos ativos
   - C7: Contagem de palavras preservada (±10%)
   - C8: Estrutura narrativa preservada

2. **Evidências coletadas** por critério (o que está errado, linha por linha)
3. **Palavras/frases marcadas para remoção ou substituição**

Só avance para a reescrita após o diagnóstico.

---

### FASE 1 — Pesquisa de ancoragem (C2)

Antes de reescrever, **pesquise obrigatoriamente** nas fontes abaixo conforme o tema do trecho:

**Comunidades e fóruns**
- Reddit: r/cscareerquestions, r/datascience, r/ExperiencedDevs, r/brasil, r/empreendedorismo, r/marketing, r/smallbusiness, r/freelance, r/humanresources, r/sales

**Blogs de empresas de referência**
- Tech/produto: Nubank Tech Blog, iFood Engineering, Airbnb Engineering, Uber Engineering, Google Engineering, Meli Tech, Feedzai Engineering, Loft Tech, Revolut Tech, Tata Consultancy
- Negócios/gestão: McKinsey Insights, HBR (Harvard Business Review), First Round Review, a16z Blog
- Outros setores: depende do tema — busque blogs de referência do setor específico (saúde, varejo, educação, jurídico, finanças, RH)

**Publicações e newsletters de autoridade**
- The Batch (Andrew Ng / DeepLearning.AI) — para temas de IA, carreira em tech, educação
- James Clear Newsletter — para temas de hábitos, performance, produtividade
- Simon Sinek Stories (simonsinek.com) — para temas de liderança, propósito, cultura

**Objetivo**: coletar **1–3 observações reais, verificáveis e específicas** que ancorem o texto. A ancoragem deve ser calibrada ao público do trecho — profissional de tech, gestor, empreendedor, freelancer, profissional de saúde, etc.

---

#### Como ancoragem funciona nos três autores de referência — aprenda o padrão antes de escrever

**Simon Sinek — ancoragem por observação de padrão entre organizações**
Sinek nunca parte de uma tese abstrata. Abre com uma observação concreta de mercado que ele mesmo fez — geralmente comparando duas organizações no mesmo setor com resultados opostos. O leitor chega à conclusão do porquê antes que Sinek a declare.

> Padrão Sinek: "Olhei para [empresa/líder A] e [empresa/líder B]. Mesmo setor, mesma tecnologia, mesma época. [A] inspirava lealdade. [B] precisava de promoções para vender. Fui entender o que diferenciava os dois."

Exemplos extraídos do estilo dele:
- Fábricas americanas usam marreta de borracha para ajustar portas. Japonesas projetam a porta para caber desde o início. Mesma função, filosofia completamente diferente.
- Martin Luther King Jr. não disse "Eu tenho um plano". Disse "Eu tenho um sonho". A diferença não era o conteúdo — era a sequência: por quê antes do quê.
- Apple comunica de dentro para fora: primeiro o porquê existe, depois como faz, depois o que vende. Dell comunicava de fora para dentro: produto, feature, preço.

**James Clear — ancoragem por cena específica com número verificável**
Clear não discute conceito, ele mostra uma cena. Sempre com detalhe operacional que ninguém inventaria — o travesseiro dos atletas, a tinta branca no caminhão para detectar poeira. O número aparece depois da cena, não antes.

> Padrão Clear: "[Personagem específico] em [ano] com [cargo/contexto]. Fez [ação concreta e incomum]. Resultado mensurável: [número]. O conceito que explica isso é simples."

Exemplos extraídos do estilo dele:
- Dave Brailsford, 2003, assume o ciclismo britânico com a filosofia de melhorar tudo em 1%. Não o treino, não a dieta. Tudo. O gel de massagem que recuperava músculo mais rápido. A técnica de lavar as mãos ensinada por um cirurgião. Cinco anos depois: 60% das medalhas olímpicas de ciclismo em Pequim.
- O autor fratura o crânio numa queda de beisebol no ensino médio. Recuperação de meses. Aprende na prática que pequenas melhorias diárias compõem — "como juros sobre juros, mas para habilidades".
- Ronan Byrne, estudante em Dublin, queria se exercitar mas amava Netflix. Escreveu um programa que só deixava o Netflix rodar se ele estivesse pedalando acima de uma velocidade mínima. Problema resolvido sem força de vontade.

**Andrew Ng — ancoragem por desmistificação com dado de escala**
Ng parte de uma crença comum que limita pessoas e a derruba com dado concreto. Tom de professor que já viu o erro muitas vezes e quer poupar o aluno. Nunca condescendente — empático com quem acredita na crença errada.

> Padrão Ng: "Muita gente acha que precisa de [X complexo] para fazer [Y]. Na prática, a maioria dos [profissionais/projetos] que conheço começa com [Z simples]. Vi isso acontecer com [escala ou exemplo concreto]."

Exemplos extraídos do estilo dele:
- "A maioria das aplicações valiosas de IA que já vi não usava deep learning. Usava regressão logística num dataset bem organizado. O algoritmo sofisticado é o último 5% do problema."
- "Aprendi mais sobre IA nas primeiras 6 semanas do que nos 2 anos anteriores lendo artigos — porque passei a construir. Construir força você a confrontar o que realmente não sabe."
- "Quando olho para estudantes que conseguiram emprego em IA rapidamente, o padrão é quase sempre o mesmo: eles tinham um projeto público que demonstrava que podiam entregar, não só que sabiam a teoria."

---

#### Exemplos de ancoragem ruim vs. boa por setor

| Setor do trecho | Ancoragem ruim | Ancoragem boa |
|---|---|---|
| Carreira tech | "muitas empresas buscam profissionais que se destacam" | "Olhei 50 vagas de engenheiro sênior no LinkedIn BR em março/25. Python e SQL em todas. 'Experiência com LLMs' em 34 delas. Há 18 meses era zero." |
| Gestão/liderança | "líderes de sucesso sabem inspirar suas equipes" | "Sinek entrevistou executivos da Southwest e da Continental. Mesmo mercado, mesma crise de 2001. Uma demitiu zero. A outra demitiu primeiro. A diferença: a Southwest sabia por que existia." |
| Empreendedorismo | "empreendedores precisam de resiliência" | "Fui ver o histórico de 20 startups do Y Combinator que falharam entre 2020-2022. 17 tinham produto funcionando. 14 tinham clientes. O problema em 12 delas era o mesmo: o founder parou de falar com usuário após o product-market fit inicial." |
| Hábitos/produtividade pessoal | "é importante criar rotinas saudáveis" | "Clear mediu: melhorar 1% por dia por um ano = 37x melhor. Piorar 1% por dia por um ano = quase zero. A matemática do hábito não é linear — é exponencial em ambas as direções." |
| RH/gestão de pessoas | "reter talentos é um desafio crescente" | "Gallup 2024: 62% dos funcionários globalmente se declaram 'não engajados'. Custo estimado: US$ 8,9 trilhões em produtividade perdida por ano. O dado existe há 20 anos. As empresas continuam tratando como problema de benefícios." |
| Saúde/bem-estar profissional | "o burnout afeta cada vez mais trabalhadores" | "Microsoft Work Trend Index 2023: 48% dos funcionários e 53% dos gestores reportam burnout. O dado subiu 4pp desde 2022, mesmo depois de políticas de trabalho flexível. Flexibilidade sem clareza de prioridade não resolve — piora." |

---

### FASE 2 — Reescrita com 8 critérios

#### C1 — Remoção de marcas de IA e guru-speak

**Remova imediatamente** qualquer ocorrência de:

- **Padrão de rejeição + revelação** — a família inteira, não só a forma canônica. O padrão é: rejeita uma explicação falsa → afirma a verdadeira → fecha com sentença de peso. Qualquer variação sintática desta lógica é proibida:
  - Forma canônica: "não é X, é Y" / "não se trata de X, mas de Y"
  - Forma bimembre com pausa: "A diferença não estava em X. Estava em Y."
  - Forma com inversão de sujeito: "O problema não é o que entregam. É que a entrega virou obrigação."
  - Forma com eco de substantivo: "obrigação — e obrigação não constrói reputação" (repetir a palavra como pivot dramático)
  - **Regra geral**: se a sentença rejeita algo antes de afirmar algo, é suspeita. Substitua pela observação ou dado que torna a rejeição desnecessária — o leitor chega à conclusão sozinho.
- "Cada vez mais", "no mundo atual", "em um cenário cada vez mais"
- "É nesse ponto que", "É aqui que", "É justamente"
- "Verdadeiro diferencial", "diferencial real", "diferencial genuíno"
- "Impacto concreto", "avanço concreto", "resultado concreto"
- "Transformação", "jornada", "mindset" (sem contexto específico)
- Adjetivos empilhados sem dado: "intensamente", "genuinamente", "profundamente"
- Qualquer construção de lista de três com ritmo idêntico ("Acorda cedo, cumpre prazos, atende clientes")
- "O verdadeiro X", "O real X", "O que realmente importa"
- Perguntas retóricas ao estilo coach: "Por acaso já presenciou isso?"
- Fecho motivacional vazio: "É isso que separa quem X de quem Y"
- **"nomear" (NOVO — regra de três níveis)**:
  - **Moldura — bloqueio absoluto.** Frase cujo trabalho é anunciar que algo será nomeado. Regex: `(vale|cabe|convém|é importante|importa|vamos|precisamos)\s+nomear`. Ex.: "Vale nomear o que este capítulo costuma mexer." Corte a moldura, diga a coisa.
  - **Sinônimo preguiçoso — trocar.** Se **dizer / citar / descrever / apontar / registrar / traduzir** couber, o verbo concreto ganha. "Conseguia nomear três entregas" → "conseguia citar três entregas".
  - **Rótulo técnico — permitido com teto.** "bloqueio nomeado", "gap nomeado", "força nomeada em SAR": máx. 1 por capítulo fora de caixas.

**Substitua por**: observações específicas, dados, verbos no passado com sujeito definido, frases incompletas com tensão, ou silêncio narrativo.

**Verificação mecânica antes de entregar**: rodar `hunt_g1.py` sobre o texto. O balde BLOQUEIO precisa zerar. O balde REVISAR é decisão humana — em particular, `rejeicao-revelacao` e `bimembre-contraste` acertam negações narrativas legítimas (as que estabelecem fato, não as que preparam um reveal). Não corrija no automático.

#### C2 — Ancoragem em realidade de mercado

Use os dados coletados na Fase 1.  
Nunca generalize sem dado. Nunca diga "muitos profissionais" sem exemplificar um.  
Prefira: nomes de empresas, cargos específicos, datas, números, relatos de fóruns reais.

#### C3 — Voz humana autêntica

Voz humana tem:
- Frases incompletas que o leitor termina mentalmente
- Mudanças de ritmo (curta → longa → curta)
- Hesitação ou contradição interna do narrador
- Coloquialismos calibrados (não gírias, mas ruptura do tom formal)
- Observações de primeira pessoa com especificidade ("Quando olhei para as vagas de tech lead em SP em janeiro...")
- Digressões controladas que voltam ao ponto

Voz de IA tem:
- Paralelismo excessivo de estruturas
- Listas de três sem variação
- Transições explicativas ("Portanto", "Sendo assim", "É por isso que")
- Tom sempre elevado, sem queda ou dúvida

#### C4 — Abertura: estrutura Sinek OU Clear

**Use Sinek** quando o tema for: liderança, cultura organizacional, RH, C-Level, gestão de times, propósito corporativo.  
**Use Clear** quando o tema for: produtividade pessoal, hábitos, performance individual, empreendedorismo, carreira técnica, engenharia.

**Template Sinek (Start With Why adaptado)**:
1. Observação de padrão de mercado — neutra, sem juízo ("Fui olhar o que diferencia...")
2. Dado específico ou relato ("Empresas que X têm Y em comum...")
3. Abre para contexto sem revelar a conclusão ("Mas antes de chegar lá, vale entender o que mudou no mercado...")

**Template Clear (Atomic Habits adaptado)**:
1. Cena concreta e específica — um profissional real em situação específica
2. Observação de padrão a partir da cena ("O que aconteceu com ele é mais comum do que parece...")
3. Suspense sem contraste declarado: termine com dado ou fala que abre a pergunta sem respondê-la. Exemplo aceitável: "Fui perguntar para três gestores o que diferenciava quem avançava. Nenhum falou de entrega técnica." — a tensão fica na fala, o leitor formula o contraste sozinho. PROIBIDO: "A diferença não estava onde ele procurava" — estrutura bimembre de contraste, mesmo em suspense.

**PROIBIDO** na abertura:
- Perguntas retóricas diretas ao leitor ("Você já se sentiu...")
- Listas de comportamentos do leitor ("Acorda cedo, cumpre prazos...")
- Declaração do problema no primeiro parágrafo
- Qualquer promessa de solução na abertura

#### C5 — Desenvolvimento: estrutura Andrew Ng

**Template Andrew Ng (CS229/Coursera adaptado)**:
1. Define o conceito pelo que ele **não** exige de background ("Você não precisa saber X para entender Y")
2. Analogia do cotidiano antes da definição técnica
3. Exemplo concreto com números ou situação específica
4. Implicação prática testável hoje ("Se você fizer só isso esta semana...")
5. Conexão com o próximo conceito sem transição explícita

**Tom**: professor que descobriu algo junto com o aluno, não guru que revela verdade.  
**Proibido**: "É fundamental que", "É essencial", "Não podemos ignorar".

#### C6 — Gatilhos psicológicos

Os três mecanismos obrigatórios — **integre ao texto, não como lista**:

**a. Reconhecimento sem exposição**  
O texto descreve uma observação de mercado, não um gap do leitor.  
"Fui olhar vagas de PM sênior no BR..." → leitor se reconhece sem ser apontado.  
Quando compartilha, parece estar à frente, não ficando para trás.

**b. Baseline Anchor**  
Valide o que o leitor já sabe **antes** de mostrar o delta.  
"SQL ainda está em 94% das vagas de dados. OK. Python também. OK. Agora olha o que apareceu nos últimos 90 dias..."  
Sem âncora → ansiedade paralisante. Com âncora → resolução ativa.

**c. Dica testável hoje**  
A ação prática precisa caber em 20 minutos, com ferramenta que o leitor já tem.  
"Abra o LinkedIn agora. Filtre vagas do seu cargo. Copie os 5 primeiros requisitos. Cole no ChatGPT e pergunte: qual desses está sendo substituído por IA nos próximos 12 meses?"

#### C7 — Contagem de palavras

- Tolerância: ±10% do original
- Se variar além disso: justifique explicitamente no relatório de saída
- Nunca adicione seções inteiras para "enriquecer" o texto

#### C8 — Estrutura narrativa

- Preserve a ordem dos blocos temáticos do original
- Pode reorganizar frases dentro de cada bloco
- Se alterar a ordem dos blocos: justifique explicitamente

---

### FASE 3 — Relatório de saída

Após a reescrita, entregue:

```
RELATÓRIO DE EDIÇÃO
───────────────────
Palavras original: X | Palavras reescritas: Y | Variação: Z%

Scores (antes → depois):
C1 Ausência de IA/guru-speak:     X → Y
C2 Ancoragem em mercado:           X → Y
C3 Voz humana:                     X → Y
C4 Abertura Sinek/Clear:           X → Y
C5 Desenvolvimento Andrew Ng:      X → Y
C6 Gatilhos psicológicos:          X → Y
C7 Palavras preservadas:           X → Y
C8 Estrutura narrativa:            X → Y

Scores abaixo de 9: [lista com justificativa e proposta de iteração]

Fontes pesquisadas: [lista de fontes da Fase 1]
Principais substituições: [top 5 substituições com antes/depois]
```

---

### FASE 4 — Iteração

Se qualquer score < 9, proponha automaticamente a próxima iteração focada nos critérios mais baixos.  
Continue iterando até todos os scores ≥ 9.  
Informe o usuário: "Iteração X concluída. Scores abaixo de 9: [lista]. Deseja continuar?"

---

## REFERÊNCIAS DE ESTILO

### Sinek — padrão de abertura aceitável
> "Em 2009, olhei para duas empresas do mesmo setor, tamanho parecido, tecnologia parecida. Uma crescia. A outra encolhia. Fui conversar com as equipes das duas. Os de fora não conseguiam explicar por que compravam de uma e não da outra — só diziam que uma 'parecia mais confiável'."
> *(A tensão fica na observação — o leitor já está se perguntando o porquê. Sinek não declara o contraste, mostra o sintoma.)*

### Clear — padrão de abertura aceitável
> "Em 2011, Dave Brailsford assumiu o ciclismo britânico com uma única ideia: melhorar tudo em 1%. Não a estratégia. Não o treino. Tudo. Até o travesseiro dos atletas."

### Andrew Ng — padrão de desenvolvimento aceitável
> "Você não precisa saber álgebra linear para entender o que um modelo de linguagem faz. Pense em autocomplete — só que treinado com metade da internet. É isso. Agora: o que muda quando você coloca isso no seu processo de onboarding?"

### Marcas de IA — exemplos de remoção

| Original (IA) | Reescrito (humano) |
|---|---|
| "O problema não é o que entregam. É que a entrega virou obrigação — e obrigação não constrói reputação." | [delete — três violações: rejeição+revelação, forma bimembre, eco de substantivo como pivot. Substitua pela observação: "Fui olhar os perfis. Entregavam. O gestor não sabia o nome do que entregaram."] |
| "A diferença não estava nos relatórios de performance. Estava em algo que os gestores enxergavam e os profissionais não." | [delete estrutura inteira — substitua pela observação concreta que mostra o que os gestores enxergavam, sem declarar o contraste] |
| "A estagnação raramente decorre da falta de capacidade" | "Fui olhar os perfis de quem ficou parado em sênior por 4 anos. Nenhum deles tinha falta de técnica." |
| "O verdadeiro diferencial surge quando..." | [delete — substitua pela observação que justifica a afirmação] |
| "Por acaso já presenciou isso?" | [delete — a cena já deve ter feito o leitor se reconhecer] |
| "É isso que separa quem se movimenta de quem realmente avança" | [delete — a implicação deve emergir do exemplo, não ser declarada] |
| "Você já se sentiu preso em um ciclo desgastante?" | "Em 2023, um engenheiro sênior de SP me mandou uma mensagem às 23h: 'Entreguei tudo esse ano. Fui preterido de novo.'" |

---

## MODO MESA — executor, fora da Mesa

Você **não pertence** à Mesa. É o cirurgião; ela é a banca.

**Suprimido:** a FASE 0 e o score 0–10 por critério. Quem corrige não pontua — se você
reescreve e depois se dá 9, é esse número que fica na cabeça do autor.

**Entrada:** a carta editorial do `mesa-edit-letter`, com o plano ordenado por ROI.
**Saída:** o texto corrigido e o **diff**, para o `mesa-revision-verifier`.

**Proibido:** avaliar o próprio resultado, estimar nota, dizer se o manuscrito melhorou.
Quem responde isso é o verificador, e só a partir do diff.
