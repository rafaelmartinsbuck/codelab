---
name: book-context-block
description: >
  Monta e atualiza o Livro Context Block a partir de um ou mais trechos aprovados de um livro. O Context Block é o arquivo de memória viva do livro — registra ancoragens já usadas, estruturas de abertura, convenções de voz e persona do narrador, para que a skill book-editor-humanizer nunca repita cena, dado ou estrutura já utilizada. Use SEMPRE que o usuário fornecer um trecho aprovado de livro e pedir para "atualizar o contexto", "registrar o trecho", "adicionar ao contexto do livro", "montar o context block", ou antes de iniciar a edição de qualquer trecho novo com a skill book-editor-humanizer. Também dispara ao mencionar: "contexto do livro", "memória do livro", "histórico de trechos", "bloco de contexto", "não repetir ancoragem".
---

# Book Context Block

Skill de montagem e atualização do contexto vivo de um livro para uso com a skill `book-editor-humanizer`.

**Objetivo:** produzir um bloco de contexto enxuto (~150–300 tokens) que a `book-editor-humanizer` consome antes de cada edição, garantindo coesão entre capítulos sem desperdiçar janela de contexto com o livro inteiro.

---

## QUANDO USAR

| Situação | Ação |
|---|---|
| Primeiro trecho do livro | Criar o Context Block do zero |
| Trecho aprovado (score ≥ 9) | Atualizar o Context Block existente |
| Antes de editar novo trecho | Entregar o Context Block atual para a `book-editor-humanizer` |
| Múltiplos trechos de uma vez | Processar em sequência, atualizando após cada um |

---

## PROCESSO OBRIGATÓRIO

### FASE 1 — Extração

Leia o(s) trecho(s) fornecidos e extraia obrigatoriamente:

**A. Ancoragens usadas**
Para cada trecho, identifique:
- Cenas concretas com personagem + situação + detalhe operacional
- Dados numéricos com fonte + data
- Relatos de fóruns, gestores, entrevistas
- Nomes de empresas ou pesquisas citadas

**B. Estrutura de abertura**
- Qual autor foi usado: Sinek ou Clear?
- Qual foi o mecanismo: cena específica / comparação entre organizações / observação de padrão?
- Uma linha descrevendo a abertura (não o conteúdo — o mecanismo)

**C. Convenções de voz estabelecidas**
Extraia apenas o que está explicitamente presente no texto:
- Pessoa gramatical do narrador (1ª pessoa / 3ª pessoa / impessoal)
- Tom dominante (investigativo / didático / conversacional / ensaístico)
- Presença ou ausência de subtítulos
- Presença ou ausência de listas ou tabelas
- Qualquer outro padrão de formatação recorrente

**D. Baseline Anchors já estabelecidos**
Registre qualquer conhecimento que o leitor já foi convidado a validar como verdadeiro antes de ver o delta — para não repetir o mesmo anchor em capítulos seguintes.

---

### FASE 2 — Montagem do Context Block

Produza o bloco no formato exato abaixo. Mantenha enxuto — máximo 300 tokens. Se uma seção estiver vazia, escreva `nenhum ainda`.

```
## LIVRO CONTEXT BLOCK
Atualizado em: [capítulo ou trecho mais recente processado]

### A — Ancoragens já usadas (não repetir)
- [tipo: cena/dado/relato] [descrição em uma linha] [referência: Cap X / Trecho X]

### B — Estruturas de abertura já usadas
- [Cap/Trecho X]: [autor: Sinek/Clear] — [mecanismo em uma linha]

### C — Voz e convenções estabelecidas
- Narrador: [pessoa gramatical + tom]
- Formatação: [subtítulos sim/não | listas sim/não | outros padrões]

### D — Baseline Anchors estabelecidos
- [anchor em uma linha] [referência: Cap X]

### E — Próximo trecho
[reservado — preencher antes de chamar a book-editor-humanizer]
```

---

### FASE 3 — Instrução de uso

Após entregar o Context Block, sempre inclua:

```
COMO USAR:
1. Cole o LIVRO CONTEXT BLOCK acima no início do prompt
2. Cole o trecho novo abaixo de "### E — Próximo trecho"
3. Chame a skill book-editor-humanizer normalmente

A skill usará o Context Block para:
- Barrar ancoragens, cenas ou dados já usados (critério C0)
- Manter consistência de voz e formatação
- Evitar repetição de estrutura de abertura consecutiva

Atualize o Context Block após cada trecho aprovado (score ≥ 9).
Nunca atualize com trecho ainda em iteração.
```

---

### FASE 4 — Atualização incremental

Quando receber um novo trecho aprovado para adicionar a um Context Block existente:

1. Leia o Context Block atual
2. Extraia apenas o que é **novo** no trecho aprovado (FASE 1)
3. Adicione às seções existentes — nunca reescreva o que já está lá
4. Atualize o campo `Atualizado em:`
5. Mantenha o bloco dentro de 300 tokens — se exceder, comprima descrições já registradas para uma linha ainda mais curta, sem perder a informação essencial

---

## REGRAS DE COMPRESSÃO

O Context Block precisa ser útil e pequeno. Quando comprimir:

| O que preservar | O que comprimir |
|---|---|
| Nome do personagem + situação única | Detalhes narrativos da cena |
| Fonte + número do dado | Contexto em que o dado apareceu |
| Mecanismo da abertura | O conteúdo da abertura |
| Padrão de voz | Exemplos de voz |

Exemplo de entrada longa demais:
> "Cena do engenheiro de dados de SP que liderou a migração completa do data lake da empresa em três meses com zero incidentes na virada e recebeu a resposta do gestor de que entregava bem mas não era visto como referência"

Comprimida corretamente:
> `[cena] engenheiro dados SP — migração data lake, preterido na promoção [Cap 1]`

---

## EXEMPLO DE OUTPUT COMPLETO

Dado o trecho aprovado da iteração anterior desta conversa, o Context Block seria:

```
## LIVRO CONTEXT BLOCK
Atualizado em: Trecho 1 (Cap 1 — estagnação de carreira)

### A — Ancoragens já usadas (não repetir)
- [cena] engenheiro dados SP — migração data lake, preterido na promoção [Trecho 1]
- [cena] 3 gestores perguntados — nenhum citou entrega técnica no top 3 [Trecho 1]
- [dado] Fox Human Capital 2024 — sênior +12%, júnior/pleno -14,5% [Trecho 1]
- [dado] LinkedIn BR março/2025 — Python/SQL em 100% das vagas sênior [Trecho 1]
- [cena] profissional com 40 repos no GitHub — zero acesso de recruiter em 18 meses [Trecho 1]
- [observação] 20 perfis comparados — variável era visibilidade fora do time [Trecho 1]

### B — Estruturas de abertura já usadas
- [Trecho 1]: Clear — cena específica (engenheiro SP) + fala do gestor abre o padrão

### C — Voz e convenções estabelecidas
- Narrador: 1ª pessoa, investigativo — observa padrões, vai perguntar, olha dados
- Formatação: sem subtítulos | sem listas | parágrafos curtos | frases quebradas para ritmo

### D — Baseline Anchors estabelecidos
- Piso técnico (Python/SQL/cloud) validado como estável há 3 anos [Trecho 1]
- Entrega consistente validada como presente nos profissionais parados [Trecho 1]

### E — Próximo trecho
[cole aqui o próximo trecho antes de chamar a book-editor-humanizer]
```

---

## MODO MESA

**Bloqueado em P0–P6.** O Context Block carrega as convenções e a intenção do autor. Entregá-lo
ao Halloran antes do veredicto faz a Mesa julgar o livro pelos critérios do próprio livro — que
é exatamente o viés que o charter existe para impedir.

**Obrigatório em P7.** Na carta editorial ele volta, para que o plano de correção respeite as
convenções já estabelecidas em vez de sugerir mudanças que contradizem a linha.

Se for invocado durante a auditoria, responda apenas: `bloqueado em modo mesa até P7`.
