#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hunt_g1_marcas.py v2 — Gate G1: lista de caça em TRÊS BALDES

Mudança em relação à v1 (lição do lapidário do Profissional Exponencial v60→v63):
a lista única reprovava texto bom. A negação que estabelece FATO narrativo é legítima
("A planilha não era de nenhum projeto. Era o registro da própria carreira"); a que existe
só para preparar o reveal, não. Regex nenhum distingue as duas. Então:

    BLOQUEIO  qualquer ocorrência REPROVA. Só entra aqui string mecanicamente inequívoca.
              Zero falso positivo tolerado: se um editor sério consegue defender o achado,
              o padrão está largo demais e desce para REVISAR.
    REVISAR   alta suspeita, uso legítimo possível. NÃO reprova. Decisão humana, item a item.
    TETO      permitido com limite. Acima do teto, reprova.

Par de:  hunt_g2_ecos.py (repetição verbatim) · hunt_g3_voz.py (ritmo e densidade)

Uso:
    python3 hunt_g1_marcas.py texto_extraido.txt
    python3 hunt_g1_marcas.py texto_extraido.txt --so-bloqueio

Entrada: `pandoc -f docx -t plain --wrap=none`. Linhas de caixa/tabela/rótulo são ignoradas.
Exit 1 se houver BLOQUEIO ou estouro de TETO. REVISAR sozinho não reprova (exit 0).
"""
import re
import sys
import unicodedata

BOX_PREFIXES = ("|", "+", "=", "[", "-", "—", "· ", ">")

# ---------------------------------------------------------------- BLOQUEIO
BLOQUEIO = [
    # -- "nomear" como moldura: a frase só avisa que algo será nomeado
    ("nomear-moldura",   re.compile(r"(vale|cabe|convém|convem|é importante|e importante|importa|vamos|precisamos)\s+nomear", re.I)),
    # -- fórmula de LLM: moldura explicativa
    ("fórmula-llm",      re.compile(r"\b(vale ressaltar|vale destacar|é importante (destacar|ressaltar|notar)|cabe destacar|diante disso|nesse sentido)\b", re.I)),
    # -- falsa profundidade
    ("fórmula-llm",      re.compile(r"(^|[.!?]\s+)Dito isso,", re.M)),
    ("falsa profundidade", re.compile(r"\b(não se trata de|a verdade é que|no fim do dia|no fundo, o que)\b", re.I)),
    # -- abertura genérica
    ("abertura-genérica", re.compile(r"\b(no mundo de hoje|no mundo atual|nos dias de hoje|em um cenário cada vez mais|num cenário cada vez mais|vivemos em um)\b", re.I)),
    ("abertura-genérica", re.compile(r"\bvamos mergulhar\b", re.I)),
    # -- fecho default
    ("fecho-default",    re.compile(r"\b(em resumo|em suma|em síntese|por fim,|concluindo,)\b[,:]?", re.I)),
    # -- guru-speak
    ("guru",             re.compile(r"\b(zona de conforto|game[- ]?changer|revolucionári[oa]s?|desbloquear o potencial|elevar (ao|para o) próximo nível|o céu é o limite|virada de chave)\b", re.I)),
    # -- vetos de canon do livro 2
    ("canon: 'jornada'",       re.compile(r"\bjornadas?\b", re.I)),
    ("canon: 'avatar'",        re.compile(r"\bavatar(es)?\b", re.I)),
    ("canon: 'mindset'",       re.compile(r"\bmindsets?\b", re.I)),
    ("canon: 'usuário fake'",  re.compile(r"\busuários? fakes?\b", re.I)),
    ("canon: 'bot de teste'",  re.compile(r"\bbots? de teste\b", re.I)),
    ("canon: substituir usuário real",
     re.compile(r"substitui(r|em|ndo)?\s+(o\s+)?(teste com\s+)?usuários? rea(l|is)", re.I)),
    # -- primeira pessoa do plural (o narrador da casa não usa)
    ("1ª pessoa do plural", re.compile(r"\b(a gente|nós (precisamos|podemos|vamos|temos))\b", re.I)),
]

# ---------------------------------------------------------------- REVISAR
REVISAR = [
    # a família da antítese mora AQUI, não em BLOQUEIO: no v131 ela aparece 6 vezes em construções
    # autorais defensáveis. Critério humano: negação que estabelece FATO narrativo fica;
    # negação que só existe para preparar o reveal sai.
    ("antítese 'Não é X. É Y.'",              re.compile(r"[Nn]ão é [^.!?\n]{2,60}[.!?] +É ")),
    ("antítese 'Não era X — era Y'",          re.compile(r"[Nn]ão era [^.\n]{2,60}[—–] *era ")),
    ("antítese 'Não porque X. Porque Y'",     re.compile(r"[Nn]ão porque [^.\n]{2,60}\. +Porque ")),
    ("antítese 'não é o que X entrega. É o que'", re.compile(r"[Nn]ão é o que [^.\n]+ entrega\. +É o que")),
    ("nomear-genérico",   re.compile(r"\bnomear\b(?!\s+(o|a)\s+(bloqueio|gap|arquétipo|failure))", re.I)),
    ("bimembre-contraste", re.compile(r"\b[Aa] diferença não (estava|está|é|era) [^.\n]{2,60}\.\s+[EeÉé]st")),
    ("rejeição-revelação", re.compile(r"\b[Nn]ão (era|é|foi) [^.,;\n]{2,50}, (mas|e sim) ")),
    ("transição-explicativa", re.compile(r"^(Portanto|Assim,|Dessa forma|Desse modo|Sendo assim|Logo,|Isso significa que|Ou seja)", re.M)),
    ("advérbio-vazio",    re.compile(r"\b(genuinamente|profundamente|intensamente|verdadeiramente|simplesmente)\b", re.I)),
    ("superlativo sem dado", re.compile(r"\b(o (mais|maior|melhor|pior) [a-zà-ÿ]+ que existe)\b", re.I)),
    # trio decorativo: três palavras longas fechando a frase — a assinatura do fecho de LLM
    ("trio decorativo no fecho", re.compile(r"\b[a-zà-ÿ]{6,},\s+[a-zà-ÿ]{6,}\s+e\s+[a-zà-ÿ]{6,}\s*[.!?]")),
]

# ---------------------------------------------------------------- TETO
TETO = [
    ("nomear-técnico (máx. 1/capítulo)", re.compile(r"\b(failure mode|arquétipo|gap|bloqueio) nomead[oa]\b", re.I), 1),
]


def is_box(line: str) -> bool:
    s = line.strip()
    if not s:
        return True
    if s.startswith(BOX_PREFIXES):
        return True
    letters = [c for c in s if c.isalpha()]
    if letters and sum(c.isupper() for c in letters) / len(letters) > 0.8:
        return True
    return False


def varrer(corpo, padroes):
    achados = []
    for ln, line in corpo:
        for nome, rx in padroes:
            for m in rx.finditer(line):
                ini = max(0, m.start() - 30)
                trecho = ("…" if ini else "") + line[ini:m.end() + 30].strip() + "…"
                achados.append((nome, ln, trecho))
    return achados


def tabela(titulo, achados, largura=38):
    print(f"\n### {titulo} — {len(achados)} ocorrência(s)")
    if not achados:
        print("  (nenhuma)")
        return
    print(f"  {'PADRÃO':{largura}} | LINHA | TRECHO")
    print("  " + "-" * 78)
    for nome, ln, trecho in achados:
        print(f"  {nome:{largura}} | {ln:5} | {trecho}")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        sys.exit(2)
    so_bloqueio = "--so-bloqueio" in sys.argv
    raw = open(args[0], encoding="utf-8").read().splitlines()
    corpo = [(i + 1, unicodedata.normalize("NFC", l))
             for i, l in enumerate(raw) if not is_box(l)]

    bloq = varrer(corpo, BLOQUEIO)
    rev = [] if so_bloqueio else varrer(corpo, REVISAR)

    # fechamento em pergunta retórica (G6)
    for idx, (ln, line) in enumerate(corpo):
        if line.rstrip().endswith("?"):
            nxt = corpo[idx + 1][1].strip() if idx + 1 < len(corpo) else ""
            if not nxt or nxt.startswith(("Capítulo", "CAPÍTULO", "Apêndice")):
                bloq.append(("fechamento em pergunta retórica (G6)", ln, line.strip()[-70:]))

    estouros = []
    texto = " ".join(l for _, l in corpo)
    for nome, rx, teto in TETO:
        n = len(rx.findall(texto))
        if n > teto:
            estouros.append((nome, n, teto))

    print("=" * 84)
    print("HUNT G1 v2 — LISTA DE CAÇA EM TRÊS BALDES")
    print("=" * 84)
    tabela("BLOQUEIO (reprova)", bloq)
    if not so_bloqueio:
        tabela("REVISAR (decisão humana, item a item — não reprova)", rev)
    print(f"\n### TETO")
    for nome, rx, teto in TETO:
        n = len(rx.findall(texto))
        print(f"  {nome:44} {n:3} (teto {teto}) {'OK' if n <= teto else 'ESTOUROU'}")

    print("\n" + "=" * 84)
    reprova = bool(bloq) or bool(estouros)
    print(f"BLOQUEIO: {len(bloq)}  ·  REVISAR: {len(rev)}  ·  TETO estourado: {len(estouros)}")
    print("G1 = " + ("APROVADO" if not reprova else
                     "REPROVADO — tabela `padrão | trecho | reescrita` para cada BLOQUEIO"))
    sys.exit(1 if reprova else 0)


if __name__ == "__main__":
    main()
