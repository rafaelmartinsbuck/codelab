#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hunt_g3_voz.py — Gate G11: envelope estatístico da prosa (o "cheiro de IA" que regex não pega)

Trio de caça:
    hunt_g1_marcas.py  -> PADRÃO vetado (string/regex)
    hunt_g2_ecos.py    -> REPETIÇÃO verbatim
    hunt_g3_voz.py     -> RITMO E DENSIDADE (este)

As faixas foram medidas no corpo de texto do Profissional Exponencial v131 (27.066 palavras,
1.651 frases, 702 parágrafos de corpo). Não são opinião: são a assinatura do livro que passou.

Uso:
    python3 hunt_g3_voz.py cap01.txt
    python3 hunt_g3_voz.py cap01.txt cap02.txt cap03.txt   # + checa uniformidade entre capítulos
    python3 hunt_g3_voz.py cap01.txt --ref                 # imprime a referência do PE ao lado

Entrada: texto extraído com `pandoc -f docx -t plain --wrap=none`.
Linhas de caixa, tabela, título e rótulo são ignoradas (mesmo filtro do g1/g2) — o envelope foi
medido com esse filtro, então mudá-lo invalida as faixas.

Saída: tabela métrica | valor | faixa | veredito. Exit 1 se houver qualquer FALHA.
"""
import re
import sys
import statistics as st

BOX_PREFIXES = ("|", "+", "=", "[", "-", "—", "· ", ">")

# métrica -> (mín, máx, referência PE v131, unidade)
FAIXAS = {
    "frase média (palavras)":            (13.0, 22.0, 16.4, ""),
    "burstiness (desvio/média)":         (0.58, 1.40, 0.705, ""),
    "frases curtas (<=5 palavras)":      (7.0, 23.0, 14.4, "%"),
    "frases longas (>=21 palavras)":     (15.0, 40.0, 29.9, "%"),
    "parágrafos de 1 frase":             (14.0, 55.0, 36.8, "%"),
    "aberturas conectivas":              (0.0, 1.20, 0.36, "% das frases"),
    "ponto e vírgula":                   (0.0, 2.50, 0.92, "/1000 palavras"),
    "travessão curto – sobre o total":   (0.70, 1.0, 0.94, "fração"),
    "exclamação":                        (0.0, 0.0, 0.0, "/1000 palavras"),
    "reticências":                       (0.0, 0.0, 0.0, "/1000 palavras"),
    "1ª pessoa do plural (nós/a gente)": (0.0, 0.0, 0.0, "/1000 palavras"),
    "1ª pessoa do singular":             (0.0, 3.50, 1.83, "/1000 palavras"),
    "interrogação":                      (0.0, 4.50, 2.51, "/1000 palavras"),
    "abertura de § mais repetida":       (0.0, 5.00, 3.28, "% dos §"),
}

CONECTIVOS = ("Portanto", "Assim,", "Além disso", "No entanto", "Contudo", "Todavia",
              "Ou seja", "Por isso", "Dessa forma", "Desse modo", "Nesse sentido",
              "Em resumo", "Em suma", "Por fim", "Sendo assim", "Logo,", "Isso significa",
              "Vale ", "É importante", "Vale ressaltar", "Diante disso", "Nesse contexto")

ARTIGOS = {"O", "A", "Os", "As", "Um", "Uma", "Ele", "Ela", "Isso", "Esse", "Essa", "Este", "Esta"}


def is_box(line: str) -> bool:
    s = line.strip()
    if not s:
        return True
    if s.startswith(BOX_PREFIXES):
        return True
    letters = [c for c in s if c.isalpha()]
    if letters and sum(c.isupper() for c in letters) / len(letters) > 0.8:
        return True
    if len(s.split()) < 4:          # títulos, rótulos, legendas soltas
        return True
    return False


def medir(path: str) -> dict:
    raw = open(path, encoding="utf-8").read()
    paras = [l.strip() for l in raw.split("\n") if not is_box(l)]
    if len(paras) < 5:
        raise SystemExit(f"{path}: menos de 5 parágrafos de corpo — arquivo errado ou filtro pegou tudo.")
    txt = " ".join(paras)
    palavras = re.findall(r"[A-Za-zÀ-ÿ0-9%]+", txt)
    kw = len(palavras) / 1000
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", txt) if len(s.strip()) > 1]
    sl = [len(re.findall(r"[A-Za-zÀ-ÿ0-9%]+", s)) for s in sents]
    n = len(sl)

    um_frase = sum(1 for p in paras
                   if len([s for s in re.split(r"(?<=[.!?])\s+", p) if s.strip()]) == 1)
    conect = sum(1 for s in sents if s.startswith(CONECTIVOS))
    em, en = txt.count("—"), txt.count("–")
    primeiras = {}
    for p in paras:
        w = p.split()[0]
        if w not in ARTIGOS:
            primeiras[w] = primeiras.get(w, 0) + 1
    pico = max(primeiras.values()) if primeiras else 0

    return {
        "_arquivo": path, "_palavras": len(palavras), "_frases": n, "_paragrafos": len(paras),
        "frase média (palavras)": st.mean(sl),
        "burstiness (desvio/média)": st.pstdev(sl) / st.mean(sl),
        "frases curtas (<=5 palavras)": sum(1 for x in sl if x <= 5) * 100 / n,
        "frases longas (>=21 palavras)": sum(1 for x in sl if x >= 21) * 100 / n,
        "parágrafos de 1 frase": um_frase * 100 / len(paras),
        "aberturas conectivas": conect * 100 / n,
        "ponto e vírgula": txt.count(";") / kw,
        "travessão curto – sobre o total": (en / (en + em)) if (en + em) else 1.0,
        "exclamação": txt.count("!") / kw,
        "reticências": (txt.count("…") + len(re.findall(r"\.\.\.", txt))) / kw,
        "1ª pessoa do plural (nós/a gente)":
            len(re.findall(r"\b(nós|nossos?|nossas?|a gente)\b", txt, re.I)) / kw,
        "1ª pessoa do singular":
            len(re.findall(r"\b(eu|meu|minha|meus|minhas)\b", txt, re.I)) / kw,
        "interrogação": txt.count("?") / kw,
        "abertura de § mais repetida": pico * 100 / len(paras),
    }


def relatorio(m: dict, mostrar_ref: bool) -> int:
    print("=" * 84)
    print(f"HUNT G3 — ENVELOPE DE VOZ · {m['_arquivo']}")
    print(f"{m['_palavras']} palavras · {m['_frases']} frases · {m['_paragrafos']} parágrafos de corpo")
    print("=" * 84)
    cab = f"{'MÉTRICA':36} {'VALOR':>9} {'FAIXA':>16}"
    if mostrar_ref:
        cab += f" {'PE v131':>9}"
    print(cab + "  VEREDITO")
    print("-" * 84)
    falhas = 0
    for nome, (lo, hi, ref, un) in FAIXAS.items():
        v = m[nome]
        ok = lo - 1e-9 <= v <= hi + 1e-9
        if not ok:
            falhas += 1
        linha = f"{nome:36} {v:9.2f} {f'{lo:.2f}–{hi:.2f}':>16}"
        if mostrar_ref:
            linha += f" {ref:9.2f}"
        seta = "" if ok else ("  ↓ abaixo" if v < lo else "  ↑ acima")
        print(linha + f"  {'ok' if ok else 'FALHA'}{seta}")
    print("-" * 84)
    print(f"FALHAS: {falhas}   G3 = " + ("APROVADO" if not falhas else "REPROVADO"))
    return falhas


def uniformidade(ms: list) -> int:
    """Capítulo idêntico a capítulo é família de cheiro de IA. No PE v131 a amplitude
    da frase média entre seções foi 7,2 palavras e a de burstiness, 0,75."""
    print("\n" + "=" * 84)
    print("UNIFORMIDADE ENTRE CAPÍTULOS (variação humana é alta; texto de IA é chapado)")
    print("=" * 84)
    falhas = 0
    for chave, minimo, ref in [("frase média (palavras)", 2.5, 7.19),
                               ("burstiness (desvio/média)", 0.15, 0.75),
                               ("frases curtas (<=5 palavras)", 5.0, 13.82)]:
        v = [x[chave] for x in ms]
        amp = max(v) - min(v)
        ok = amp >= minimo
        if not ok:
            falhas += 1
        print(f"  amplitude de {chave:34} {amp:6.2f}  (mín {minimo} · PE {ref})  "
              f"{'ok' if ok else 'FALHA — capítulos chapados demais'}")
    return falhas


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    mostrar_ref = "--ref" in sys.argv
    if not args:
        print(__doc__)
        sys.exit(2)
    medidas, falhas = [], 0
    for p in args:
        m = medir(p)
        medidas.append(m)
        falhas += relatorio(m, mostrar_ref)
        print()
    if len(medidas) >= 3:
        falhas += uniformidade(medidas)
    print("\n" + "=" * 84)
    print("VEREDITO FINAL: " + ("APROVADO" if not falhas else f"REPROVADO — {falhas} métrica(s) fora"))
    print("Fora da faixa não é erro automático: é obrigação de olhar o trecho e decidir.")
    sys.exit(1 if falhas else 0)


if __name__ == "__main__":
    main()
