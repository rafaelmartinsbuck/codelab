#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hunt_g2_ecos.py — Gate G2: ecos verbatim (passagens repetidas fora de caixas/templates)

Complementa o hunt_g1 (marcas de IA): o G1 pega padrão de escrita; o G2 pega
REPETIÇÃO — passagens que o livro diz duas vezes com as mesmas palavras.
Origem: lapidário do Profissional Exponencial v60→v62 (dedup de SSI e eco de epílogo).

Uso:
    python3 hunt_g2_ecos.py texto_extraido.txt [--n 8] [--whitelist whitelist_ecos.txt]

Como funciona:
    1. Ignora linhas de caixa/template/tabela (| + = [ - ou rótulos em MAIÚSCULAS).
    2. Marca todo n-grama (default 8 palavras) que ocorre 2+ vezes.
    3. FUNDE n-gramas sobrepostos na passagem repetida MÁXIMA (evita que uma
       frase repetida de 15 palavras vire 8 achados).
    4. Whitelist: passagem é ECO-DELIBERADO se compartilha uma janela de 5+
       palavras com qualquer entrada da whitelist (refrões estruturais, cenas-
       trailer da introdução, fórmulas canônicas do método).
    5. ECO fora da whitelist reprova (exit 1).

Regra editorial correspondente (SKILL, B1):
    Toda métrica/frase tem UMA casa canônica + no máximo UMA ocorrência plena
    no payoff. Ecos estruturais intencionais entram na whitelist do livro.
"""
import argparse
import collections
import re
import sys
import unicodedata

BOX_PREFIXES = ("|", "+", "=", "[", "-", "—", "· ")

def load_lines(path):
    with open(path, encoding="utf-8") as f:
        return f.read().splitlines()

def is_box_or_table(line):
    s = line.strip()
    if not s:
        return True
    if s.startswith(BOX_PREFIXES):
        return True
    letters = [c for c in s if c.isalpha()]
    if letters and sum(c.isupper() for c in letters) / len(letters) > 0.8:
        return True
    return False

def norm(text):
    text = unicodedata.normalize("NFC", text)
    return re.sub(r"\s+", " ", text).strip()

def windows(words, n):
    return {" ".join(words[i:i + n]) for i in range(max(0, len(words) - n + 1))} or {" ".join(words)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("texto")
    ap.add_argument("--n", type=int, default=8, help="tamanho do n-grama base (palavras)")
    ap.add_argument("--wn", type=int, default=5, help="janela de casamento com a whitelist")
    ap.add_argument("--whitelist", default=None)
    args = ap.parse_args()

    wl_windows = set()
    if args.whitelist:
        for ln in load_lines(args.whitelist):
            ln = ln.split("#")[0].strip()
            if ln:
                wl_windows |= windows(norm(ln).lower().split(), args.wn)

    body = " ".join(norm(l) for l in load_lines(args.texto) if not is_box_or_table(l))
    words = body.split()
    n = args.n
    counts = collections.Counter(" ".join(words[i:i + n]) for i in range(len(words) - n + 1))

    # marca posições cujo n-grama é repetido e funde runs consecutivos
    rep = [counts[" ".join(words[i:i + n])] > 1 for i in range(len(words) - n + 1)]
    passages = collections.Counter()
    i = 0
    while i < len(rep):
        if rep[i]:
            j = i
            while j + 1 < len(rep) and rep[j + 1]:
                j += 1
            passages[" ".join(words[i:j + n])] += 1
            i = j + 1
        else:
            i += 1
    repeated = [(p, c) for p, c in passages.items() if c > 1]
    repeated.sort(key=lambda t: (-t[1], -len(t[0])))

    ecos, deliberados = [], []
    for p, c in repeated:
        pw = windows(p.lower().split(), args.wn)
        (deliberados if pw & wl_windows else ecos).append((p, c))

    print("=" * 72)
    print(f"HUNT G2 — ECOS VERBATIM (n={n}, janela whitelist={args.wn})")
    print("=" * 72)
    if deliberados:
        print(f"\nECO-DELIBERADO (whitelist) — {len(deliberados)} (informativo)")
        for p, c in deliberados:
            print(f"  {c}x  {p}")
    if ecos:
        print(f"\nECO — {len(ecos)} (reprova: cada passagem precisa de casa canônica única)")
        for p, c in ecos:
            print(f"  {c}x  {p}")
    print("\n" + "=" * 72)
    print(f"ECO: {len(ecos)}   ECO-DELIBERADO: {len(deliberados)}")
    print("G2 = " + ("APROVADO" if not ecos else "REPROVADO"))
    sys.exit(1 if ecos else 0)

if __name__ == "__main__":
    main()
