#!/usr/bin/env bash
# rodar_gates.sh — os três gates em sequência sobre um capítulo em Markdown
# uso: bash gates/rodar_gates.sh manuscrito/E03_cap1.md
set -u
ARQ="${1:?uso: bash gates/rodar_gates.sh manuscrito/E0N_nome.md}"
DIR="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"
TXT="$TMP/$(basename "${ARQ%.*}").txt"

# extrai o corpo: tira caixas de código, headings markdown e marcas [LAPIDAR]/[FALTA]
python3 - "$ARQ" "$TXT" << 'PY'
import sys, re
src, dst = sys.argv[1], sys.argv[2]
t = open(src, encoding='utf-8').read()
t = re.sub(r"```.*?```", "", t, flags=re.S)          # blocos de código
t = re.sub(r"^\s*>.*$", "", t, flags=re.M)            # citações/caixas
t = re.sub(r"\[(LAPIDAR|FALTA[^\]]*|DECISÃO[^\]]*)[^\]]*\]", "", t)
t = re.sub(r"^#{1,6}\s.*$", "", t, flags=re.M)        # headings
t = re.sub(r"\*\*(.+?)\*\*", r"\1", t)                # negrito
t = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"\1", t)   # itálico
open(dst, 'w', encoding='utf-8').write(t)
PY

FALHA=0
echo; echo "########## G1 — LISTA DE CAÇA ##########"
python3 "$DIR/hunt_g1_marcas_v2.py" "$TXT" || FALHA=1
echo; echo "########## G2 — ECOS VERBATIM ##########"
if [ -f "$DIR/hunt_g2_ecos.py" ]; then
  python3 "$DIR/hunt_g2_ecos.py" "$TXT" --whitelist "$DIR/whitelist_ecos_ps.txt" || FALHA=1
else
  echo "(hunt_g2_ecos.py ausente — pule)"
fi
echo; echo "########## G3 — ENVELOPE DE VOZ ##########"
python3 "$DIR/hunt_g3_voz.py" "$TXT" --ref || FALHA=1

echo; echo "========================================"
if [ "$FALHA" -eq 0 ]; then
  echo "TODOS OS GATES PASSARAM — $ARQ"
else
  echo "REPROVADO — corrija o que está em BLOQUEIO e as métricas fora da faixa."
  echo "REVISAR não se corrige sozinho: liste no relatório e siga."
fi
rm -rf "$TMP"
exit $FALHA
