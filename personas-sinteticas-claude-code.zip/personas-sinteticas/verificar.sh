#!/usr/bin/env bash
# verificar.sh — roda antes de começar. Diz se o bundle está completo e se você pode escrever.
cd "$(dirname "$0")"
echo "=========================================="
echo " PERSONAS SINTÉTICAS — verificação do setup"
echo "=========================================="
ERRO=0
obrig=(CLAUDE.md docs/GABARITO_MASTER_v3.md docs/ARSENAL_VERIFICADO_v2_3.md \
  docs/FICHA_DE_VOZ_RAFAEL_GODOY_v1.md docs/ESTRUTURA_7_CAPITULOS.md \
  .claude/skills/personas-sinteticas-rewriter/SKILL.md gates/hunt_g1_marcas_v2.py \
  gates/hunt_g2_ecos.py gates/hunt_g3_voz.py gates/rodar_gates.sh)
echo; echo "-- arquivos obrigatórios"
for f in "${obrig[@]}"; do
  [ -f "$f" ] && echo "   ok   $f" || { echo "   FALTA $f"; ERRO=1; }
done

echo; echo "-- ambiente"
python3 --version >/dev/null 2>&1 && echo "   ok   python3" || { echo "   FALTA python3"; ERRO=1; }
python3 -c "import anthropic" 2>/dev/null && echo "   ok   pacote anthropic" || echo "   AVISO pip install anthropic (necessário só para o /lab)"
python3 -c "import matplotlib" 2>/dev/null && echo "   ok   matplotlib" || echo "   AVISO pip install matplotlib (necessário só para o /lab)"
[ -n "${ANTHROPIC_API_KEY:-}" ] && echo "   ok   ANTHROPIC_API_KEY definida" || echo "   AVISO ANTHROPIC_API_KEY ausente (necessária só para o /lab)"

echo; echo "-- gates funcionam"
python3 gates/hunt_g3_voz.py >/dev/null 2>&1; [ $? -eq 2 ] && echo "   ok   hunt_g3_voz" || { echo "   ERRO hunt_g3_voz não roda"; ERRO=1; }
python3 gates/hunt_g1_marcas_v2.py >/dev/null 2>&1; [ $? -eq 2 ] && echo "   ok   hunt_g1_marcas_v2" || { echo "   ERRO hunt_g1_marcas_v2 não roda"; ERRO=1; }

echo; echo "-- decisões humanas (bloqueiam a escrita)"
for f in docs/DECISOES_F0.md docs/CONJUNTO_ANCORA.md docs/BANCO_DE_CAMPO.md; do
  n=$(grep -c "PREENCHER" "$f" 2>/dev/null || echo 0)
  if [ "$n" -gt 0 ]; then echo "   PENDENTE $f — $n campo(s) em branco"; ERRO=1; else echo "   ok   $f"; fi
done

echo; echo "-- corpus (bloqueia a escrita dos capítulos)"
n=$(ls corpus/*.md 2>/dev/null | wc -l)
[ "$n" -gt 0 ] && echo "   ok   $n arquivo(s) em corpus/" || echo "   PENDENTE corpus vazio — rode /lab antes de /escrever"

echo; echo "=========================================="
if [ "$ERRO" -eq 0 ]; then echo " PRONTO para escrever."; else echo " AINDA NÃO. Resolva os itens acima."; fi
echo "=========================================="
