# MANIFESTO E PLANO — Personas Sintéticas (v3, definitivo)

## ARQUIVOS FINAIS DO PROJETO (suba exatamente estes)

**Novos (deste kit):**
1. `personas-sinteticas-rewriter_SKILL.md` (v3) — o motor: tese, mapa 7 caps, padrão PROMPT/CÓDIGO→RESULTADO, paleta verde-petróleo, lista de caça, G1-G8, gate de domínio, Apêndice obrigatório. **Instalar como skill.**
2. `ARSENAL_VERIFICADO_v1.md` — fonte única de fatos (fichas com status).
3. `LIVRO_ESTRUTURA_COMPLETA_v1.md` (com adendo v1.1) — mapa de capítulos+fontes, protocolo Opus, mapa de figuras + mapa de PLOTS, mapa de prompts, código dos 6 blocos, esqueleto de página resultado-first.
4. `Personas_Sinteticas_PREVIA_KINDLE_v1.docx` — gabarito de voz (atenção: a prévia ainda usa o esqueleto antigo e o azul; será regravada na F2 com o esqueleto resultado-first e a paleta petróleo).
5. Este arquivo.

**Copiar do projeto do PE, sem mudar:** `criterios-best-seller` · `book-editor-humanizer` · `guardian-conteudo` · `book-context-block` (Context Block novo da linha) · `GUIA_FORMATACAO` + docx v49 (base do template; trocar paleta na F1) · bloco hand-drawn do `PLANO_FIGURAS` · `book_evaluator.ipynb` (células 4/6/7b trocadas na F5).
**Não subir:** rewriter do PE e hr-prompt-evaluator (conflito de canon).

## PASSO A PASSO — cada fase, um dono, um teste de saída

**F0 · Calibração (FABLE + RAFAEL, 1 sessão)**
Travar: título/subtítulo · paleta (default verde-petróleo #0F4C5C; alternativa terracota) · pergunta canônica da Resolutividade · nomes dos 5 arquétipos · nota do autor (fio ficcional). Congela skill v-final.
*Teste de saída:* zero `[DECISÃO]` abertos.

**F1 · Fundações (paralelo)**
- OPUS+busca: segunda checagem do arsenal (abrir fontes primárias dos RE-VERIFICAR, fixar claims/números; +1 caso de blog de engenharia).
- FABLE: `MASTER_TEMPLATE.docx` derivado do v49 — corpo esvaziado, paleta trocada para petróleo (H1/H2, caixas), nova caixa RESULTADO criada, sumário re-titulável.
*Teste de saída:* arsenal sem pendências; template renderiza as 4 caixas na paleta nova.

**F2 · O CORPUS antes da prosa (SONNET executa, OPUS especifica, FABLE arquiva)**
Construir e RODAR o Laboratório completo (6 blocos + plots.py) com o agente-exemplo e a conversa-seed; rodar os 7 prompts em cadeia na IA com 3 perfis (PM, vendedor, eng). Arquivar TODA saída (transcrições + PNGs dos 7 plots). Regravar a PRÉVIA no esqueleto resultado-first como gabarito.
*Teste de saída:* `Run all` reproduz os 7 plots; cada capítulo tem sua SAÍDA real arquivada. **É a trava que garante o "ultra convincente": nada será impresso que não tenha acontecido.**

**F3 · Gate de valor (OPUS como eng sênior de evals + RAFAEL)**
O Simulador do corpus passa nos 5 critérios do gate de domínio + Teste de Valor ("colocaria no CI do meu time?" / "vale R$150+?"). Reprova → conserta produto, não prosa.
*Teste de saída:* gate assinado; Rafael tomou 1 decisão real com o Simulador.

**F4 · Capítulos 1-7 + Apêndice (OPUS, 1 por sessão)**
Por capítulo: pré-condições (ficha ao lado, SAÍDA do corpus ao lado, slots de figura/plot confirmados) → rascunho pela skill no esqueleto resultado-first → checagem de paralelismo → **sweep da lista de caça com tabela padrão|trecho|reescrita** → G1-G8 + gate de domínio → humanizer → guardian → proposta → "siga" do Rafael → docx.
*Teste de saída por capítulo:* zero matches na lista de caça; toda caixa de código/prompt seguida de SAÍDA real; fecha em descoberta.

**F5 · Evals de leitura fluida (SONNET prepara, GEMINI FLASH julga)**
Trocar células 4/6/7b do book_evaluator (3 perfis: eng cético, dev-virou-AI-eng, PM técnico; 7b alinhada à lista de caça e ao G4 resultado-first). Rodar subset por capítulo; manuscrito fechado roda o set completo. Métrica-chave: leitura contínua + valor percebido; reprovação do eng cético = problema de honestidade, prioridade máxima. Padrão de falha → patch na skill por evidência.
*Teste de saída:* todos os caps ≥ limiar nas 5 métricas do notebook.

**F6 · Figuras (GEMINI para o traço, SONNET para os plots)**
Lote único: 16 hand-drawn (vinhetas+figuras conceituais do mapa) no bloco de estilo com a linha "Exact labels verbatim"; os 7 plots entram DIRETO do corpus (PNG 300dpi, sem retoque — são prova, não ilustração). Aceite por imagem: fundo branco puro, acentos, 16:9, ≥1600px.
*Teste de saída:* o teste do arco — as figuras+plots em sequência contam o livro sem prosa.

**F7 · Montagem e fechamento (FABLE)**
Pipeline do PE: inserções em ordem decrescente → pack --original → validação com delta justificado → PDF das páginas tocadas → varredura FINAL grep da lista de caça no texto plano → checagem de números contra corpus/arsenal → TOC/metadados → KDP (e Hotmart: vídeo por sessão + link do Colab).
*Teste de saída:* varredura final zero matches; zero número órfão; docx validado.

## Onde cada exigência sua é garantida
- **Leitura fluida** → F5 (evals de leitor) + Sinek/Clear/Ng na skill + resultado-first (o leitor vê prova, não teoria).
- **Valor R$150+** → F3 (gate de valor no PRODUTO antes da prosa) + Apêndice reproduzível.
- **Zero IA/guru speech** → lista de caça em 3 pontos: F4 por capítulo (sweep antes de propor), F5 (célula 7b), F7 (grep final no manuscrito).
- **Ultra convincente** → F2 (corpus): todo output e todo plot impressos aconteceram e são reproduzíveis pelo leitor na IA e no Jupyter.
