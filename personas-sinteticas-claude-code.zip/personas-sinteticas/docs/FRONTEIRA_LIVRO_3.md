# AI_METRICS_FRAMEWORK_ref — referência de escopo (fonte da ficha §A38)
**Papel na pasta:** documento de REFERÊNCIA, não de escrita. É a fonte da ficha §A38 do arsenal e o mapa da fronteira Livro 2 × Livro 3. O Livro 2 (Personas Sintéticas) usa dele só os itens marcados [L2]; o resto é a Pirâmide do Livro 3 (Agent Evaluation), marcado [L3].

## O que o Livro 2 aproveita [L2]
- **O tipo de agente decide a métrica** (taxonomia Informacional / Transacional / Multi-agente / Transversal) → Cap 5, 1 parágrafo. A persona do leitor precisa saber que tipo de agente testa para escolher o que o Juiz mede.
- **LLM-as-judge + ground truth congelado** como padrão de indústria (linhas SQL-02, SQL-03, SUM-01, CRT-01) → reforço do canon do Juiz, Cap 5.
- **Valor/NPS como métrica transversal** (NEG-01, RAG-08) → a Resolutividade é a versão conversacional e preditiva disso, medida turno a turno; Cap 5.
- **Custo/token como métrica transversal** (CON-01, FinOps) → o parágrafo "quanto custa rodar" do Cap 7; número final do corpus.
- **Plataformas de eval/observabilidade** (fontes normativas: Google Cloud, Confident AI/DeepEval, NIST, ISO) → categoria no Cap 7, sem ranking.

## O que fica para o Livro 3 [L3] (Cap 7 do L2 só faz a ponte de 1 frase)
Trajectory Correctness, Tool Selection Accuracy, Loop/Error Propagation Rate, Schema Compliance, Execution Accuracy, RAG Context Precision/Recall, Guardrail Pass Rate, GRD/red-teaming, TEC-01 observabilidade (Dynatrace/APM), SLOs, plano de monitoramento de 10 pontos, auditoria/logging detalhado, componentes RAG isolados, bias/toxicity/privacy testing.

## Fontes normativas do documento (entram nas Notas do L2 SÓ se citadas; todas passam pela F1)
Google Cloud (tipos de agente) · Confident AI/DeepEval (agent evaluation) · arXiv:2305.10468 (AI Agents vs. Agentic AI) · RAGAS/Weaviate (métricas RAG) · NIST AI RMF + ISO/IEC 42001 (guardrails/observabilidade/auditoria).

## Regra de fronteira (repetida do arsenal, para consulta rápida)
Livro 2 = gerar o usuário sintético + julgar a conversa (3 métricas) + gate. Medir a mecânica interna do agente = Livro 3. Na dúvida: 1 frase de ponte no Cap 7, zero seção.
