**PERSONAS**

**SINTÉTICAS**

*Encontre as falhas antes dos seus usuários —*

*e entregue sistemas de IA que escalam.*

**Rafael Godoy**

— GABARITO MASTER · esqueleto resultado-first · paleta petróleo —

**Sumário**

Prefácio

Antes de começar

Introdução — O teste que mede o teste

Capítulo 1 · O teste que passa em tudo

Capítulo 2 · Os cinco jeitos de quebrar

Capítulo 3 · A persona que não desmonta

Capítulo 4 · O painel que discorda

Capítulo 5 · As três perguntas

Capítulo 6 · Da falha ao conserto

Capítulo 7 · O Simulador

Apêndice · O Laboratório — o Simulador em Python

O que o método não entrega — os cinco aprendizados

Notas e Referências

Sobre o Autor

Agradecimentos

**Prefácio**

*⟦ V0 · vinheta hand-drawn — O TESTE × O MUNDO (F6) ⟧*

No ano passado, acompanhei dois times colocando o mesmo tipo de agente de IA em produção. Os dois eram bons. Os dois testaram antes. O primeiro rodou uma bateria de duzentos casos e passou em todos; comemorou, publicou, e três semanas depois estava apagando incêndio no suporte. O segundo passou em menos testes — e quase não teve incêndio para apagar.

Levei um tempo para aceitar o que separava os dois, porque a resposta era desconfortável de tão simples: quem tinha feito o teste. No primeiro time, o agente conversou com casos de teste — frases limpas, completas, educadas, escritas por quem já sabia a resposta. No segundo, o agente conversou com gente sintética que se comportava como gente de verdade: impaciente, vaga, teimosa, capaz de descrever o sintoma sem nunca nomear o problema.

Existe hoje um corpo sério de pesquisa e de prática de indústria sobre isso. A DeepMind publicou como gerar populações de personas que cobrem o possível, e não só o provável. Stanford transformou mil entrevistas reais em agentes que respondem como as pessoas entrevistadas. A Sierra construiu um benchmark inteiro em que quem testa o agente é um usuário simulado. A Microsoft transformou duas das perguntas certas em métricas oficiais de plataforma.

E isso deixou de ser laboratório. A Anthropic publicou no seu guia oficial de evals que testar um agente conversacional exige um segundo modelo simulando o usuário. Os clientes da Sierra rodam mais de trinta e cinco mil conversas simuladas por dia antes de qualquer mudança chegar a um cliente. A primeira competição de teste de sistemas com LLM da ICSE julgou as ferramentas pela diversidade das falhas que conseguem expor. O que este livro ensina virou rotina de quem opera agente em escala — e continua trancado em papers e documentação técnica que ninguém do seu time de produto vai ler numa terça-feira à noite.

Esse conhecimento existe, funciona — e está no formato errado para quem precisa dele.

Este livro destranca. Em sete capítulos, você constrói o Simulador: um painel de usuários sintéticos do seu produto, um juiz que mede cada conversa com três perguntas e um ciclo de melhoria com assinatura. Você verá cada passo funcionando antes de executá-lo — todo prompt e todo código deste livro aparecem seguidos da saída real que produziram, e você reproduz tudo na IA da sua escolha ou no Laboratório em Python do Apêndice.

Escrevi para quem decide, vende, gerencia ou constrói produtos com IA — e não pode esperar o incêndio para descobrir que testou errado.

*Rafael Godoy*

**Antes de começar**

Este livro funciona diferente dos outros. Ele não termina na leitura: termina num produto que você instala e usa. Para acompanhar, você precisa de três coisas: uma IA de conversa — Claude, ChatGPT ou Gemini, no plano que você já tem; uma conversa real que deu errado — um chat de suporte, um e-mail de reclamação, uma transcrição; e vinte minutos por capítulo.

No primeiro capítulo você preenche três campos que acompanham o livro inteiro: qual é o seu produto ou agente, quem usa, e qual risco te tira o sono. Todos os prompts partem daí.

**Como ler este livro**

Cada passo aparece em três tempos: a caixa escura traz o prompt ou o código; a caixa clara logo abaixo traz a saída real — o que aconteceu quando esse passo foi executado, sem edição; e a prosa em seguida lê o resultado com você. Depois de ver funcionando, uma faixa curta — Sua vez — indica como reproduzir com o seu material. Quem programa encontra o mesmo passo em Python no Apêndice, bloco a bloco. Quem não programa termina o livro com o mesmo produto de quem programa.

**A regra de ouro**

Todos os prompts deste livro carregam a mesma instrução: a IA está proibida de inventar dados sobre pessoas. Todo traço de comportamento que ela extrair precisa citar o trecho da conversa que o sustenta — e o que não tiver evidência entra marcado como hipótese. Essa regra separa uma persona que testa de uma persona que decora parede.

**Nota do autor**

*Os times e profissionais que atravessam a narrativa deste livro são compostos ficcionais, criados a partir de padrões que observei em campo. As empresas, os estudos e os números citados são reais e têm fonte nas Notas e Referências. Todas as saídas impressas nas caixas claras vieram de execuções reais, arquivadas, que você pode reproduzir.*

**Introdução — O teste que mede o teste**

Toda equipe que coloca um agente de IA no mundo faz um teste antes. A pergunta que quase nenhuma faz é mais incômoda: o que o meu teste testa?

Um caso de teste típico é uma frase limpa: pedido completo, contexto no lugar, ortografia impecável. O agente responde, alguém confere, a planilha ganha um visto verde. Duzentos vistos verdes depois, o time tem 100% de acurácia — e uma certeza que nenhum usuário de verdade assinou embaixo.

*⟦ Figura 1 · hand-drawn — Dois caminhos: o teste que o agente passa e o teste que importa (F6) ⟧*

*⟦ F4 · parágrafos: usuário real às 22h + τ-bench com claim fixado pelo arsenal (§A4, após F1) + 1 frase estático×dinâmico com fonte de survey (§A29) ⟧*

*⟦ F4 · narrativa histórica: post-it → planilha → agente → voz (Cooper 1999 → data-driven → Park 2023 → τ³ 2026; §A13 + §A20 + §A26) — 'a persona passou quarenta anos muda na parede; em 2023 começou a responder; em 2026 já interrompe o agente no meio da frase' ⟧*

*⟦ F1b · timeline hand-drawn — POST-IT → PLANILHA → AGENTE (2023) → VOZ (2026) (F6) ⟧*

*⟦ Figura B · desenho EXECUTIVO — CLIENTES DE ENSAIO → SEU AGENTE → NOTA + DECISÃO (F6) ⟧*

Este livro fecha essa distância com método. Você vai construir, capítulo a capítulo, sete Capacidades que se encaixam:

| **O QUE VOCÊ VAI CONSTRUIR** 1. O Caso Real — a persona mínima extraída de uma conversa que deu errado 2. O Arquétipo — os cinco padrões de comportamento que quebram agentes 3. A Spec — a persona completa que não desmonta no segundo turno 4. O Painel — cinco personas que discordam entre si 5. O Juiz — três perguntas que um score único não responde 6. O Change Log — o ciclo falha, conserto, re-teste, com assinatura 7. O Simulador — tudo montado, rodando antes da porta da produção |
| --- |

Duas das três perguntas do Juiz são métricas oficiais da indústria — Resolução de Intenção e Aderência à Tarefa, evaluators publicados pela Microsoft no Azure AI Foundry. A terceira é a contribuição deste livro, e é a que decide o negócio: Resolutividade. O usuário voltaria amanhã?

**Capítulo 1 · O teste que passa em tudo**

*⟦ V1 · vinheta — lupa sobre a conversa amassada (F6) ⟧*

Às 22h17 de uma quinta-feira, uma cliente digitou três palavras no chat de uma loja: "meu pedido sumiu". O agente respondeu em dois segundos, com um parágrafo cordial sobre a política de reembolso — prazos, condições, um link. A cliente leu, digitou "só quero saber onde está", esperou, recebeu o mesmo parágrafo com outras palavras, e no quarto turno escreveu a frase que nenhum dashboard mede: "esquece, vou cancelar".

No dia seguinte, essa conversa não apareceu em relatório nenhum. O agente tinha respondido rápido, com informação correta e tom educado. Pelos critérios do teste que o aprovou, aquilo foi um sucesso. Pelo único critério que sustenta um negócio, foi uma cliente a menos.

*⟦ F4 · parágrafo de validação: converter a falha reportada em caso de teste é o passo 1 do guia oficial de evals da Anthropic (§A24b, verbatim do arsenal) — o leitor executa a prática recomendada pelo laboratório que constrói o Claude, em 10 minutos, sem engenheiro ⟧*

Essa conversa que doeu é o melhor ativo de teste que você tem: ela carrega, comprimidos, o comportamento que quebrou o agente e a evidência de como quebrou. O prompt abaixo a transforma na sua primeira persona sintética — e você vai vê-lo funcionando antes de rodar o seu.

**Prompt — Capacidade 1 · O Caso Real**

| Você é meu engenheiro de testes de agentes de IA. Produto/agente: [_____]   Quem usa: [_____] O risco que me tira o sono: [_____] Leia a conversa real colada abaixo. Não invente nada sobre o usuário: todo traço que você extrair deve citar o trecho que o sustenta; sem evidência, marque como HIPÓTESE. Primeiro, explique em 3 linhas por que essa conversa deu errado - o que o usuário fez que um caso de teste limpo nunca faria. Só então, monte a PERSONA MÍNIMA que reproduz essa falha: - QUEM: 1 linha, só o que a conversa mostra - COMO: 3 réguas de comportamento observáveis, com o trecho-fonte - ABERTURA: a primeira mensagem que essa persona mandaria Feche com 1 previsão testável ("se o agente responder X, essa persona faz Y") e 1 pergunta que eu deveria levar ao meu time. [Conversa real colada aqui] |
| --- |

| **SAÍDA · EXECUÇÃO REAL** *⟦ F2 · transcrição real do corpus — a persona mínima devolvida* *pela IA para a conversa-seed (QUEM/COMO com trechos-fonte,* *ABERTURA, previsão testável) · 10-14 linhas, sem edição ⟧* |
| --- |

*⟦ F4 · leitura do resultado (2-3 §): a régua que o time não via; onde ficou a HIPÓTESE; a previsão que os logs confirmaram ⟧*

| SUA VEZ · 10 MIN — cole a sua conversa que deu errado (ou o relato da última reclamação, três linhas honestas) junto com o prompt acima e guarde a resposta completa: é a sua Capacidade 1. |
| --- |

*No Laboratório (Apêndice), este passo em código: Bloco 1.*

*⟦ F4 · fechamento em descoberta + ponte para os cinco arquétipos ⟧*

· 1 DE 7 CAPACIDADES ·

**Capítulo 2 · Os cinco jeitos de quebrar**

*⟦ V2 vinheta cinco rostos (F6) ⟧*

*⟦ F4 · abertura CLEAR — cena concreta: a mesma pergunta feita de cinco jeitos — teoria dentro da história; fontes: §A5 Impatient users · §A11 NN/g · §A27 benevolence bias (o nome de pesquisa do vilão) · §A23 siconfância — remate: pedir "seja um usuário difícil" produz teatro; dificuldade se especifica (claims fixados na F1) ⟧*

*⟦ F4 · conceito em prosa, estilo Ng, um conceito por vez ⟧*

*⟦ Figura 3 tabela arquétipo × como quebra (F6) ⟧*

**Prompt — Capacidade 2 · O arquétipo**

| *⟦ F4 · texto final do Prompt 2 — página única, parâmetro no topo,* *raciocínio antes da conclusão, regra de ouro, gancho de 1 linha ⟧* *⟦ especificação: ingere a CAPACIDADE 1; devolve os 5 arquétipos adaptados ao domínio + qual ataca primeiro / o failure mode que ninguém listou ⟧* |
| --- |

| **SAÍDA · EXECUÇÃO REAL** *⟦ F2 · SAÍDA real do corpus para este prompt — sem edição ⟧* |
| --- |

*⟦ PLOT real: barras — taxa de falha do agente-exemplo por arquétipo (F2) ⟧*

*⟦ F4 · leitura do resultado (o que isso prova; onde mora a HIPÓTESE) ⟧*

| SUA VEZ · 10 MIN — ⟦ F4 · instrução de 3-4 linhas para reproduzir com o material do leitor ⟧ |
| --- |

*No Laboratório (Apêndice), este passo em código: Bloco 2.*

*⟦ F4 · fechamento em descoberta + ponte para o próximo capítulo ⟧*

· 2 DE 7 CAPACIDADES ·

**Capítulo 3 · A persona que não desmonta**

*⟦ V3 vinheta persona derretendo vs. pergaminho (F6) ⟧*

*⟦ F4 · abertura SINEK — por que personas derretem no turno 2 (drift) — teoria dentro da história; fonte: §A10 Anthropic/Willison · §A15 Grok · §A17 Model Spec · §A16 Meta — o TRIO DE SPECS (cena central: oficial × pública × exposta sem gate) (claims fixados na F1) ⟧*

*⟦ F4 · conceito em prosa, estilo Ng, um conceito por vez ⟧*

*⟦ Figura 4 spec em 3 blocos (F6) ⟧*

**Prompt — Capacidade 3 · A spec**

| *⟦ F4 · texto final do Prompt 3 — página única, parâmetro no topo,* *raciocínio antes da conclusão, regra de ouro, gancho de 1 linha ⟧* *⟦ especificação: ingere o arquétipo escolhido; devolve identidade + 5 réguas observáveis + condição de saída / traços ainda HIPÓTESE ⟧* |
| --- |

| **SAÍDA · EXECUÇÃO REAL** *⟦ F2 · SAÍDA real do corpus para este prompt — sem edição ⟧* |
| --- |

*⟦ PLOT real: radar réguas × evidência + linha de drift por turno (F2) ⟧*

*⟦ F4 · leitura do resultado (o que isso prova; onde mora a HIPÓTESE) ⟧*

| SUA VEZ · 10 MIN — ⟦ F4 · instrução de 3-4 linhas para reproduzir com o material do leitor ⟧ |
| --- |

*No Laboratório (Apêndice), este passo em código: Bloco 3.*

*⟦ F4 · fechamento em descoberta + ponte para o próximo capítulo ⟧*

· 3 DE 7 CAPACIDADES ·

**Capítulo 4 · O painel que discorda**

*⟦ V4 vinheta balões divergentes (F6) ⟧*

*⟦ F4 · abertura CLEAR — pedir **"**personas diversas**"** e receber cinco clones — teoria dentro da história; fontes: §A1 DeepMind coverage**>**density · §A2 · §A14 Anthropic orchestrator-worker (90,2%; 15x tokens; verbatim do arsenal) · §A30 em 1 linha: a competição DeepTest/ICSE 2026 julgou ferramentas por efetividade E diversidade das falhas — cobertura virou régua pública + Figura A: desenho TÉCNICO orquestrador→personas(ator+rastreador)⇄agente ReAct→juiz→gate (claims fixados na F1) ⟧*

*⟦ F4 · conceito em prosa, estilo Ng, um conceito por vez ⟧*

*⟦ Figura 5 clones vs. cobertura (F6) ⟧*

**Prompt — Capacidade 4 · O painel**

| *⟦ F4 · texto final do Prompt 4 — página única, parâmetro no topo,* *raciocínio antes da conclusão, regra de ouro, gancho de 1 linha ⟧* *⟦ especificação: ingere a spec; devolve 5 personas + mapa de divergência + teste de redundância / o buraco de cobertura ⟧* |
| --- |

| **SAÍDA · EXECUÇÃO REAL** *⟦ F2 · SAÍDA real do corpus para este prompt — sem edição ⟧* |
| --- |

*⟦ PLOT real: mapa de divergência do painel (F2) ⟧*

*⟦ F4 · leitura do resultado (o que isso prova; onde mora a HIPÓTESE) ⟧*

| SUA VEZ · 10 MIN — ⟦ F4 · instrução de 3-4 linhas para reproduzir com o material do leitor ⟧ |
| --- |

*No Laboratório (Apêndice), este passo em código: Bloco 5.*

*⟦ F4 · fechamento em descoberta + ponte para o próximo capítulo ⟧*

· 4 DE 7 CAPACIDADES ·

**Capítulo 5 · As três perguntas**

*⟦ V5 vinheta juiz com prancheta (F6) ⟧*

*⟦ F4 · abertura SINEK — o dashboard de 40 indicadores que não responde se o cliente volta — teoria dentro da história; fontes: §A3 Azure AI Foundry · §A24a: a Anthropic nomeia oficialmente a técnica — evals de agente conversacional exigem "um segundo LLM simulando o usuário" · canon do Juiz completo: duas filosofias (§A4) + vieses e mitigações (§A21) (claims fixados na F1) ⟧*

*⟦ F4 · conceito em prosa, estilo Ng, um conceito por vez ⟧*

*⟦ Figura 6 três perguntas, a terceira circulada (F6) ⟧*

**Prompt — Capacidade 5 · O juiz**

| *⟦ F4 · texto final do Prompt 5 — página única, parâmetro no topo,* *raciocínio antes da conclusão, regra de ouro, gancho de 1 linha ⟧* *⟦ especificação: ingere o painel + 1 conversa simulada; devolve notas 1-5 com evidência nas 3 métricas / a pior métrica e a causa ⟧* |
| --- |

| **SAÍDA · EXECUÇÃO REAL** *⟦ F2 · SAÍDA real do corpus para este prompt — sem edição ⟧* |
| --- |

*⟦ PLOT real: barras agrupadas 3 métricas × 5 personas com threshold (F2) ⟧*

*⟦ F4 · leitura do resultado (o que isso prova; onde mora a HIPÓTESE) ⟧*

| SUA VEZ · 10 MIN — ⟦ F4 · instrução de 3-4 linhas para reproduzir com o material do leitor ⟧ |
| --- |

*No Laboratório (Apêndice), este passo em código: Bloco 3.*

*⟦ F4 · fechamento em descoberta + ponte para o próximo capítulo ⟧*

· 5 DE 7 CAPACIDADES ·

**Capítulo 6 · Da falha ao conserto**

*⟦ V6 vinheta engrenagem de 3 dentes (F6) ⟧*

*⟦ F4 · abertura CLEAR — o fix que melhorou uma métrica e quebrou outra — teoria dentro da história; fonte: §A3 · §A7 (claims fixados na F1) ⟧*

*⟦ F4 · conceito em prosa, estilo Ng, um conceito por vez ⟧*

*⟦ Figura 7 linha de change log (F6) ⟧*

**Prompt — Capacidade 6 · O change log**

| *⟦ F4 · texto final do Prompt 6 — página única, parâmetro no topo,* *raciocínio antes da conclusão, regra de ouro, gancho de 1 linha ⟧* *⟦ especificação: ingere o veredito do Juiz; devolve UM fix cirúrgico → re-teste → linha de change log / o que NÃO mudar junto ⟧* |
| --- |

| **SAÍDA · EXECUÇÃO REAL** *⟦ F2 · SAÍDA real do corpus para este prompt — sem edição ⟧* |
| --- |

*⟦ PLOT real: antes/depois do fix + heatmap pass^3 (F2) ⟧*

*⟦ F4 · leitura do resultado (o que isso prova; onde mora a HIPÓTESE) ⟧*

| SUA VEZ · 10 MIN — ⟦ F4 · instrução de 3-4 linhas para reproduzir com o material do leitor ⟧ |
| --- |

*No Laboratório (Apêndice), este passo em código: Bloco 4.*

*⟦ F4 · fechamento em descoberta + ponte para o próximo capítulo ⟧*

· 6 DE 7 CAPACIDADES ·

**Capítulo 7 · O Simulador**

*⟦ V7 vinheta Simulador montado diante da porta PRODUÇÃO (F6) ⟧*

*⟦ F4 · abertura SINEK — a porta da produção e quem passa por ela — teoria dentro da história; fontes: Composição · §A9 sim2real · §A6 · §A25 Sierra: 35.000+ simulações/dia em CI/CD, o gate do leitor é a versão de 1 pessoa do que a indústria opera em escala (é isto que "sistemas de IA que escalam" significa na capa; frase-guarda: o que escala é o par agente+gate) · §A24d Queijo Suíço · Figura B reprisada (claims fixados na F1) ⟧*

*⟦ F4 · conceito em prosa, estilo Ng, um conceito por vez ⟧*

*⟦ F4 · seção FRONTEIRA (1 página, dois horizontes de meia página): (a) o Simulador como serviço — A2A/Agent Card (§A19); (b) o Simulador que fala — τ³/voz (§A26): os arquétipos do Cap 2 já são parâmetros configuráveis (paciência, interruptividade, aversão a silêncio) no benchmark líder; fecho: o formato muda, a spec de comportamento é o que sobrevive ⟧*

*⟦ F4 · 1 parágrafo de mercado (§A31): a categoria virou feature de plataforma em 2025-26; o leitor sai com o método portável — que também serve de critério para avaliar qualquer plataforma que prometa isso pronto (sem ranquear fornecedores) ⟧*

*⟦ Figura 8 dashboard do gate (F6) ⟧*

**Prompt — Capacidade 7 · Ativação**

| *⟦ F4 · texto final do Prompt 7 — página única, parâmetro no topo,* *raciocínio antes da conclusão, regra de ouro, gancho de 1 linha ⟧* *⟦ especificação: ingere as Capacidades 1-6; devolve o comando do Simulador com dados embutidos + ritual quinzenal + dashboard de 1 página / limites declarados ⟧* |
| --- |

| **SAÍDA · EXECUÇÃO REAL** *⟦ F2 · SAÍDA real do corpus para este prompt — sem edição ⟧* |
| --- |

*⟦ PLOT real: o dashboard do gate (Figura 8 é plot, não desenho) (F2) ⟧*

*⟦ F4 · leitura do resultado (o que isso prova; onde mora a HIPÓTESE) ⟧*

| SUA VEZ · 10 MIN — ⟦ F4 · instrução de 3-4 linhas para reproduzir com o material do leitor ⟧ |
| --- |

*No Laboratório (Apêndice), este passo em código: Bloco 6.*

*⟦ F4 · fechamento em descoberta + ponte para o próximo capítulo ⟧*

· 7 DE 7 CAPACIDADES ·

**Apêndice · O Laboratório — o Simulador em Python**

Este apêndice reconstrói, em código, cada Capacidade do livro — bloco a bloco, na mesma ordem. Rode no Colab com Runtime › Run all: as figuras que você viu nos capítulos são reproduzidas na sua tela, com a conversa-seed inclusa. Troque a seed pela sua conversa e o Laboratório vira o seu Simulador.

**Bloco 1 · A spec da persona (Capacidade 3)**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — dicionário de identidade, réguas e condição de saída ⟧*

**Bloco 2 · A conversa simulada (Capacidades 1 e 3)**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — a persona conversa com o SEU agente ⟧*

**Bloco 3 · O juiz de três métricas (Capacidade 5)**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — notas 1-5 com evidência, em JSON ⟧*

**Bloco 4 · pass^k (Capacidade 6)**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — consistência, não sorte ⟧*

**Bloco 5 · O painel e o gate (Capacidades 4 e 7)**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — threshold que libera ou bloqueia ⟧*

**Bloco 6 · O relatório de uma página (Capacidade 7)**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — o que o executivo lê ⟧*

**Bloco 7 (opcional/avançado) · O Simulador como serviço**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — Agent Card A2A + endpoint mínimo expondo simula() (§A19) ⟧*

**plots.py · radar_persona() · divergencia_painel() · barras_metricas() · antes_depois() · heatmap_passk() · dashboard_gate()**

*⟦ F2 · código particionado (≤25 linhas por bloco) + SAÍDA real logo abaixo — as funções que geram cada figura do livro ⟧*

**O que o método não entrega — os cinco aprendizados**

*⟦ F4 · abertura da seção: a honestidade não é ressalva de rodapé; são os cinco aprendizados que a própria elaboração do livro produziu, cada um com fonte e com a resposta prática embutida ⟧*

1. Simulador não é gente. O campo mediu: usuários simulados divergem de humanos em avaliações agênticas (§A28b, Lost in Simulation). Resposta do método: o Simulador é a fatia barata e rápida do Queijo Suíço (§A24d) — ele não substitui as outras camadas; ele impede que a falha óbvia chegue nelas.

2. O gap fecha com grounding, não com prompt melhor. A direção do campo é ancorar o simulador em dado real (§A28c, RealUser-Sim) — exatamente a regra de ouro do livro: todo traço cita o trecho da conversa real. A Capacidade 1 vem antes de todas por isso.

3. Diversidade se especifica, não se pede. Benevolence bias (§A27) somado ao mode collapse (§A1): "gere usuários difíceis" produz teatro cooperativo. Cobertura é decisão de engenharia, não pedido em linguagem natural.

4. Consistência é a métrica adulta. pass^k (§A4): passar uma vez é sorte; o gate exige passar sempre. Um agente que resolve o caso difícil em uma tentativa de cada três não está pronto para a porta da produção.

5. O teste não termina no deploy. Evals em CI são a primeira camada; a monitoração de produção pega o drift que a simulação não previu (§A24e). O ritual quinzenal do Capítulo 7 existe exatamente para essa segunda camada.

*⟦ F4 · fecho da seção e do livro: o método não promete um agente que nunca falha; promete que nenhuma falha barata de encontrar chegue ao seu usuário antes de chegar a você — e essa é a diferença entre operar um sistema de IA e torcer por ele ⟧*

**Notas e Referências**

1. Paglieri et al., Persona Generators: Generating Diverse Synthetic Personas at Scale. arXiv:2602.03545 (2026).

2. Park et al., Generative agent simulations of 1,000 people. arXiv:2411.10109 (2024); Park et al., Generative Agents (2023).

3. Microsoft, Agent Evaluators — Intent Resolution, Task Adherence, Tool Call Accuracy. Azure AI Foundry, learn.microsoft.com (2025-26).

4. Yao et al.; Barres et al., τ-bench / τ²-bench (Sierra, 2024-25). ⟦F1: claim exato⟧

5. He et al., Impatient users confuse AI agents. arXiv:2510.04491 (2025). ⟦F1: números⟧

6. Dou et al., SimulatorArena. EMNLP 2025. ⟦F1: conclusão exata⟧

7. Ge et al., PersonaHub, arXiv:2406.20094 (2024); NVIDIA Nemotron-Personas (2025).

8. arXiv:2601.15290, Agentic Persona Control and Task State Tracking (2026). ⟦F1: arquitetura exata⟧

9. Zhou et al., Mind the Sim2Real Gap, arXiv:2603.11245 (2026); Li et al., arXiv:2503.16527 (2025).

10. Anthropic, system prompts publicados (release notes); Willison, Highlights from the Claude 4 system prompt (mai/2025); Chen et al., Persona vectors, arXiv:2507.21509 (2025).

11. Nielsen Norman Group, Synthetic Users: If, When, and How (nngroup.com).

12. Vezhnevets et al., Concordia, arXiv:2312.03664 (2023).

13. Cooper, The Inmates Are Running the Asylum (1999); Pruitt & Adlin, The Persona Lifecycle (2006); Jansen et al., APG. ⟦F1: anos exatos⟧

14. Anthropic, How we built our multi-agent research system. anthropic.com/engineering (jun/2025).

15. TechCrunch/404 Media, Grok's AI persona prompts exposed (18/ago/2025).

16. Reuters, diretrizes internas dos chatbots da Meta (ago/2025). ⟦F1: matéria primária⟧

17. OpenAI, Model Spec (2024-25); Swarm → Agents SDK. ⟦F1: versão vigente⟧

18. Yao et al., ReAct, arXiv:2210.03629 (2022).

19. Google/Linux Foundation, protocolo Agent2Agent (A2A) (2025). ⟦F1: spec vigente⟧

20. Anthropic, Demystifying evals for AI agents. anthropic.com/engineering (2025-26). ⟦F1: trechos exatos⟧

21. Sierra, Simulations: the secret behind every great agent. sierra.ai/blog (mai/2026). ⟦F1: trecho 35.000/dia⟧

22. Sierra, τ³-Bench: advancing agent evaluation to knowledge and voice. sierra.ai/blog (mai/2026). ⟦F1: parâmetros exatos⟧

23. Efficient Agent Evaluation via Diversity-Guided User Simulation. arXiv:2604.21480 (2026) — benevolence bias. ⟦F1: números⟧

24. Lost in Simulation: LLM-Simulated Users are Unreliable Proxies for Human Users in Agentic Evaluations. arXiv:2601.17087 (2026). ⟦F1: conclusão exata⟧

25. Zhu et al., RealUser-Sim: Bridging the Reality Gap in Agent Benchmarking via Grounded User Simulation. arXiv:2605.20204 (2026). ⟦F1: método exato⟧

26. Sorokin et al., DeepTest Tool Competition 2026 (ICSE/BMW). arXiv:2604.12615 (2026); Mohammadi et al., Evaluation and Benchmarking of LLM Agents: A Survey. arXiv:2507.21504 (2025).

**Sobre o Autor**

*⟦ F4 · bio na voz da linha — inclui o caso do avaliador de leitores sintéticos do primeiro livro (dogfooding verificável) ⟧*

**Agradecimentos**

*⟦ F7 · agradecimentos ⟧*