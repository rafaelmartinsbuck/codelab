# PLANO DE PRODUÇÃO v2 — Personas Sintéticas
**Subtítulo travado:** *Encontre as falhas antes dos seus usuários — e entregue sistemas de IA que escalam.*
**Base:** ROTEIRO_PRODUCAO_v1 + PRONTIDAO_ESCRITA_v1.3 + o que o Profissional Exponencial v131 ensinou.
**Substitui:** ROTEIRO v1 §A passos 25–27 (figuras) e §C inteiro (prompts Gemini). O resto do v1 permanece válido com os patches da §1 abaixo.

---

## 1. PARECER — dez achados que mudam o plano

Cada achado traz a evidência e o que muda. Ordem: primeiro o que reprovaria na etapa mais cedo.

### 1.1 O pipeline de figuras do plano está obsoleto
**Evidência:** o ROTEIRO v1 §C tem 20 prompts Gemini hand-drawn com bloco de estilo, e a skill `personas-sinteticas-rewriter` v3 ainda diz "hand-drawn conceitual da linha (Gemini)". O PE v131 foi fechado por outro caminho: `Figuras_PT.excalidraw` com 29 frames → `exc2livro.py` → SVG com texto em contorno → PNG 400 DPI → injeção no docx por alt-text.
**Muda:** o §C inteiro sai. Gemini deixa de gerar traço. Entram a §6 deste documento e a skill `excalidraw-para-livro`. Patch obrigatório na linha de figuras da skill do livro 2.
**Ganho colateral:** figura de Excalidraw não tem marca d'água nem fundo mosqueado, então a etapa de limpeza da `arte-kdp` cai para auditoria — e a tradução herda o traço sem regerar nada.

### 1.2 A legenda mudou de lugar e de função
**Evidência:** no v131 a legenda é texto do `.docx`, afirmativa e curta — "Toda carreira se apoia em três habilidades", "Pular degrau não funciona" —, o rótulo vive dentro do desenho e o alt-text descreve em ≤140 caracteres. São três textos com três funções. O mapa de figuras do `LIVRO_ESTRUTURA_COMPLETA_v1` ainda traz legendas descritivas em itálico ("*O teste que o agente passa e o teste que importa*").
**Muda:** reescrever as oito legendas numeradas no padrão afirmativo antes de desenhar. A legenda é o canal IMG do parecer editorial: lidas em sequência, as legendas têm que ensinar o método sem o corpo do livro.

### 1.3 Conflito de estrutura: 12 capítulos × 7 capítulos
**Evidência:** a skill instalada (v3) declara no frontmatter "12 capitulos, 3 partes" e carrega o MAPA CANÔNICO de 12 capítulos com Colabs 01–12. `LIVRO_ESTRUTURA_COMPLETA_v1`, o `ROTEIRO` (sessões E1–E12) e o `GABARITO_MASTER_v3` operam em 7 capítulos + Apêndice. Há uma nota de reconciliação parcial só no capítulo 3.
**Muda:** este é o maior risco de deriva de v0 que existe hoje no projeto — o modelo lê a skill antes de tudo. O mapa de 12 sai da skill e vira anexo histórico. Item 1 da F0 v2.

### 1.4 As regras novas do PE ainda não existem na skill do livro 2
**Evidência:** a `profissional-exponencial-rewriter` ganhou, depois do v63, a REGRA 6 (tipografia: no máximo 2 mensagens-âncora por capítulo, itálico em quatro usos, negrito proibido em vértice/dado/nome de Capacidade), a REGRA 2b (CTA não-guru), a regra de três níveis do verbo "nomear" e o gate G9 de tipografia. A skill do livro 2 tem G1–G9, mas o G9 dela é de ecos e não há gate de tipografia.
**Muda:** renumerar (ecos vira G10), criar o G9 de tipografia, importar a REGRA 2b e a regra do "nomear". As duas mensagens-âncora por capítulo deixam de ser efeito colateral da escrita e viram entrada da sessão (§5.2).

### 1.5 O `hunt_g1_marcas.py` está uma geração atrás
**Evidência:** o script do projeto tem lista única de padrões e reprova em qualquer match. O do PE evoluiu para três baldes — BLOQUEIO (reprova), REVISAR (decisão humana) e TETO (máximo 1 por capítulo) — porque `rejeicao-revelacao` e `bimembre-contraste` acertam negações narrativas legítimas. O script do livro 2 também não tem nenhum padrão de "nomear" (`grep -c nomear` = 0).
**Muda:** portar a estrutura de três baldes e os padrões de "nomear" antes da primeira sessão. Sem isso, ou o gate reprova texto bom, ou passa a muleta que custou uma rodada inteira no PE.

### 1.6 A ordem do front matter e do back matter não está escrita em lugar nenhum do livro 2
**Evidência (v131):** capa → folha de rosto → epígrafe de uma linha → **Prefácio** → Sumário → Antes de começar → O que você vai construir → Introdução → capítulos. No fim: Sobre o Autor → Dedicatória → Agradecimentos → Notas e Referências → Créditos. Créditos e dedicatória migraram para o fim; o Prefácio subiu na frente do Sumário.
**Muda:** essa ordem é o resultado da `amostra-kindle` e define onde cai o corte de 10%. Ela precisa estar no `MASTER_TEMPLATE.docx` antes da montagem, não depois. Para o livro 2, o produto tem que estar nomeado — **o Simulador** — dentro de 60% da amostra.

### 1.7 O "Sobre o Autor" da pasta está superado
**Evidência:** `SOBRE_O_AUTOR_LINHA_v2.md` continua na lista de 13 itens da PRONTIDAO. O v131 fechou com um texto v3 curto, em terceira pessoa, que abre por otimismo e fecha em contato — sem lista de cargos.
**Muda:** a variante Personas Sintéticas parte do v3, troca uma única oração pela âncora técnica do livro e mantém o resto idêntico. "Sobre o Autor" é fonte única da série: divergência entre livros é defeito.

### 1.8 O parecer editorial agora mede quatro canais paralelos — e isso é decisão de escrita, não de revisão
**Evidência:** a `diretor-editorial-big-five` reconstrói o livro às cegas por imagens, negritos, prompts e prefixo de 10%, calcula recall/precisão/FRC contra um conjunto-âncora congelado e roda controle negativo com o canal de outro livro. Reprova em bloco se os quatro ficarem abaixo de 0,40.
**Muda:** congelar o conjunto-âncora **antes** do capítulo 1 e distribuí-lo pelos quatro canais na hora de escrever (§5.2). Auditar canal no fim é caro; escrever para o canal é de graça.

### 1.9 O eixo emocional do livro 2 nunca foi decidido
**Evidência:** o PE tem a Prioridade 3b — resultado em duas partes, pública ("Seu Destaque", compartilhável) e privada ("Sua Alavanca"). A skill do livro 2 herdou "descoberta, não veredito" (P3), mas não herdou a divisão. E um livro cujo output é uma lista de falhas do próprio agente não tem, por construção, o que compartilhar.
**Muda:** a divisão se transpõe limpa e resolve o problema — **público = o dashboard de uma página e o gate; privado = a tabela de falhas encontradas.** Ninguém publica o bug; todo mundo publica o gate que agora protege a produção. Os capítulos 5 e 7 carregam o gatilho.

### 1.10 Os bloqueadores materiais continuam abertos
Conversa-seed (real anonimizada ou composto ficcional declarado), agente-exemplo, Banco de Campo, `book_evaluator.ipynb`, `MASTER_TEMPLATE.docx`. Todos já estavam na PRONTIDAO §4.3. Somam-se agora: a cena base do Excalidraw e os scripts `exc2livro.py` com a `ESCALA_PADRAO` travada.

---

## 2. A MULTIPERSONA COMO PAPEL SISTÊMICO

### 2.1 O que o projeto tem hoje
Nada disso. Verifiquei arsenal, estrutura, adendo, roteiro, gabarito e skill: persona sintética aparece exclusivamente como **instrumento de teste** — gerar o usuário simulado, conversar com o agente, julgar com três métricas, decidir o deploy. O mais próximo que existe são três fichas que tratam da persona **do agente**, não do usuário: §A10 (system prompts de produção e persona vectors), §A15/§A16/§A17 (personas-produto de Grok, Meta e o Model Spec da OpenAI) e §A32 (as personas pré-construídas EXPERT / NOVICE / EVALUATOR do ADK do Google — que são personas de usuário simulado com nível de expertise, o vizinho mais próximo do tema, ainda dentro de avaliação).

O papel sistêmico que você descreve — **um painel de personas que o sistema usa para adaptar a experiência de quem está do outro lado** — não está no plano, não está no arsenal e não tem fonte no projeto.

### 2.2 As fontes existem, e são fortes
Quatro entradas verificáveis, prontas para virar fichas:

| Ficha | Fonte | O que sustenta |
|---|---|---|
| **§A39** | Tseng, Huang, Hsiao, Chen, Huang, Meng, Chen. *Two Tales of Persona in LLMs: A Survey of Role-Playing and Personalization*. Findings of EMNLP 2024, p. 16612–16631 · arXiv:2406.01171 | A taxonomia canônica: o campo tem duas linhas — **role-playing**, em que personas são atribuídas ao LLM, e **personalization**, em que o LLM cuida das personas dos usuários. É a primeira survey a unificar as duas sob a visão de persona. É o enquadramento exato da sua pergunta, com endereço acadêmico. |
| **§A40** | Zhang, Rossi, Kveton et al. *Personalization of Large Language Models: A Survey*. arXiv:2411.00027 (2024) | O guarda-chuva da segunda linha: técnicas, taxonomia e avaliação de personalização. Serve de nota de rodapé, não de capítulo. |
| **§A41** | Li, Bose, Brahman, Du, Koh, Fazel, Tsvetkov. *Personalized Reasoning: Just-in-time Personalization and Why LLMs Fail at It*. arXiv:2510.00177 (2025) | A ponte técnica e a honestidade na mesma ficha. Define *personalized reasoning* como adaptar o raciocínio a preferências descobertas; mostra que o cenário difícil é o **cold-start**, sem histórico do usuário; e propõe o PREFDISCO, que **transforma benchmark estático em tarefa interativa de personalização usando personas com preferências esparsas**. Ou seja: o campo já usa painel de personas sintéticas para medir adaptação. É literalmente o método do livro aplicado a outra pergunta. |
| **§A42** | Google ADK — *User Simulation in ADK Evaluation* (nov/2025) + docs `google.github.io/adk-docs/evaluate/user-sim` — já é §A32 | As personas pré-construídas EXPERT / NOVICE / EVALUATOR mostram que a indústria já modela **nível de usuário** como dimensão de simulação. Duas linhas de reforço, sem ficha nova. |

Verificação: §A39 e §A41 foram abertos nesta sessão (título, venue e claim de tese confirmados) — nível N2 do seu protocolo antialucinação. Antes de imprimir número de qualquer um dos dois, abrir o PDF na F1 e subir para N1.

### 2.3 A decisão de escopo recomendada
**Não vire capítulo. Vire leitura transversal.** Três razões, nesta ordem:

1. A promessa da capa é encontrar falhas antes do usuário. Adaptação de experiência é uma promessa diferente, e promessa não paga é o que vira devolução dentro dos 10% e uma estrela depois.
2. O seu `AI_METRICS_FRAMEWORK_ref.md` já fixa a regra de fronteira: livro 2 gera o usuário sintético, julga a conversa e decide o gate; medir mecânica interna vai para o livro 3. Adaptação fica do lado de lá — mas com um pedaço que é legitimamente daqui.
3. O pedaço que é daqui já está construído e não custa página nova: **você já mede três métricas por persona.** Um agente que tira 4,5 com o especialista e 2,1 com o novato não tem problema de qualidade; tem problema de adaptação. O dado já existe no plot de barras 3×5 do capítulo 5. Falta a leitura.

**O que entra, concretamente:**

- **Capítulo 3 (A Spec), um parágrafo:** a taxonomia das duas linhas, com a fonte §A39, e a frase que fecha a porta com honestidade — a persona deste livro é a que testa; a mesma spec, virada do avesso, é a definição de segmento que o seu agente precisa atender. O livro diz qual das duas ele é e aponta a outra. Isso compra autoridade com quem vem de produto e desarma a objeção do leitor sênior.
- **Capítulo 5 (O Juiz), a Matriz de Adaptação:** duas páginas lendo o plot que já existe por coluna em vez de por linha. Nota alta média com variância alta entre personas = falha de adaptação, não de acurácia. É a leitura que nenhuma das plataformas citadas entrega, e amarra direto na Resolutividade — que é a métrica proprietária do livro.
- **Capítulo 7 (o Simulador), uma linha do dashboard:** "menor nota entre personas" ao lado da média. O gate passa a olhar o pior caso, não o caso médio. Coerente com o conceito-âncora nº 1 (cobertura vence média) e com o critério do DeepTest/ICSE (§A30): não basta achar falha, ela tem que ser diversa.
- **Sexto aprendizado em "O que o método não entrega":** adaptação medida em simulação é teto otimista. O campo mediu que personalização just-in-time, sem histórico, é uma falha aberta dos modelos atuais (§A41). Fonte na mão, sem promessa inflada.

**Custo total:** um parágrafo, duas páginas, uma linha de dashboard, uma ficha de aprendizado, quatro fichas de arsenal. Zero capítulo novo, zero mudança na cadeia das sete Capacidades, zero risco de promessa órfã.

---

## 3. O QUE MUDA EM RELAÇÃO AO PROFISSIONAL EXPONENCIAL

A voz é a mesma, letra por letra. A didática é outra, e a diferença tem uma causa única: **no PE o produto é um texto que a IA devolve; aqui o produto é um sistema que roda e imprime evidência.**

| Dimensão | Profissional Exponencial | Personas Sintéticas |
|---|---|---|
| Produto | o Consultor — prompt instalável | o Simulador — personas + juiz + gate, que executa |
| Unidade didática | conceito → exercício → caixa de prompt | conceito curto → PROMPT/CÓDIGO → **caixa de RESULTADO real** → leitura em 2-3 parágrafos → faixa "Sua vez" |
| Onde mora a prova | no output que o leitor vai gerar | no output que **já foi gerado** e está impresso na página |
| Leitor | um: o profissional | dois: quem roda o notebook e quem aprova o deploy (P6) |
| Cadeado de valor | cadeia de dados pessoais do leitor | cadeia de artefatos executáveis + corpus reproduzível |
| Eixo emocional | orgulho que vira compartilhamento | controle que vira autoridade técnica |
| Parte pública / privada | Destaque / Alavanca | **dashboard e gate / tabela de falhas** (achado 1.9) |
| Exercício | bloco com caixa, protagonista | faixa de 3-4 linhas depois do resultado — perde destaque de propósito |
| Figuras | 29 frames Excalidraw | 26 frames Excalidraw + 7 plots matplotlib, nunca misturados |
| Gate de valor | Teste R$150 | Teste R$150 **e** "eu comitaria isso no CI do meu time?" |

Duas coisas que **não** mudam e que qualquer sessão precisa reler antes de começar: a alternância Sinek/Clear na abertura, o desenvolvimento no tom de Ng — e o fato de que a teoria entra dentro da história, nunca como manual.

---

## 4. F0 v2 — as doze decisões antes da primeira linha

As sete que já existiam, mais cinco que este parecer abriu. Uma sessão, com você na mesa.

1. Pergunta canônica da Resolutividade — "voltaria amanhã?" ou "recomendaria?".
2. Nomes em português dos cinco arquétipos.
3. Texto exato da nota do autor (depende do item 5).
4. Paleta — confirmar petróleo #0F4C5C.
5. Seed do corpus — conversa real anonimizada ou composto ficcional declarado.
6. Mecânica do Ensaio Manual — duas janelas como padrão, janela única como atalho, e em qual capítulo entra.
7. Banco de Campo — cinco a oito observações verdadeiras ditadas por você, e a frase de dogfooding do Prefácio.
8. **NOVA — Estrutura: 7 capítulos.** O mapa de 12 sai da skill.
9. **NOVA — Escopo da multipersona:** aprovar ou recusar a Matriz de Adaptação da §2.3.
10. **NOVA — Divisão público/privado:** dashboard e gate são o compartilhável; falhas ficam privadas.
11. **NOVA — Gramática visual do Excalidraw:** os números da §6.1, travados antes de desenhar.
12. **NOVA — Conjunto-âncora congelado:** de 8 a 15 proposições que definem o livro (§5.2).

Só depois disso: patch da skill → congela → F1 e F2 em paralelo → capítulo 1.

---

## 5. TEXT GENERATION — passo a passo

### 5.1 O Pacote de v0 — o mecanismo que faz a primeira versão nascer certa

A primeira versão sai fraca quando o modelo precisa **inventar** o que deveria ter recebido. Cada decisão que ele toma no meio da prosa é uma decisão que ninguém revisou: a âncora que ele escolheu destacar, a figura que ele imaginou, a ponte que ele inferiu. A correção é anterior à escrita — montar, antes de cada sessão, um pacote fechado com tudo já decidido, para que a sessão seja só prosa em volta de artefatos aprovados.

O Pacote de v0 tem sete itens e é montado pelo modelo intermediário, nunca pelo modelo que escreve:

1. **Fichas do arsenal citadas por aquele capítulo**, verbatim, só elas. Definição de método nunca é reescrita: é colada.
2. **A SAÍDA real do corpus** daquele capítulo — transcrição bruta, PNG do plot, os números que aparecem no texto.
3. **As duas mensagens-âncora**, escolhidas por você entre quatro candidatas antes da sessão. Elas são o canal dos negritos; decidi-las depois é escrever no escuro.
4. **O slot de figura**: qual frame, a legenda afirmativa proposta e o alt-text em ≤140 caracteres.
5. **O último parágrafo aprovado do capítulo anterior** — é o que fecha a ponte.
6. **O Context Block do livro** (≤300 tokens), gerado pela `book-context-block` a cada capítulo aprovado.
7. **As linhas do Banco de Campo autorizadas** para aquele capítulo — zero, uma ou duas. Fora dali, primeira pessoa é proibida.

Fecha o pacote uma linha só: **o contrato do capítulo** — o que o leitor sabe no fim que não sabia no começo. Se essa frase não couber em uma linha, o capítulo não está pronto para ser escrito.

### 5.2 Congelar o conjunto-âncora e distribuí-lo pelos quatro canais

Antes do capítulo 1, escreva de 8 a 15 proposições que alguém que entendeu o livro obrigatoriamente diria. Esse conjunto congela e não se mexe — é contra ele que o parecer editorial vai medir recall e FRC de cada canal.

Depois, distribua: cada proposição precisa ser recuperável por **pelo menos dois** dos quatro canais.

| Canal | Como carrega a âncora | Teste |
|---|---|---|
| Negritos | 2 mensagens-âncora por capítulo × 7 = 14 frases | Lidas em sequência, formam um resumo útil do método. Se não formam, as frases estão erradas — não a regra. |
| Imagens | 8 legendas afirmativas + 8 figuras numeradas | As legendas sozinhas ensinam o método. |
| Prompts | os 7 prompts do Simulador | Um leitor que só lê as caixas de prompt reconstrói a cadeia. |
| Prefixo 10% | Prefácio + Antes de começar + parte da Introdução | Produto nomeado antes de 60% da amostra; corte cai em valor, não em contexto. |

Isso é uma sessão de trabalho, e é a de maior retorno do projeto inteiro.

### 5.3 As doze sessões

Mantidas do ROTEIRO v1, com os patches deste documento marcados em negrito.

| # | Sessão | Conteúdo | Patch v2 |
|---|---|---|---|
| E1 | Prefácio + Antes de começar | parágrafo industrial (§A24+§A25+§A30); nota do autor | **+ frase de dogfooding; ordem do front matter do v131** |
| E2 | Introdução | timeline com o terceiro ato τ³; Figura B executiva; tabela "o que você vai construir"; estático × dinâmico (§A29) | teto duro de 4-5 páginas |
| E3 | Cap 1 · O teste que passa em tudo | cena das 22h17; §A24b; Prompt 1 + SAÍDA | **+ 1 passagem de comprador sênior (P6)** |
| E4 | Cap 2 · Os cinco jeitos de quebrar | abertura Clear; benevolence bias §A27 + §A23 + §A11; plot de barras | — |
| E5 | Cap 3 · A persona que não desmonta | abertura Sinek; trio de specs §A10/§A17/§A15 + §A16; radar + drift | **+ parágrafo da taxonomia das duas linhas (§A39)** |
| E6 | Cap 4 · O painel que discorda | abertura Clear; §A1 cobertura > densidade; §A14 verbatim; Figura A | — |
| E7 | Cap 5 · As três perguntas | abertura Sinek; canon do Juiz completo — duas filosofias §A4, vieses e mitigações §A21, segundo LLM §A24a | **+ Matriz de Adaptação (2 pp.)** |
| E8 | Cap 6 · Da falha ao conserto | abertura Clear; §A24c; antes/depois + heatmap pass^k | — |
| E9 | Cap 7 · O Simulador | abertura Sinek; §A25; fronteira dupla A2A+voz; mercado §A31; dashboard | **+ linha "menor nota entre personas"; gatilho de compartilhamento do dashboard** |
| E10 | Apêndice · O Laboratório | blocos 1–7 + plots.py, cada bloco com SAÍDA real | — |
| E11 | O que o método não entrega + Notas + Sobre o Autor + Agradecimentos | cinco aprendizados; referências conferidas | **+ sexto aprendizado (§A41); Sobre o Autor a partir do v3** |
| E12 | Passada de costura | pontes, ordem canônica das três métricas, faixas 1–7, fechamentos | **+ leitura dos quatro canais contra o conjunto-âncora** |

### 5.4 O protocolo de sessão — sete tempos, sempre os mesmos

1. **Pré-condição** — o Pacote de v0 está montado. Sem ele, a sessão não começa. Esta é a trava, não uma recomendação.
2. **Rascunho** no esqueleto resultado-first: conceito curto → caixa PROMPT/CÓDIGO → caixa RESULTADO → leitura em 2-3 parágrafos → faixa "Sua vez" → linha do Laboratório → faixa de progresso.
3. **Abertura** conforme o mapa: Sinek nos ímpares, Clear nos pares. Teoria dentro da história, um conceito por vez, definição de método sempre verbatim do arsenal.
4. **Paralelismo** conferido em toda enumeração de dois itens ou mais.
5. **Sweep da lista de caça** → tabela `padrão | trecho | reescrita` para todo match do balde BLOQUEIO; balde REVISAR é decisão humana item a item.
6. **Gates** G1–G10 + gate de domínio (5 critérios) + teste de valor.
7. **Proposta antes de aplicar** → seu "siga" → docx (template, ordem decrescente de offset, delta de parágrafos justificado, PDF das páginas tocadas).

**Regra da passada única:** um capítulo é escrito em uma sessão, do começo ao fim. Retomar capítulo pela metade em sessão nova custa mais contexto do que reescrever, e produz costura visível.

### 5.5 Os gates, na ordem em que reprovam

| Gate | O que mede | Como roda |
|---|---|---|
| G1 | lista de caça | `hunt_g1_marcas.py` — três baldes (patch 1.5) |
| G2 | dado do arsenal citado letra por letra | conferência manual contra a ficha |
| G3 | abre por história, nunca por definição | leitura |
| G4 | todo PROMPT/CÓDIGO seguido de SAÍDA real | grep de caixa órfã |
| G5 | a peça se encaixa: declara o que ingere e o que entrega | leitura |
| G6 | fecha em descoberta, sem `?` na última frase | heurística do script |
| G7 | "Sua vez" executável em uma sessão, no domínio do leitor | leitura |
| G8 | reforça ≥1 conceito-âncora com mecanismo + fonte | leitura |
| **G9 (novo)** | tipografia: exatamente 2 mensagens-âncora, nenhuma em caixa; itálico nos quatro usos; zero negrito em dado ou nome de Capacidade | contagem de runs `<w:b/>` e `<w:i/>` fora de heading |
| **G10 (ex-G9)** | ecos verbatim | `hunt_g2_ecos.py --whitelist whitelist_ecos_ps.txt` |
| Domínio | 5 critérios de eng sênior de evals | roda no código + capítulo |

Depois do manuscrito fechado: `diretor-editorial-big-five` (três etapas, quatro canais, controle negativo) → Protocolo Buck com persona de head de engenharia cético → `amostra-kindle` → `arte-kdp`.

---

## 6. EXCALIDRAW GENERATION — passo a passo

### 6.1 A gramática visual, travada antes do primeiro traço

Medi o `Figuras_PT.excalidraw` do PE. Os números abaixo saem dessa medição e evitam repetir dois problemas que o livro 1 pagou.

**O problema que os números resolvem.** A escala é única para todas as figuras: `escala = min(TETO_LARG / maior_largura, TETO_ALT / maior_altura)`. Quem manda é o desenho mais largo e o mais alto do arquivo inteiro. No PE, a caixa desenhada maior tem 812 unidades de largura e outra tem 596 de altura — **as duas vazam do frame de 700×420**. Com `TETO_LARG` 3,40" e `TETO_ALT` 2,20", isso põe o texto de 20px em cerca de 5,3 pt impressos. Legível na tela, apertado no papel.

**A regra que corrige, e é simples:** *o desenho não pode vazar do frame.* Se toda caixa desenhada couber em 700×420, a escala sobe para ~0,00486 "/unidade e a régua tipográfica fica assim:

| Tamanho no Excalidraw | Sai impresso | Uso |
|---|---|---|
| 24 px | 8,4 pt | rótulo dentro da figura |
| 32 px | 11,2 pt | título de bloco |
| 40 px | 14,0 pt | número, selo, destaque único |

**As constantes:**

| Item | Valor | Por quê |
|---|---|---|
| Frame | 700 × 420, idêntico em todos | o mesmo do PE; conteúdo nunca vaza |
| Largura máxima desenhada | 700 u | acima disso, a letra de **todas** as figuras encolhe |
| Altura máxima desenhada | 420 u | idem |
| Régua de fonte | 24 / 32 / 40 px, e só | nunca redimensionar elemento de texto à mão |
| Cor | preto + acento #0F4C5C em um ou dois elementos | paleta petróleo do livro 2 |
| `TETO_LARG` / `TETO_ALT` / `DPI` | 3,40" / 2,20" / 400 | padrão da skill; 400 dá folga sobre os 300 da KDP |
| `ESCALA_PADRAO` | travar após a primeira diagramação completa | senão, uma figura nova maior repagina o livro inteiro |

**Por que a régua de fonte é regra e não sugestão:** o arquivo do PE tem cerca de trinta tamanhos fracionários (18,4 · 30,2 · 46,6 · 51,5 px), rastro de texto redimensionado à mão junto com a forma. Isso quebra a checagem "20px = X pt em todas", que é justamente a prova de que a letra ficou uniforme. Para redimensionar, escale o conteúdo do frame inteiro — nunca a caixa de texto sozinha.

### 6.2 As 26 figuras

| Grupo | Quantidade | Nome do frame | Legenda no docx |
|---|---|---|---|
| Vinhetas de abertura | 8 (V0–V7) | `V0_teste_x_mundo` … `V7_simulador_montado` | sem legenda |
| Figuras numeradas | 9 (F1, F1b, F2–F8) | `Fig_1_dois_caminhos` … `Fig_8_dashboard` | legenda afirmativa obrigatória |
| Desenhos de arquitetura | 2 (Figura A técnica, Figura B executiva) | `Fig_A_orquestrador`, `Fig_B_tres_caixas` | legenda afirmativa obrigatória |
| Faixas de progresso | 7 (P1–P7) | `Faixa_1_de_7` … `Faixa_7_de_7` | sem legenda |

Os rótulos internos vêm do mapa de figuras do `LIVRO_ESTRUTURA_COMPLETA_v1` §3, transcritos em caixa alta, em português, sem tradução nem paráfrase. As oito legendas precisam ser reescritas no padrão afirmativo (achado 1.2) antes de desenhar — a legenda decide o desenho, não o contrário.

### 6.3 O pipeline, em sete passos

1. **Travar a gramática** (§6.1) e criar a cena base com os 26 frames vazios, nomeados, todos 700×420, em grade de 4 colunas. Trabalho determinístico.
2. **Escrever as 26 fichas de figura** — uma linha cada: o que a figura afirma, quais rótulos aparecem verbatim, onde entra o acento. É o roteiro do desenho; sem ele, sai enfeite.
3. **Gerar a cena inteira em um único lote.** Um frame por figura, tudo na mesma passada, para o traço e o espaçamento não derivarem entre capítulos. É a mesma razão pela qual o plano antigo mandava gerar todas as figuras na mesma sessão do Gemini.
4. **Passada humana.** Layout gerado por modelo sai simétrico demais e legível de menos. Você abre no Excalidraw, empurra o que estiver frouxo, corta o que estiver decorativo. Essa passada é o que separa figura de livro de figura de slide — e é curta, porque a estrutura já está lá.
5. **Exportar e parear:** `exc2livro.py svg` → `exc2livro.py mapa` (roda sempre antes, mostra o pareamento sem escrever nada) → `exc2livro.py aplicar`. Pareamento abaixo de 0,34 para o script; corrija com `mapa.json` em vez de renomear alt-text.
6. **Conferir a saída:** a linha `texto de 24px = X pt em todas` tem que aparecer com um valor único. Se variar, a escala quebrou.
7. **Auditar:** `arte-kdp auditar` no build Kindle e `arte-kdp auditar --tinta` no impresso. A caixa de prompt em #1E1E1E é o suspeito de sempre — no PE, sete páginas marcaram de 20% a 32% de cobertura de tinta contra 5,9% de média, e foram invertidas só no build impresso.

### 6.4 Os plots — a segunda linguagem

Sete PNGs, direto do matplotlib do corpus, 300 dpi, paleta petróleo e cinza, sem grade pesada, sem retoque: radar de traços da persona, mapa de divergência do painel, barras das três métricas, antes/depois do fix, heatmap pass^k, dashboard do gate — mais o que a Matriz de Adaptação exigir se a §2.3 for aprovada.

Duas regras que não se negociam: **plot nenhum é decorativo** — todo gráfico impresso nasceu de uma execução arquivada que o leitor reproduz pelo Apêndice; e **as duas linguagens nunca se misturam na mesma figura**.

### 6.5 Os erros que já custaram rodada, para não custarem de novo

- Legenda dentro do desenho. No Kindle com narração automática a imagem é excluída e só a legenda de texto sobrevive; legenda desenhada vira silêncio, e leitor de tela não lê. No PE, 25 legendas tiveram de ser extraídas de volta depois do parecer.
- `srcRect` no XML do Word. Corta a imagem antes de exibir e a checagem de proporção não pega, porque o recorte fica entre a caixa e o arquivo. O script remove em toda figura que toca — confira que removeu.
- Tracejado que vira linha sólida e ponta de seta que some: são as três coisas que o `roughjs` não devolve e a skill reanexa. Se uma seta de dois sentidos aparecer com uma ponta só, é isso.
- Pareamento por nome de arquivo. `image7.png` muda de posição entre versões e já trocou figura de lugar. O pareamento é por alt-text, sempre.

---

## 7. ROTEAMENTO DE MODELOS E ECONOMIA DE TOKEN

### 7.1 Os cinco princípios

1. **O modelo mais barato é nenhum modelo.** Contagem de parágrafos, comprimento de alt-text, DPI efetivo, cobertura de tinta, sweep de regex, delta de validação: tudo isso é Python. Se um script resolve, nenhum modelo roda.
2. **Nunca entregue o livro inteiro a um modelo caro.** O modelo que escreve recebe o Pacote de v0 (§5.1) e o Context Block de 300 tokens. Nada além.
3. **Trabalho determinístico não sobe de faixa.** Montar pacote, executar Colab, gerar JSON de cena, cirurgia de docx, reordenar front matter: faixa intermediária.
4. **O juiz é de outra família que o escritor.** Não é economia, é o canon do próprio livro — mitigação de *self-enhancement bias* (§A21). O avaliador de leitura roda em Gemini Flash, que também é a opção barata.
5. **Lote único onde a consistência importa.** As 26 figuras numa passada; os sete plots numa execução; as 14 mensagens-âncora numa sessão. Fragmentar é pagar duas vezes e ainda perder uniformidade.

### 7.2 A tabela

| Etapa | Modelo | Por que ele | O que entra no contexto |
|---|---|---|---|
| F0 — as 12 decisões | Opus 5 | decisão editorial com você na mesa; é curto e vale o melhor julgamento | os documentos do projeto, uma vez |
| F1 — verificação do arsenal com busca | **Fable 5** | muitas fontes primárias abertas em sequência, com julgamento sobre o que é citável; é a etapa onde erro custa credibilidade do livro | lista de fichas pendentes, uma por vez |
| F1 — `MASTER_TEMPLATE.docx` | Sonnet 5 | cirurgia de XML determinística | template v49 + paleta |
| F2 — Laboratório e corpus | Sonnet 5 | escrever, rodar e arquivar código; iteração alta, criatividade baixa | notebook + seed + agente-exemplo |
| F2 — os 7 prompts em 3 perfis | Sonnet 5 executa · Opus 5 especifica | o prompt é produto: quem o desenha é o modelo caro, quem o roda 21 vezes não | spec do prompt |
| F3 — gate de valor | Opus 5 | julgamento de engenheiro sênior de evals | corpus + os 5 critérios |
| **Conjunto-âncora e canais (§5.2)** | Opus 5 | maior retorno por token do projeto inteiro | estrutura + gabarito |
| Pacote de v0 (12×) | Sonnet 5 | montagem mecânica a partir de arquivos existentes | arsenal + corpus + mapa |
| **E1–E12 — a prosa** | Opus 5 | é a voz; não há substituto | só o Pacote de v0 |
| Cap 1 (sessão E3) | **Fable 5** | a skill congela depois do capítulo 1: é o único artefato que define todos os outros | Pacote de v0 do Cap 1 |
| Gates G1, G6, G9, G10 | script Python | regex e contagem de runs | texto extraído |
| Gates G2–G5, G7, G8 | Sonnet 5 | leitura estruturada contra checklist | capítulo + fichas |
| `book-editor-humanizer` | Opus 5 | reescrita de frase é trabalho de voz | capítulo + Context Block |
| Evals de leitura (F5) | **Gemini Flash** | outra família que a de quem escreveu (§A21) e a opção barata | capítulo + rubrica |
| Cena Excalidraw (26 frames) | Sonnet 5 | JSON estruturado, lote único | fichas de figura + gramática |
| Plots (7) | Sonnet 5 | matplotlib a partir do corpus | dados arquivados |
| Montagem do docx | Sonnet 5 | unpack → edit → pack → validate | manuscrito + figuras |
| `arte-kdp`, `amostra-kindle` | script + Sonnet 5 | medição, depois leitura do resultado | docx |
| Parecer big five | **Fable 5** | quatro canais, controle negativo, FRC; é a auditoria que decide publicar | manuscrito completo |
| Protocolo Buck | Opus 5 | leitura sintética integral por persona de comprador | manuscrito + persona |
| Context Block | Haiku 4.5 | compressão para ≤300 tokens, tarefa trivial | capítulo aprovado |

### 7.3 Onde o token vaza, na prática

- **Reler o manuscrito a cada capítulo.** Não faça. O Context Block existe exatamente para isso, e cabe em 300 tokens.
- **Colar o arsenal inteiro.** São 29 KB. Cada capítulo cita de três a seis fichas. Cole as fichas.
- **Iterar prosa no modelo caro por gosto.** Iteração por evidência de gate: o script apontou, você corrige. Iteração por gosto no meio do livro é o que a regra de congelamento da skill existe para impedir.
- **Regerar em vez de operar.** Cirurgia no docx, sempre — ordem decrescente de offset, delta de parágrafos justificado, validação contra o original. Regeneração perde estilo e custa a rodada inteira.
- **Deixar a skill fora do prefixo estável.** Skill + gramática visual + Context Block são o mesmo bloco em todas as sessões: mantenha na mesma posição para o cache funcionar.

---

## 8. ORDEM DE EXECUÇÃO

Percursos antes de prosa, estrutura antes de frase, produto antes das duas. Polir frase de capítulo que vai mudar é trabalho jogado fora.

```
F0    12 decisões + patch da skill + congelamento          1 sessão
F0.5  conjunto-âncora congelado + distribuição nos canais   1 sessão
F1    arsenal N1 ∥ MASTER_TEMPLATE                          paralelo
F2    Laboratório roda · 7 prompts × 3 perfis · corpus       a trava do "ultra convincente"
F3    gate de valor — você toma 1 decisão real com ele       reprova → conserta o produto
F4    E1…E12, um capítulo por sessão                         Pacote de v0 obrigatório
F5    evals de leitura (Gemini Flash)                        eng cético reprova = prioridade máxima
F6    26 frames em lote → passada humana → exc2livro → arte-kdp
F7    montagem · amostra-kindle · big five · Buck · KDP
PÓS   Context Block da linha · dogfooding público · retrospectiva para o livro 3
```

O gate mais importante continua sendo o F3, e ele não é sobre o texto: se o Simulador não passar no teste de "eu comitaria isso no CI do meu time", nenhuma prosa salva o livro. E se passar, quase nenhuma prosa o estraga.
