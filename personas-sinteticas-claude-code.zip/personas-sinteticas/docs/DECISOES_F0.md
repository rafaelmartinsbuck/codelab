# DECISÕES F0 — preencher ANTES de qualquer escrita
Este arquivo é lido pelo Claude Code e nunca escrito por ele. Item em branco = escrita bloqueada.

| # | Decisão | Valor travado |
|---|---|---|
| 1 | Pergunta canônica da Resolutividade | `[PREENCHER: "voltaria amanhã?" ou "recomendaria?"]` |
| 2 | Nomes dos 5 arquétipos em português | `[PREENCHER: 1. … 2. … 3. … 4. … 5. …]` |
| 3 | Texto da nota do autor | `[PREENCHER]` |
| 4 | Paleta | #0F4C5C petróleo · cinza #4A4A4A · fundo branco |
| 5 | Seed do corpus | `[PREENCHER: conversa real anonimizada OU composto ficcional declarado]` |
| 6 | Mecânica do Ensaio Manual | `[PREENCHER: duas janelas / janela única; capítulo onde entra]` |
| 7 | Banco de Campo aprovado | ver `BANCO_DE_CAMPO.md` |
| 8 | Estrutura | 7 capítulos + Apêndice — TRAVADO |
| 9 | Escopo da multipersona | `[PREENCHER: aprovada / recusada — se aprovada, Cap 3 §A39 + Matriz de Adaptação no Cap 5 + linha do dashboard no Cap 7 + 6º aprendizado]` |
| 10 | Divisão público/privado | público = dashboard e gate · privado = tabela de falhas — TRAVADO |
| 11 | Gramática visual | frame 700×420, régua 24/32/40 px, desenho não vaza do frame — TRAVADO |
| 12 | Conjunto-âncora | ver `CONJUNTO_ANCORA.md` |
