# ADENDO v1.3 — Subtítulo novo, storytelling atualizado e aprendizados finais
**Anexa-se ao `LIVRO_ESTRUTURA_COMPLETA_v1.md` (que permanece válido no que este adendo não sobrescreve). Fontes novas: ARSENAL v2 (§A24–§A31).**

---

## 1. SUBTÍTULO OFICIAL (decisão travada — fecha o item 1 da P0)

**PERSONAS SINTÉTICAS**
***Encontre as falhas antes dos seus usuários — e entregue sistemas de IA que escalam.***

Consequências em cascata (executar na F1, com grep):
1. **Capa/folha de rosto do gabarito** — substituir o subtítulo antigo ("Teste seu agente de IA com usuários que não existem, antes que os que existem o derrubem").
2. **Cabeçalho do ARSENAL e da SKILL** — atualizar a linha de título de trabalho.
3. **O subtítulo antigo NÃO morre:** vira a **primeira frase do Prefácio reescrita como ideia** (não verbatim) e candidata a tagline de contracapa — junto com o aforismo nº 3 da tabela ("O usuário que não existe encontra o erro que o real não perdoa"), que segue reservado para orelha/epígrafe.
4. **Gramática da promessa (guia de toda a prosa):** o subtítulo tem dois verbos e o livro tem duas metades — *encontrar falhas* (Caps 1–5: caso real → arquétipos → spec → painel → juiz) e *escalar com confiança* (Caps 6–7: loop documentado → gate em ritual/CI). Todo fechamento de capítulo aponta para uma das duas metades.
5. **Gate AB da capa:** sustentado por §A25 (35.000 simulações/dia como rotina industrial), §A24 (evals em CI como primeira linha de defesa) e §A2 (personas em escala). Frase-guarda do Cap 7: *o que escala não é o agente sozinho; é o par agente+gate*.

## 2. STORYTELLING — o que muda com a pesquisa de julho/2026

### 2.1 Prefácio (upgrade de autoridade)
Mantém a cena dos dois times. Ganha um parágrafo novo de contexto industrial, com três fatos em uma respiração: a Anthropic publicou que evals de agente conversacional exigem um segundo LLM simulando o usuário (§A24a); os clientes da Sierra rodam mais de 35 mil simulações por dia antes de qualquer mudança chegar a um cliente (§A25a); e a primeira competição de teste de LLM da ICSE julgou as ferramentas pela diversidade das falhas que expõem (§A30). Batida: **o que este livro ensina deixou de ser técnica de laboratório em 2025 — virou rotina de quem opera agente em escala. O que continua trancado é o método em formato que um time normal executa numa terça-feira. Este livro destranca.**

### 2.2 Introdução (a linha do tempo ganha o terceiro ato)
A timeline post-it → planilha → agente (§A13) ganha o fecho 2024-26: a linha da engenharia (Eckert 1997 → Schatzmann 2007 → τ-bench 2024, §A20) agora termina em **τ² (o usuário simulado age, 2025) → τ³ (o usuário simulado FALA e interrompe, 2026, §A26)**. Frase-âncora nova da Introdução: *"a persona passou quarenta anos muda na parede; em 2023 começou a responder; em 2026 já interrompe o agente no meio da frase."* A figura F1b (timeline) ganha o terceiro marco (ver prompt G-03 no roteiro).

### 2.3 Capítulo 1 (a validação que faltava)
A Capacidade 1 (conversa real ruim → primeiro caso de teste) agora abre citando que este é literalmente o **passo 1 do guia oficial de evals da Anthropic**: comece pelo bug tracker e pela fila de suporte; converta falhas reportadas em casos de teste (§A24b). O leitor não está fazendo um truque de autor — está executando a prática recomendada pelo laboratório que constrói o Claude, em 10 minutos, sem engenheiro.

### 2.4 Capítulo 2 (o vilão ganha nome científico)
O fenômeno "persona ingênua não estressa nada" agora tem três camadas com fonte: o assistente é sicofanta por treino (§A23), o usuário sintético ingênuo também agrada (§A11), e o campo deu nome ao caso do simulador — **benevolence bias** (§A27). A cena de abertura Clear ganha o remate: *pedir "seja um usuário difícil" produz teatro; a dificuldade precisa ser especificada — e é isso que os cinco arquétipos são.*

### 2.5 Capítulo 4 (cobertura virou critério de competição)
Além de DeepMind (§A1), citar em uma linha que a competição DeepTest/ICSE 2026 avaliou ferramentas de teste por **efetividade E diversidade das falhas** (§A30) — cobertura deixou de ser tese do livro e virou régua pública de julgamento.

### 2.6 Capítulo 7 (a seção Fronteira dobra de tamanho — 1 página ainda)
Fronteira agora tem DOIS horizontes em meia página cada: (a) **o Simulador como serviço** (A2A, §A19 — inalterado); (b) **o Simulador que fala** (τ³/voz, §A26): os mesmos arquétipos do Cap 2 já existem como parâmetros configuráveis — paciência, interruptividade, aversão a silêncio — no benchmark líder; quem tem a spec em texto está a um passo da voz. Fecho da Fronteira: *o formato muda; a spec de comportamento é o que sobrevive.*
Adicionar 1 parágrafo de mercado (§A31): a categoria virou feature de plataforma em 2025-26; o leitor sai do livro com o método portável — que funciona também como critério para avaliar qualquer plataforma que prometa isso pronto.

### 2.7 "O que o método não entrega" (os aprendizados finais — seção reescrita)
A seção de honestidade sobe de nível: deixa de ser ressalva e vira **os cinco aprendizados da elaboração do livro**, cada um com fonte e com a resposta prática embutida:
1. **Simulador não é gente.** O campo mediu: usuários simulados divergem de humanos em avaliações agênticas (Lost in Simulation, §A28b). Resposta do método: o Simulador é a fatia barata e rápida do Queijo Suíço (§A24d) — ele não substitui as outras camadas; ele impede que a falha óbvia chegue nelas.
2. **O gap fecha com grounding, não com prompt melhor.** A direção do campo é ancorar o simulador em dado real (RealUser-Sim, §A28c) — exatamente a regra de ouro do livro: todo traço cita o trecho da conversa real. A Capacidade 1 vem antes de todas por isso.
3. **Diversidade se especifica, não se pede.** Benevolence bias (§A27) + mode collapse (§A1): "gere usuários difíceis" produz teatro cooperativo. Cobertura é decisão de engenharia.
4. **Consistência é a métrica adulta.** pass^k (§A4): passar uma vez é sorte; o gate exige passar sempre.
5. **O teste não termina no deploy.** Evals em CI são a primeira camada; monitoração de produção pega o drift que a simulação não previu (§A24e). O ritual quinzenal do Cap 7 existe para isso.
Fecho da seção (e do livro, antes das referências): *o método não promete um agente que nunca falha; promete que nenhuma falha barata de encontrar chegue ao seu usuário antes de chegar a você — e essa é a diferença entre operar um sistema de IA e torcer por ele.*

## 3. ATUALIZAÇÕES DE MAPA (delta sobre a v1)
- **Tabela de capítulos:** Cap 1 soma §A24b às fontes; Cap 2 soma §A27; Cap 4 soma §A30; Cap 7 soma §A25, §A26, §A24d, §A31; "O que o método não entrega" passa a referenciar §A28 (a/b/c) + §A24d.
- **Notas e Referências do gabarito:** acrescentar entradas 20–26 (Anthropic Demystifying Evals; Sierra Simulations; Sierra τ³; arXiv 2604.21480; arXiv 2601.17087; arXiv 2605.20204; arXiv 2604.12615; arXiv 2507.21504).
- **Whitelist do hunt_g2:** adicionar os refrões deliberados novos — "a persona passou quarenta anos muda", "encontre as falhas antes dos seus usuários", "o par agente+gate", "fatia do Queijo Suíço" (ecos estruturais intencionais).
- **Glossário (patch na skill quando ela descongelar — ou já na F0, antes do congelamento):** adicionar **benevolence bias** (definição §A27, sempre com o nome em inglês na primeira menção + tradução funcional "viés de benevolência") e **Queijo Suíço** (§A24d). O termo "siconfância" continua para o assistente; benevolence bias é do simulador.
- **P0 recalculada:** item 1 (título/subtítulo) TRAVADO por este adendo. Restam: pergunta canônica da Resolutividade · nomes dos 5 arquétipos em PT · texto exato da nota do autor · paleta (default verde-petróleo segue).
