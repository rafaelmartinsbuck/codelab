# PERSONAS SINTÉTICAS — Estrutura Completa v1
**Título de trabalho:** *Personas Sintéticas — Teste seu agente de IA com usuários que não existem, antes que os que existem o derrubem*
**Fórmula PE aplicada:** 7 capítulos · cada um produz UMA Capacidade · o Cap 7 monta tudo · o prompt é o produto · código opcional para quem codifica · leitor-alvo: PM, executivo, vendedor, dados e engenharia — a MESMA página serve a todos porque o prompt faz o trabalho técnico.

---

## 1. A CONSTRUÇÃO (o arco em 7 capítulos)

A lógica é a do PE: cada capítulo entrega uma peça que encaixa na anterior, e o leitor termina com um produto instalado — **o Simulador**: um painel de usuários sintéticos que estressa o agente/atendimento/produto dele, mede com três perguntas e melhora em ciclos documentados.

| Cap | Título | Capacidade produzida | O que o leitor descobre | Fontes verificadas (ARSENAL) |
|---|---|---|---|---|
| 1 | O teste que passa em tudo | **CAPACIDADE 1 — O Caso Real**: a persona mínima extraída de UMA conversa real que deu errado | O agente dele passa no teste limpo e falha com gente; acurácia em input limpo mede o teste, não o agente | §A4 τ-bench/pass^k · §A11 NN/g |
| 2 | Os cinco jeitos de quebrar | **CAPACIDADE 2 — O Arquétipo**: os 5 arquétipos comportamentais adaptados ao domínio dele | Cada arquétipo quebra o agente de um jeito diferente; demografia não quebra nada, comportamento quebra | §A5 Impatient users · §A4 |
| 3 | A persona que não desmonta | **CAPACIDADE 3 — A Spec**: a persona completa como especificação de comportamento (identidade + réguas + condição de saída), anti-drift | Persona de produção se escreve como o system prompt do Claude: cada regra específica parece um incidente corrigido | §A10 Anthropic/Willison · §A9 drift |
| 4 | O painel que discorda | **CAPACIDADE 4 — O Painel**: 5 personas que cobrem failure modes DISTINTOS | Cobertura vence média: o outlier derruba a produção, não o usuário provável; pedir "gere personas diversas" produz clones | §A1 DeepMind · §A2 PersonaHub/Nemotron |
| 5 | As três perguntas | **CAPACIDADE 5 — O Juiz**: o avaliador de 3 métricas com evidência | Duas métricas são padrão da indústria (Resolução de Intenção, Aderência à Tarefa); a terceira — Resolutividade — é a que ninguém mede e a que decide se o cliente volta | §A3 Azure AI Foundry |
| 6 | Da falha ao conserto | **CAPACIDADE 6 — O Change Log**: o loop diagnóstico→fix→re-teste documentado | Melhoria sem diagnóstico documentado é superstição; um fix por vez, antes/depois registrado | §A3 · §A7 |
| 7 | O Simulador | **CAPACIDADE 7 — Ativação**: o comando completo (para quem não codifica) + o notebook completo (para quem codifica) + o dashboard de 1 página (para quem decide) + ritual quinzenal | As 7 peças viram um sistema; e o que o método NÃO entrega (gap sim2real, com fonte) | Composição · §A9 · §A6 |

**Cadeia (cadeado de valor):** conversa real → persona mínima → arquétipo → spec → painel → juiz → loop → Simulador. Cada prompt começa com "Com base na CAPACIDADE anterior colada abaixo". Sem a conversa acumulada, o prompt isolado é esqueleto — incopiável, como no PE.

**Como o mesmo livro serve PM, executivo, vendedor, dados e engenharia:** todo capítulo tem UM exercício (prompt, 15-20 min, celular serve) que qualquer perfil executa — porque a IA faz a parte técnica. Ao fim do capítulo, um bloco curto "**Para quem codifica**" (código particionado, ≤25 linhas, testado) constrói a mesma peça em Python. Quem não codifica pula o bloco sem perder nada; quem codifica sai com o notebook. O Cap 7 entrega os dois caminhos completos + a página que o executivo lê sem tocar em nada.

---

## 2. PROTOCOLO OPUS POR CAPÍTULO (para não cair em NENHUM problema do PE)

Cada problema que corrigimos no PE vira aqui uma pré-condição ou um gate. Ordem de execução por capítulo (uma sessão cada):

**Pré-condições (bloqueiam o início):**
1. Ficha do arsenal aberta ao lado — o capítulo só cita o que tem ficha, letra por letra (mata a classe F1: WEF/Gallup/Apollo).
2. CORPUS do capítulo rodado — o prompt do capítulo já foi executado com dados reais de teste; toda cena de output é transcrição condensada do corpus (mata o "vinte vs. quinze minutos" e os mocks ilegíveis).
3. Slots de figura do capítulo confirmados no mapa (§3 abaixo) — o texto é escrito sabendo onde a vinheta e a figura entram (mata a refação de figuras).

**Escrita:**
4. Abertura alternada Sinek (ímpares) / Clear (pares); teoria DENTRO da história; um conceito por vez estilo Ng, código/prompt logo após o conceito.
5. Cena de IA: narrada em prosa, 2-3 parágrafos, no máximo UMA fala citada — nunca despejo Entrada/Saída (o padrão que consolidamos no v48).
6. **Checagem de paralelismo:** toda enumeração de 2+ itens tem itens do MESMO peso (a inconsistência exata que o Rafael flagou na Introdução do PE). Se um item pede exemplo, todos pedem — ou nenhum.

**Gates antes de propor (nesta ordem):**
7. Sweep da LISTA DE CAÇA (grep-ável): antíteses de reversão, "não se trata de", clichês de IA, guru-speak, "jornada", pergunta retórica no fechamento → tabela `padrão | trecho | reescrita` para todo match.
8. G2-G8 da skill (fonte com ficha; abre por cena; prompt cabe na página; encaixa na cadeia; fecha em descoberta; desafio executável; conceito-âncora com mecanismo).
9. Gate de domínio (eng sênior de evals): reprodutível, falha visível ANTES do fix, métrica que se move, cobertura não volume, honesto.
10. `book-editor-humanizer` → `guardian-conteudo` → proposta ao Rafael (propose-before-apply) → aprovação "siga" → só então entra no docx (template v49, ordem decrescente, pack --original, delta justificado, PDF das páginas tocadas).

**Regra de congelamento:** skill e mapa congelam após o Cap 1 aprovado; patch só por evidência de falha recorrente nos evals — nunca ajuste de gosto no meio.

---

## 3. MAPA DE FIGURAS (o livro para quem só olha)

Padrão hand-drawn da linha (bloco de estilo do PLANO_FIGURAS do PE). Vinhetas sem legenda; figuras didáticas numeradas; faixa de progresso ao fim de cada exercício. **Teste do arco:** lidas em sequência, as figuras contam o livro sem uma palavra de prosa:

> um robô atende uma fila de usuários de papel idênticos e ganha troféu; um usuário de verdade amassa o papel → cinco caras diferentes quebram o robô de cinco jeitos → uma persona vira uma spec com regras → cinco personas discordando em painel → três perguntas medem a conversa → o ciclo falha-conserto-re-teste gira → o Simulador completo roda antes da porta da produção.

| # | Tipo | Onde | Descrição (prompt Gemini na fase de figuras) |
|---|---|---|---|
| V0 | vinheta | Prefácio | Robô-agente recebendo troféu 'APROVADO' diante de fila de bonecos de papel idênticos; ao lado, um humano de verdade amassando um dos papéis. Rótulo: 'O TESTE × O MUNDO' |
| F1 | Figura 1 | Introdução | Dois caminhos: 'INPUT LIMPO → 100%' com selo, e 'USUÁRIO REAL → ?' com linha tremida. Legenda: *O teste que o agente passa e o teste que importa* |
| V1 | vinheta | Cap 1 | Lupa sobre UMA conversa de chat amassada; dentro da lente, uma silhueta de pessoa se formando. |
| F2 | Figura 2 | Cap 1 | A persona mínima: caixa com 3 andares 'QUEM · COMO · ABERTURA', seta saindo de um balão de chat real. Legenda: *De uma conversa real nasce o primeiro caso de teste* |
| V2 | vinheta | Cap 2 | Cinco rostos rabiscados em fila, cada um com um ícone: relógio (impaciente), interrogação dupla (troca de contexto), martelo (desafia política), espiral (descreve sintoma), porta (abandona). |
| F3 | Figura 3 | Cap 2 | Tabela desenhada: 5 arquétipos × 'COMO QUEBRA O AGENTE'. Legenda: *Cada arquétipo quebra de um jeito* |
| V3 | vinheta | Cap 3 | Persona derretendo no 'TURNO 2' vs. persona firme segurando um pergaminho de regras. |
| F4 | Figura 4 | Cap 3 | A spec em 3 blocos: 'IDENTIDADE · RÉGUAS DE COMPORTAMENTO · CONDIÇÃO DE SAÍDA'. Legenda: *Persona é especificação, não biografia* |
| V4 | vinheta | Cap 4 | Cinco balões de fala apontando para direções diferentes ao redor de um robô. |
| F5 | Figura 5 | Cap 4 | 'CLONES' (5 bonecos idênticos agrupados) vs. 'COBERTURA' (5 bonecos espalhados cobrindo o quadro). Legenda: *Volume não é cobertura* |
| V5 | vinheta | Cap 5 | Juiz de toga rabiscado com prancheta de 3 linhas. |
| F6 | Figura 6 | Cap 5 | As três perguntas empilhadas: 'ENTENDEU? · SEGUIU? · O USUÁRIO VOLTA?' — a terceira circulada. Legenda: *Duas métricas da indústria e a que falta nelas* |
| V6 | vinheta | Cap 6 | Engrenagem de 3 dentes: 'FALHA → CONSERTO → RE-TESTE', com um caderninho de log ao lado. |
| F7 | Figura 7 | Cap 6 | Linha de change log desenhada: '[TAG] hipótese → mudança → antes → depois'. Legenda: *Melhoria com assinatura* |
| V7 | vinheta | Cap 7 | O Simulador montado: painel de 5 personas + juiz + engrenagem, plugados por peças de quebra-cabeça, diante de uma porta 'PRODUÇÃO'. |
| F8 | Figura 8 | Cap 7 | O dashboard de 1 página rabiscado: 5 personas × 3 métricas com ✓/✗ e um selo 'GATE'. Legenda: *A página que o executivo lê* |
| P1-P7 | faixas | fim de cada exercício | 'N DE 7 CAPACIDADES' — quebra-cabeça de 7 peças, N preenchidas |

**Total: 24 assets** (1 vinheta de prefácio + 7 vinhetas + 8 figuras numeradas + 7 faixas + capa fora do escopo Gemini).

---

## 4. MAPA DE PROMPTS (a espinha do produto)

**Campos fixos (Cap 1, uma vez):** `Produto/agente: [___]` · `Quem usa: [___]` · `O risco que me tira o sono: [___]`
**Regra de ouro em todos:** a IA não inventa dado de gente — todo traço cita o trecho da fonte colada; sem evidência, entra como HIPÓTESE. Raciocínio antes da conclusão. Cabe numa página Kindle. Fecha com prescrição + gancho de 1 linha.

| Prompt | Ingere | Devolve (público / privado) |
|---|---|---|
| 1 — O Caso Real | campos fixos + UMA conversa real ruim (ou o relato da última reclamação) | por que deu errado em 3 linhas · PERSONA MÍNIMA (QUEM/COMO/ABERTURA com trecho-fonte) / 1 previsão testável + 1 pergunta para o time |
| 2 — O Arquétipo | CAPACIDADE 1 | os 5 arquétipos adaptados ao domínio · qual ataca primeiro o produto do leitor / o failure mode que ninguém do time listou |
| 3 — A Spec | CAPACIDADE 2 (arquétipo escolhido) | a persona completa: identidade (5 linhas) + 5 réguas observáveis + condição de saída / os 2 traços ainda HIPÓTESE |
| 4 — O Painel | CAPACIDADE 3 | 5 personas com mapa de divergência (onde discordam) · teste de redundância (nenhum failure mode repetido) / o buraco de cobertura restante |
| 5 — O Juiz | CAPACIDADE 4 + 1 conversa simulada | notas 1-5 com evidência nas 3 métricas: Resolução de Intenção · Aderência à Tarefa · Resolutividade / a pior métrica e a causa |
| 6 — O Loop | CAPACIDADE 5 | UM fix cirúrgico proposto → re-teste → linha de change log antes/depois / o que NÃO mudar junto |
| 7 — Ativação | CAPACIDADES 1-6 | o comando do Simulador com os dados do leitor embutidos + ritual quinzenal + dashboard de 1 página / limites declarados (sim2real) |

---

## 5. O CÓDIGO COMPLETO (Apêndice do Cap 7 — "Para quem codifica")

Referência mínima e funcional do Simulador em Python (provider-agnóstico; exemplo com a API da Anthropic). Particionado no livro em 6 blocos; aqui, íntegro:

```python
# ============================================================
# O SIMULADOR — referência mínima (Cap 7, bloco único)
# Requisitos: pip install anthropic  (ou adapte llm() ao seu provedor)
# ============================================================
import json, os
import anthropic

client = anthropic.Anthropic()  # ANTHROPIC_API_KEY no ambiente

def llm(system: str, messages: list, model: str = "claude-sonnet-4-6") -> str:
    """Uma chamada de chat. Troque este corpo para usar outro provedor."""
    r = client.messages.create(model=model, max_tokens=1000,
                               system=system, messages=messages)
    return r.content[0].text

# ---------- BLOCO 1: a spec da persona (Capacidade 3) ----------
# Preenchida pelo Prompt 3 com dados REAIS do leitor. Exemplo:
PERSONA_SPEC = {
  "nome": "cliente_impaciente_frete",
  "identidade": "Comprou há 6 dias; pedido consta 'em transporte' sem "
                "atualização há 72h; já abriu 1 chamado sem resposta.",
  "reguas": [
    "Abre descrevendo o SINTOMA ('meu pedido sumiu'), nunca o problema técnico.",
    "Se receber texto de política com mais de 3 linhas, responde 'só quero saber onde está'.",
    "Menciona cancelamento no 3º turno sem resposta objetiva.",
    "Aceita resolução se receber: local atual + prazo com data + 1 compensação.",
    "Nunca fornece número de pedido antes de ser perguntado explicitamente.",
  ],
  "condicao_saida": "Encerra satisfeita se as 3 condições da régua 4 aparecerem; "
                    "abandona ('vou cancelar') após 5 turnos sem elas.",
}

def persona_system(spec: dict) -> str:
    return (f"Você é um usuário real, não um assistente. {spec['identidade']}\n"
            f"Siga estas regras de comportamento à risca:\n- " +
            "\n- ".join(spec["reguas"]) +
            f"\nCondição de saída: {spec['condicao_saida']}\n"
            "Responda SEMPRE como esse usuário, em 1-3 frases, sem sair do papel.")

# ---------- BLOCO 2: a conversa simulada (Capacidades 3+4) ----------
def simula(agent_fn, spec: dict, max_turnos: int = 8) -> list:
    """agent_fn(historico)->str é o SEU agente (API, função, ou copie/cole manual)."""
    historico, msg_persona = [], "" 
    persona_msgs = [{"role": "user", "content": "Inicie a conversa como o usuário."}]
    for _ in range(max_turnos):
        msg_persona = llm(persona_system(spec), persona_msgs)
        historico.append({"role": "user", "content": msg_persona})
        resposta_agente = agent_fn(historico)
        historico.append({"role": "assistant", "content": resposta_agente})
        persona_msgs += [{"role": "assistant", "content": msg_persona},
                         {"role": "user", "content": resposta_agente}]
        if "ENCERRAR" in msg_persona.upper() or "cancelar" in msg_persona.lower():
            break
    return historico

# ---------- BLOCO 3: o juiz de três métricas (Capacidade 5) ----------
JUIZ = """Você é um avaliador de agentes. Leia a conversa e pontue 1-5,
citando o trecho-evidência de cada nota (sem evidência, nota máxima 3):
1. RESOLUCAO_DE_INTENCAO: o agente entendeu o que o usuário queria?
2. ADERENCIA_A_TAREFA: seguiu suas instruções e políticas?
3. RESOLUTIVIDADE: este usuário voltaria a usar o serviço amanhã?
Responda SÓ em JSON: {"resolucao_de_intencao": {"nota": n, "evidencia": "..."},
"aderencia_a_tarefa": {...}, "resolutividade": {...}}"""

def julga(historico: list) -> dict:
    convo = "\n".join(f"[{m['role']}] {m['content']}" for m in historico)
    bruto = llm(JUIZ, [{"role": "user", "content": convo}])
    return json.loads(bruto[bruto.find("{"): bruto.rfind("}") + 1])

# ---------- BLOCO 4: pass^k — consistência, não sorte (Capacidade 6) ----------
def pass_k(agent_fn, spec: dict, k: int = 3, minimo: int = 4) -> dict:
    notas = [julga(simula(agent_fn, spec)) for _ in range(k)]
    aprovada = all(n["resolutividade"]["nota"] >= minimo for n in notas)
    return {"persona": spec["nome"], "aprovada_k": aprovada, "rodadas": notas}

# ---------- BLOCO 5: o painel + o gate (Capacidades 4+7) ----------
def gate(agent_fn, painel: list, threshold: float = 0.8) -> dict:
    resultados = [pass_k(agent_fn, spec) for spec in painel]
    taxa = sum(r["aprovada_k"] for r in resultados) / len(resultados)
    return {"taxa_aprovacao": taxa, "deploy_liberado": taxa >= threshold,
            "detalhe": resultados}

# ---------- BLOCO 6: o relatório de 1 página (Capacidade 7) ----------
def relatorio(resultado: dict) -> str:
    linhas = [f"GATE: {'LIBERADO' if resultado['deploy_liberado'] else 'BLOQUEADO'}"
              f" ({resultado['taxa_aprovacao']:.0%} do painel aprovado, pass^3)"]
    for r in resultado["detalhe"]:
        m = r["rodadas"][-1]
        linhas.append(f"- {r['persona']}: intenção {m['resolucao_de_intencao']['nota']}"
                      f" · tarefa {m['aderencia_a_tarefa']['nota']}"
                      f" · resolutividade {m['resolutividade']['nota']}"
                      f" {'✓' if r['aprovada_k'] else '✗'}")
    return "\n".join(linhas)

# uso: resultado = gate(meu_agente, [PERSONA_SPEC, ...outras 4 do Prompt 4])
#      print(relatorio(resultado))
```

**Notas de produção do código:** roda no Colab do Cap 7; cada bloco corresponde à Capacidade que o gerou (a costura livro↔código é literal); testado no CORPUS antes de entrar no texto (G4); o leitor não-técnico lê só o comentário do topo de cada bloco e entende o desenho.

---

## 6. DECISÕES QUE TRAVAM NA P0 (com o Rafael)
1. Título/subtítulo final.
2. A pergunta canônica da Resolutividade ("este usuário voltaria amanhã?" vs. "recomendaria?") — é a contribuição original do livro.
3. Os nomes canônicos dos 5 arquétipos em PT (proposta: o Impaciente, o Descritor de Sintoma, o Desafiador de Política, o Trocador de Contexto, o Quase-Desistente).
4. Nota do autor sobre o fio ficcional (texto exato).


---

## 7. ADENDO v1.1 — Resultado-first, paleta nova, Laboratório e mapa de plots

### 7.1 Esqueleto canônico de página (substitui o modelo exercício-cêntrico)
1. Conceito em prosa (curto, dentro da história)
2. **Caixa PROMPT/CÓDIGO** (terminal #1E1E1E)
3. **Caixa RESULTADO — "SAÍDA · execução real"** (#F4F7F6, mono, transcrição do CORPUS; plot quando houver métrica)
4. Leitura do resultado (2-3 parágrafos: o que isso prova, onde mora a HIPÓTESE)
5. **Faixa "Sua vez"** (3-4 linhas, sem caixa grande) + linha "No Laboratório: Bloco N"
6. Faixa de progresso N DE 7

### 7.2 Paleta (decisão P0; default = A)
- **A (default): Verde-petróleo** — H1/H2 #0F4C5C · produto #EAF4F2 · resultado #F4F7F6/borda #C9D6D2 · placeholders de prompt #7FD8C4 · plots petróleo/cinza. Sóbrio, imprime bem em e-ink, diferencia a linha do azul do PE.
- **B (alternativa): Terracota** — #9C4221 · #FBEEE6.

### 7.3 Mapa de PLOTS REAIS (terceira coluna do mapa de figuras; todos nascem do CORPUS)
| Cap | Plot (matplotlib, arquivo do notebook) | O que prova |
|---|---|---|
| 1 | Transcrição da simulação lado a lado com a conversa original (texto, caixa RESULTADO) | a persona mínima reproduz a falha real |
| 2 | Barras: taxa de falha do agente-exemplo por arquétipo (5 barras) | cada arquétipo quebra diferente |
| 3 | Radar: 5 réguas da persona × evidência na fonte (0-1) + drift por turno (linha) | a spec segura o personagem no turno 8 |
| 4 | Scatter/mapa de divergência do painel (clones agrupados vs. cobertura espalhada) | volume ≠ cobertura |
| 5 | Barras agrupadas: 3 métricas × 5 personas, com threshold | a terceira métrica muda o veredito |
| 6 | Antes/depois do fix (barras pareadas) + heatmap pass^3 | melhoria com assinatura, sem sorte |
| 7 | O dashboard do gate (a Figura 8 vira plot real) | o Simulador decide o deploy |

### 7.4 Apêndice — O Laboratório (conteúdo travado)
Blocos 1-6 do código (§5) + `plots.py`: `radar_persona()`, `divergencia_painel()`, `barras_metricas()`, `antes_depois()`, `heatmap_passk()`, `dashboard_gate()` — cada função gera exatamente a figura impressa no capítulo correspondente. Notebook único no Colab, dependências fixadas, dados de exemplo inclusos (a conversa da cliente das 22h17 como seed). Critério de aceite: leitor roda `Runtime > Run all` e reproduz todas as figuras do livro.


---

## 8. ADENDO v1.2 — História, arquitetura, gigantes e A2A (pesquisa de 05/07/2026)

### 8.1 Narrativa histórica (entra na Introdução + reforços)
Linha do tempo canônica **post-it → planilha → agente** (§A13): Cooper anos 80/1999 (persona goal-directed) → Pruitt & Adlin 2006 (lifecycle corporativo) → data-driven anos 2010 → Park 2023 (a persona conversa) → 2024-26 (Stanford 1.000, PersonaHub 1B, Persona Generators, τ-bench, personas-produto do Grok). Batida narrativa da Introdução: *"a persona passou quarenta anos muda na parede; em 2023 ela começou a responder — e quem responde pode testar"*. Reforços: Cap 2 abre no Cooper (comportamento>demografia é ideia dele, não nossa — honestidade intelectual que dá autoridade); Cap 3 usa o trio de specs (§8.3).

### 8.2 Os dois desenhos de arquitetura (novos assets, F6)
**Desenho técnico (Figura A — hand-drawn, meia página):** [ORQUESTRADOR DO SIMULADOR] no topo (grava plano/memória) → spawn de [PERSONA 1..5], cada uma com dois módulos internos: (ATOR — mantém caráter) + (RASTREADOR — mantém estado da tarefa) ⇄ setas de conversa com [SEU AGENTE (ReAct: pensa→age→observa)] → transcrições descem para [JUIZ · 3 MÉTRICAS] → [GATE ✓/✗]. Rótulo inferior: 'O MESMO PADRÃO ORCHESTRATOR-WORKER DA ANTHROPIC (§A14)'.
**Desenho executivo (Figura B — hand-drawn, 3 caixas):** [CLIENTES DE ENSAIO] → [SEU AGENTE] → [NOTA + DECISÃO DE DEPLOY]. Legenda: *O Simulador em dez segundos.* Entra na Introdução E no dashboard do Cap 7 (a versão que o C-level repete na reunião).
**Análise canônica (Cap 5/6, prosa):** o agente testado é ReAct; a persona não é — ator+rastreador (§A18). Errar isso é o erro nº1 de quem tenta construir persona "como agente".

### 8.3 Como os gigantes fazem (mapa de casos por capítulo — todos com ficha)
| Quem | O quê (definição no arsenal) | Onde no livro |
|---|---|---|
| Anthropic | orchestrator-worker oficial: 90,2%, 80% variância por tokens, 15x custo, memória externa (§A14); system prompt como spec (§A10) | Cap 4 (painel paralelo) + Cap 3 (spec) |
| Google/DeepMind | Persona Generators/AlphaEvolve, coverage>density (§A1); Concordia e as 3 perguntas da appropriateness (§A12); A2A (§A19) | Cap 4 + Cap 7 |
| OpenAI | Model Spec: spec pública em camadas com hierarquia de instruções (§A17); Swarm→Agents SDK (handoffs) | Cap 3 + Cap 7 |
| Microsoft | evaluators Intent Resolution/Task Adherence 1-5 com threshold (§A3) | Cap 5 |
| xAI/Grok | personas-produto expostas sem gate — o caso-alerta (§A15) | Cap 3 |
| Meta | diretrizes vazadas — spec é documento de risco (§A16) | Cap 3 (1 parágrafo) |
| Universidades | Stanford (Park/1.000), TU Delft, EMNLP SimulatorArena (§A2/§A6) | Intro + Cap 7 |

**O trio de specs do Cap 3** (a cena mais forte do livro): a spec oficial da Anthropic (engenharia com incidentes corrigidos) × a Model Spec da OpenAI (camadas públicas) × as personas expostas do Grok (choque sem gate). Mesma tecnologia, três culturas — e a spec do leitor vai parecer com qual?

### 8.4 A2A — decisão editorial
NÃO vira capítulo (quebraria os 7). Entra como **seção "Fronteira" no Cap 7** (1 página: o Simulador como serviço via Agent Card, §A19) + **Bloco 7 opcional no Laboratório** (esqueleto de Agent Card JSON + endpoint mínimo que expõe `simula()` — marcado como avançado). Vende o próximo livro da linha sem inflar este.

### 8.5 Mapa de figuras — atualização
Adicionar ao §3: **F1b** timeline hand-drawn 'POST-IT → PLANILHA → AGENTE' (Introdução, após a cena histórica); **Figura A** (técnica) no Cap 4; **Figura B** (executiva) na Introdução e reprisada no Cap 7. Total revisado: **27 assets**.
