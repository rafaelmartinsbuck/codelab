# SUBTÍTULOS DA LINHA — metodologia expandida (v1)
**Os quatro livros, uma gramática de capa. Metodologia PIAE (do exercício Gemini) + os dois eixos novos do MW + um terceiro estudo: a formação de título dos best-sellers que venderam para liderança técnica e executiva.**

## O que aprendemos com os best-sellers (e vamos usar)
- **Atomic Habits (Clear):** *"An Easy & Proven Way to Build Good Habits & Break Bad Ones"* — a fórmula é **[promessa de facilidade/prova] + [dor removida] + [ganho]**. "Proven" e o par ganho/dor fazem o trabalho. Título de UMA palavra concreta + subtítulo que entrega o mecanismo.
- **The Lean Startup, Zero to One, Deep Work, The Mom Test:** título curtíssimo e conceitual (vira vocabulário do leitor) + subtítulo operacional. O título é a IDEIA; o subtítulo é o MÉTODO.
- **Accelerate (Forsgren/Humble/Kim — o mais próximo do nosso público):** *"Building and Scaling High Performing Technology Organizations"* — vende status técnico e resultado organizacional na mesma linha.
- **Padrão que adotamos:** título = conceito curto que o leitor passa a usar; subtítulo = **verbo de engenharia + objeto concreto + ganho pessoal do leitor**, com uma palavra de PROVA (comprovado/verificado/mensurável) quando couber. Menos "Como pessoas fazem X" repetido em série; mais variação de arquétipo de manchete (promessa provada, contraste protótipo→produto, comando direto).

## Os 8 eixos de pontuação (0-10; corte: P>E e AB ≥ 9; total /80)
A Aspiracional · V Vendável (thumbnail) · O Otimista · C Cognitivo (1 passada) · PIAE (verbo = engenharia, não hype) · **P>E** (ganho é da PESSOA, não da empresa) · **AB** (só promete o que o livro prova) · **DIF** (diferenciação — foge do molde repetido da série)

---

## PROFISSIONAL EXPONENCIAL
Sua frase de teste: *"Como pessoas fora da curva usam inteligência artificial para acelerar seu próprio valor."* — **Avaliação: forte, e melhor que a original com "treinam".** "Usam" é mais honesto e mais largo (nem todo leitor vai treinar modelo), mantém A/C/P>E altos; só perde um ponto de PIAE (menos "engenharia" que "treinam/calibram"). Fica como **nº 2**. Recomendo o nº 1 abaixo, que recupera o PIAE sem perder a honestidade.

| # | Subtítulo | A | V | O | C | PIAE | P>E | AB | DIF | Total |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | O método fora da curva para transformar inteligência artificial em vantagem de carreira. | 10 | 10 | 9 | 10 | 9 | 10 | 9 | 9 | 76 |
| 2 | Como pessoas fora da curva usam inteligência artificial para acelerar seu próprio valor. | 10 | 10 | 9 | 10 | 8 | 10 | 9 | 7 | 73 |
| 3 | Construa o consultor de carreira em IA que trabalha por você — capítulo a capítulo. | 9 | 9 | 9 | 9 | 10 | 10 | 9 | 9 | 74 |
| 4 | A vantagem injusta de quem faz a inteligência artificial trabalhar pela própria carreira. | 10 | 9 | 8 | 9 | 9 | 10 | 8 | 9 | 72 |

**Recomendo nº 1** (arquétipo "método provado" à la Atomic Habits: "O método fora da curva para…") — mantém sua marca "fora da curva", cadência limpa, e "vantagem de carreira" é o ganho pessoal cristalino. Nº 3 se você quiser o PRODUTO explícito na capa.

---

## PERSONAS SINTÉTICAS
Seu briefing: *simular seu usuário para encontrar erros antes de entregar sistemas de IA e gerar valor em escala.* — vira família de candidatos com o arquétipo **contraste temporal (antes/depois de entregar)** + **escala**.

| # | Subtítulo | A | V | O | C | PIAE | P>E | AB | DIF | Total |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Simule seus usuários, encontre as falhas antes da produção e entregue IA que aguenta gente de verdade. | 9 | 10 | 9 | 9 | 10 | 9 | 10 | 9 | 75 |
| 2 | Encontre as falhas antes dos seus usuários — e entregue sistemas de IA que escalam. | 9 | 10 | 9 | 10 | 9 | 9 | 10 | 8 | 74 |
| 3 | O usuário que não existe encontra o erro que o real não perdoa. | 10 | 9 | 8 | 9 | 9 | 9 | 9 | 10 | 73 |
| 4 | Teste seus agentes de IA com usuários sintéticos e entregue valor em escala, sem surpresas em produção. | 9 | 9 | 9 | 8 | 10 | 9 | 10 | 8 | 72 |

**Recomendo nº 1** (comando direto Clear-style, cobre briefing inteiro: simular → falha antes da produção → aguenta gente real). Nº 3 é o mais memorável para orelha/epígrafe — arquétipo "aforismo" (Zero to One), guardar como frase de capa secundária ou tagline.

---

## AGENT EVALUATION
Seu briefing: *a diferença entre o protótipo e o produto de mercado.* — arquétipo **contraste de estado (demo→produção)**, que é exatamente a dor de quem lidera engenharia.

| # | Subtítulo | A | V | O | C | PIAE | P>E | AB | DIF | Total |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | A diferença entre o protótipo que impressiona e o agente de IA que o mercado confia. | 10 | 10 | 9 | 9 | 9 | 9 | 10 | 10 | 76 |
| 2 | Prove que seu agente de IA funciona — do primeiro teste ao sistema multiagente em produção. | 9 | 10 | 9 | 9 | 10 | 9 | 10 | 8 | 74 |
| 3 | Meça, prove e confie: como levar agentes de IA da demo à produção. | 9 | 9 | 9 | 10 | 9 | 9 | 10 | 8 | 73 |
| 4 | O que separa a demo que encanta do sistema que o conselho aprova. | 10 | 9 | 8 | 9 | 8 | 9 | 10 | 10 | 73 |

**Recomendo nº 1** (o contraste protótipo↔confiança do mercado é a promessa exata da Pirâmide; "que o mercado confia" carrega o ganho de reputação do líder). Nº 2 se você quiser "do primeiro teste ao multiagente" para deixar a progressão explícita na capa.

---

## MODERN WORKFLOWS (reafirmação, para a linha ficar coerente)
Campeão mantido: *"Como grandes líderes colocam agentes de IA para trabalhar — e assinam resultados que o conselho verifica."* (68/70 na tabela original; na régua /80 com DIF=9 → **77**, o mais alto da linha — apropriado, é o livro mais executivo).

---

## VISÃO DE COLEÇÃO (o teste final: as 4 lombadas juntas)
Com as recomendações, a série deixa de ser quatro "Como pessoas/líderes…" repetidos e passa a ter **quatro arquétipos distintos de manchete**, o que é sinal de catálogo maduro:
- **Profissional Exponencial** — *método provado*: "O método fora da curva para transformar IA em vantagem de carreira."
- **Personas Sintéticas** — *comando + antes/depois*: "Simule seus usuários, encontre as falhas antes da produção e entregue IA que aguenta gente de verdade."
- **Agent Evaluation** — *contraste de estado*: "A diferença entre o protótipo que impressiona e o agente de IA que o mercado confia."
- **Modern Workflows** — *líder + prova executiva*: "Como grandes líderes colocam agentes de IA para trabalhar — e assinam resultados que o conselho verifica."
Progressão de público visível na capa: carreira (eu) → construção (meu sistema) → prova (meu produto) → operação (minha organização). Assinatura de coleção sem monotonia.
