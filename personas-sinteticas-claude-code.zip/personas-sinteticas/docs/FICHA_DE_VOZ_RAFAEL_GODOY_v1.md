# FICHA DE VOZ — Rafael Godoy
**Fonte:** corpo de texto do *Profissional Exponencial* v131 (Kindle final). 27.066 palavras, 1.651 frases, 702 parágrafos de corpo, medidos com o mesmo filtro de caixa/tabela do `hunt_g1`.
**Papel:** entra no Pacote de v0 de toda sessão de escrita, junto com o Context Block. É o gabarito de voz da linha inteira — não só do livro 2.
**Gate que a verifica:** `hunt_g3_voz.py`.

Nada aqui é preferência estética. São as marcas mensuráveis do livro que já passou por parecer, evals e KDP. Escrever fora delas é escrever como outra pessoa — e, na prática, é escrever como um modelo de linguagem sem revisão.

---

## 1. As sete marcas que mais denunciam texto de IA — e o que o v131 faz

### 1.1 O travessão
A casa usa **`–` com espaços**, não `—`. No v131: 524 contra 105, cinco para um. Modelo de linguagem sai por padrão com em-dash colado; é a marca tipográfica mais visível de texto não revisado. Regra: `–` cercado de espaços, sempre.

### 1.2 Conectivo de abertura de frase
**0,36% das frases.** Seis ocorrências em 1.651. Zero *Portanto*, zero *Assim*, zero *Além disso*, zero *No entanto*, zero *Ou seja*, zero *Dessa forma*, zero *Nesse sentido*, zero *Em resumo*.

A relação entre duas frases se faz pela ordem em que elas aparecem. O conectivo é o modelo explicando a própria estrutura em voz alta — e é o sinal que um leitor treinado pega em três parágrafos. Prosa de LLM roda entre 3% e 8% aqui; o controle que testei deu 89%.

### 1.3 Ritmo irregular
Frase média 16,4 palavras, desvio 11,6, **burstiness 0,70**. A distribuição:

| tamanho | fatia |
|---|---|
| 1–5 palavras | 14,4% |
| 6–10 | 21,5% |
| 11–15 | 19,7% |
| 16–20 | 14,5% |
| 21–30 | 19,9% |
| 31–45 | 7,8% |
| 46+ | 2,2% |

Uma frase em sete tem cinco palavras ou menos. Uma em três passa de vinte. É essa oscilação que soa humana; o modelo, sem instrução, converge para 20–25 palavras em quase tudo e a burstiness cai para 0,3.

### 1.4 Parágrafo de uma frase
**36,8% dos parágrafos do v131 têm uma frase só.** Outros 37% têm duas ou três. Só 2,6% passam de sete. O parágrafo curto é usado como pontuação de ritmo, não como exceção.

### 1.5 Pontuação
| sinal | por 1000 palavras |
|---|---|
| dois-pontos | 12,82 |
| aspas | 14,41 |
| interrogação | 2,51 |
| ponto e vírgula | **0,92** |
| parênteses | 1,85 |
| exclamação | **0** |
| reticências | **0** |

Dois-pontos é o sinal preferido da casa: ele apresenta, e apresentar é o que o texto faz o tempo todo. Ponto e vírgula é quase inexistente — modelo de linguagem adora, o livro não usa. Exclamação e reticências não existem, nenhuma vez em 27 mil palavras.

### 1.6 Pessoa
| forma | por 1000 palavras |
|---|---|
| você | 10,83 |
| eu / meu / minha | 1,83 |
| nós / nosso / a gente | **0** |

O narrador fala com o leitor, não em nome de um grupo. "Nós" e "a gente" não aparecem uma única vez. A primeira pessoa do singular é racionada e sempre ancorada em experiência real — no livro 2, ela só pode sair do Banco de Campo.

### 1.7 Capítulos que não se parecem entre si
Uniformidade entre capítulos é uma das seis famílias de cheiro de IA. No v131 a variação é grande:

| seção | frase média | burstiness | frases ≤5 palavras | § de 1 frase |
|---|---|---|---|---|
| Prefácio | 16,7 | 0,53 | 8,6% | 34,5% |
| Antes de começar | 14,1 | 0,58 | 7,1% | 16,7% |
| Introdução | 14,5 | 0,75 | 21,0% | 16,4% |
| Cap 1 | 13,9 | 0,79 | 20,3% | 27,9% |
| Cap 2 | 17,0 | 0,72 | 18,0% | 43,3% |
| Cap 3 | 15,9 | 0,70 | 19,0% | 31,5% |
| Cap 4 | 17,9 | 0,65 | 9,8% | 31,7% |
| Cap 5 | 17,2 | 0,60 | 12,0% | 27,3% |
| Cap 6 | 18,9 | 0,72 | 13,6% | 31,9% |
| Cap 7 | 15,9 | 0,64 | 10,6% | 27,8% |
| Epílogo | 16,9 | 0,54 | 10,7% | 13,6% |

**Amplitude:** 7,2 palavras na frase média, 0,75 na burstiness, 14 pontos percentuais nas frases curtas. Capítulo escrito no mesmo ritmo do anterior é sintoma, não consistência.

---

## 2. As faixas do gate

`hunt_g3_voz.py` mede exatamente isto. Rodando no próprio v131: catorze métricas, zero falhas. Rodando num parágrafo de controle escrito em prosa típica de LLM: nove falhas.

| métrica | faixa | v131 |
|---|---|---|
| frase média (palavras) | 13,0 – 22,0 | 16,4 |
| burstiness | ≥ 0,58 | 0,70 |
| frases ≤5 palavras | 7 – 23% | 14,4% |
| frases ≥21 palavras | 15 – 40% | 29,9% |
| parágrafos de 1 frase | 14 – 55% | 36,8% |
| aberturas conectivas | ≤ 1,2% | 0,36% |
| ponto e vírgula | ≤ 2,5/1000 | 0,92 |
| fração de travessão curto `–` | ≥ 0,70 | 0,94 |
| exclamação | 0 | 0 |
| reticências | 0 | 0 |
| nós / a gente | 0 | 0 |
| 1ª pessoa do singular | ≤ 3,5/1000 | 1,83 |
| interrogação | ≤ 4,5/1000 | 2,51 |
| abertura de § mais repetida | ≤ 5% | 3,3% |

Com três capítulos ou mais na mesma chamada, o script também checa a amplitude entre eles: mínimo 2,5 palavras de variação na frase média e 0,15 na burstiness.

**Fora da faixa não é erro automático.** É obrigação de abrir o trecho e decidir. O gate aponta; quem corrige é você.

---

## 3. O que a medição não pega, e mesmo assim é a voz

Números descrevem o esqueleto. Estas quatro coisas são o resto, e saem da leitura do v131:

**A cena vem antes do conceito, e a cena tem detalhe que ninguém inventaria.** Não "um profissional frustrado", mas o feedback que se repetia em cada ciclo de avaliação: *"Você é excelente. Continue assim."* O detalhe operacional é o que faz o leitor acreditar.

**A fala entre aspas carrega o argumento.** Aspas a 14,4/1000 não é decoração: o livro faz o ponto pela boca de alguém em vez de declará-lo. Quando o narrador precisa afirmar, ele afirma curto e segue.

**O narrador tem dúvida e a mostra.** "Funcionou – de forma eficiente, porém incompleta." A hesitação é o que distingue voz de locução. Modelo de linguagem escreve sempre no mesmo tom elevado; o v131 desce e sobe.

**A conclusão é dedução do leitor.** O texto entrega a observação e para. Não explica que aquilo foi importante, não avisa que vai nomear algo, não resume o que acabou de dizer. Quando o parágrafo termina uma linha antes do que o modelo gostaria, ele está no ponto.

---

## 4. Como usar isto na sessão

1. A ficha entra no Pacote de v0, inteira. São ~1.200 tokens e substituem uma rodada de correção.
2. Antes de propor o capítulo: `hunt_g1_marcas.py` → `hunt_g2_ecos.py` → `hunt_g3_voz.py --ref`.
3. Toda métrica fora da faixa vira linha numa tabela `métrica | trecho | reescrita`, do mesmo jeito que os matches do G1.
4. Corrigir para dentro da faixa **não é** encurtar frase até o número bater. Se a frase média está em 24, o problema costuma ser um só: falta frase curta. Acrescente as curtas em vez de mutilar as longas.
5. Ao fechar o manuscrito, rode o g3 com os sete capítulos de uma vez e olhe a amplitude. Se os capítulos ficaram parecidos demais, o livro inteiro soa gerado — mesmo com cada capítulo aprovado isoladamente.
