# PROMPTS AVULSOS — para colar se um slash command não disparar

Os comandos `/pacote`, `/escrever`, `/gates`, `/lab`, `/costura` e `/entrega` já contêm estes textos.
Use estes blocos só se precisar rodar fora do comando, ou em outra ferramenta.

---

## Antes de qualquer coisa, em toda conversa nova

```
Leia CLAUDE.md, docs/FICHA_DE_VOZ_RAFAEL_GODOY_v1.md e .claude/skills/personas-sinteticas-rewriter/SKILL.md antes de responder qualquer coisa. Depois me diga em três linhas: qual é a estrutura do livro, qual é o produto, e quais são as três regras de voz que você mais corre risco de violar hoje.
```

Se ele responder "12 capítulos", pare: a skill não carregou.

---

## Montar pacote

```
Monte o Pacote de v0 da sessão E<N> em pacotes/PACOTE_E<N>.md, com os sete itens do comando /pacote. Copie ficha de arsenal verbatim, não parafraseie. Se faltar saída no corpus ou âncora no conjunto-âncora, marque STATUS: INCOMPLETO e liste o que falta. Não escreva o capítulo.
```

## Escrever capítulo

```
Escreva a sessão E<N> em manuscrito/E<N>_<nome>.md.
Pré-condição: pacotes/PACOTE_E<N>.md com STATUS: COMPLETO. Se não estiver, pare.
Uma passada, do começo ao fim, no esqueleto resultado-first.
Abertura <Sinek|Clear>. Duas mensagens-âncora vindas do pacote, fora de caixa, em posições distantes.
Toda caixa de PROMPT/CÓDIGO seguida de SAÍDA real do corpus.
Marque [LAPIDAR: ...] onde falta material; máximo 8. Nada de encher linguiça.
Proibido: "nós"/"a gente", conectivo abrindo frase, travessão longo, exclamação, reticências, pergunta retórica no fecho, caso inventado.
Depois rode bash gates/rodar_gates.sh sobre o arquivo e corrija até passar.
```

## Corrigir falha de envelope (G3)

```
O G3 reprovou em <métrica>. Não corte palavra a esmo. Diga primeiro quais trechos causaram, depois corrija pelo mecanismo certo: frase média alta se resolve acrescentando frase curta, não mutilando as longas; burstiness baixa se resolve quebrando parágrafo e deixando um deles com uma frase só; travessão se resolve trocando — por – com espaços. Rode o gate de novo e me mostre o antes e o depois das métricas.
```

## Auditoria de honestidade (rode uma vez por capítulo, depois dos gates)

```
Releia o capítulo que você acabou de escrever como um head de engenharia cético que já comprou três livros ruins sobre avaliação de agentes. Liste, sem suavizar: (1) toda afirmação que não tem fonte no arsenal nem saída no corpus; (2) todo parágrafo que soaria igual se o assunto fosse outro; (3) o ponto onde ele largaria o livro. Não corrija nada ainda. Não elogie o próprio texto.
```

## Fechar sessão

```
Atualize docs/CONTEXT_BLOCK.md em no máximo 300 tokens: cena usada, âncoras gastas, tipo de abertura, promessa aberta para o próximo capítulo, convenções fixadas. Depois grave manuscrito/E<N>_RELATORIO.md com as métricas finais dos três gates, a lista de [LAPIDAR], a lista de [FALTA] e os itens de REVISAR do G1 que você decidiu não mexer, com o motivo.
```
