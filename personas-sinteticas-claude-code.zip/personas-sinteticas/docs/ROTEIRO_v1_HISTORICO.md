> **ARQUIVO HISTÓRICO — leia com ressalva.**
> Este é o roteiro v1. Duas partes dele estão mortas e foram removidas ou corrigidas:
> 1. A **§C (20 prompts Gemini para figuras hand-drawn)** foi apagada deste arquivo. O traço agora é Excalidraw. Não procure por ela, não tente reconstruí-la.
> 2. Onde ele disser **12 capítulos, Parte 1/2/3 ou Colab 08–12**, ignore: a estrutura é 7 capítulos + Apêndice.
> O que vale hoje é `PLANO_PRODUCAO_v2_PERSONAS_SINTETICAS.md` e `EXECUCAO_PASSO_A_PASSO.md`. Este arquivo fica só pelo detalhe de conteúdo por sessão (§A, fases 2 a 4) e pelo protocolo de sessão (§B).

# ROTEIRO DE PRODUÇÃO v1 — Personas Sintéticas
**36 passos, do congelamento à submissão. Cada passo tem dono, entrada, saída e teste de saída. As sessões de escrita do Opus (passos 10–21) seguem todas o mesmo protocolo-padrão (§B). Os prompts do Gemini para as figuras estão íntegros no §C.**
**Subtítulo oficial em todos os assets:** *Encontre as falhas antes dos seus usuários — e entregue sistemas de IA que escalam.*

---

## §A — OS 36 PASSOS

### FASE 0 · Congelamento (Rafael + Fable — 1 sessão)
**1.** Travar as decisões P0 restantes: pergunta canônica da Resolutividade ("este usuário voltaria amanhã?" vs. "recomendaria?") · nomes PT dos 5 arquétipos (proposta: o Impaciente, o Descritor de Sintoma, o Desafiador de Política, o Trocador de Contexto, o Quase-Desistente) · texto exato da nota do autor · paleta (default petróleo). *Saída:* zero `[DECISÃO]` abertos.
**2.** Aplicar os patches pré-congelamento na skill: subtítulo novo no cabeçalho; glossário += benevolence bias e Queijo Suíço; whitelist do hunt_g2 += refrões deliberados do Adendo v1.3 §3. Congelar skill v-final.
**3.** Grep de subtítulo: substituir o subtítulo antigo em TODOS os arquivos do projeto (gabarito, arsenal, skill, manifesto). *Teste:* `grep -ri "que não existem" *` retorna zero fora de notas históricas.

### FASE 1 · Fundações (Opus com busca ∥ Fable — paralelo)
**4.** OPUS: rodar o protocolo F1 do arsenal — abrir cada fonte primária pendente (lista recalculada no ARSENAL v2), colar par original-inglês+tradução, fixar números citáveis. *Teste:* arsenal sem `RE-VERIFICAR` aberto.
**5.** FABLE: derivar `MASTER_TEMPLATE.docx` do v49 — paleta petróleo, 4 caixas (produto/prompt-código/resultado/Sua vez), folha de rosto com o subtítulo novo. *Teste:* as 4 caixas renderizam; PDF de prova aprovado.

### FASE 2 · CORPUS antes da prosa (Sonnet executa, Opus especifica, Fable arquiva)
**6.** Construir o Laboratório (6 blocos + plots.py) e RODAR com o agente-exemplo + conversa-seed (a cliente das 22h17). Arquivar transcrições e os 7 PNGs.
**7.** Rodar os 7 prompts em cadeia na IA com 3 perfis (PM, vendedor, eng); arquivar toda saída bruta. *Teste:* `Run all` reproduz os 7 plots; cada capítulo tem SAÍDA real arquivada.
**8.** Regravar a PRÉVIA no esqueleto resultado-first + paleta nova (vira o gabarito de voz vigente).

### FASE 3 · Gate de valor (Opus como eng sênior de evals + Rafael)
**9.** O Simulador do corpus passa nos 5 critérios do gate de domínio + Teste de Valor ("colocaria no CI do meu time?" / "vale R$150+?"). Rafael toma 1 decisão real com o Simulador. Reprova → conserta o PRODUTO, não a prosa. *Teste:* gate assinado.

### FASE 4 · Escrita (Opus, 1 sessão por passo — protocolo-padrão §B em todos)
**10.** Sessão E1 — **Prefácio + Antes de começar** (inclui o parágrafo industrial novo: §A24+§A25+§A30; nota do autor travada no passo 1).
**11.** Sessão E2 — **Introdução** (timeline com terceiro ato τ³; Figura B executiva; tabela "o que você vai construir"; estático×dinâmico com §A29).
**12.** Sessão E3 — **Cap 1 · O teste que passa em tudo** (abre com a cena das 22h17; §A24b como validação; Prompt 1 + SAÍDA do corpus).
**13.** Sessão E4 — **Cap 2 · Os cinco jeitos de quebrar** (abertura Clear; benevolence bias §A27 + §A23 + §A11; plot de barras por arquétipo).
**14.** Sessão E5 — **Cap 3 · A persona que não desmonta** (abertura Sinek; o trio de specs Anthropic×OpenAI×Grok §A10/§A17/§A15 + Meta §A16 em 1 parágrafo; radar+drift).
**15.** Sessão E6 — **Cap 4 · O painel que discorda** (abertura Clear; §A1 coverage>density; §A14 orchestrator-worker verbatim; §A30 em 1 linha; Figura A técnica; mapa de divergência).
**16.** Sessão E7 — **Cap 5 · As três perguntas** (abertura Sinek; canon do Juiz COMPLETO: duas filosofias §A4, vieses+mitigações §A21, "segundo LLM" §A24a; barras 3×5).
**17.** Sessão E8 — **Cap 6 · Da falha ao conserto** (abertura Clear; critério dos dois especialistas §A24c; antes/depois + heatmap pass^3).
**18.** Sessão E9 — **Cap 7 · O Simulador** (abertura Sinek; §A25 35k/dia; Fronteira dupla A2A+voz; parágrafo de mercado §A31; dashboard-plot; Figura B reprisada).
**19.** Sessão E10 — **Apêndice · O Laboratório** (blocos 1–7 + plots.py, cada bloco com SAÍDA real; bloco 7 A2A marcado avançado).
**20.** Sessão E11 — **"O que o método não entrega"** (os 5 aprendizados do Adendo v1.3 §2.7) + **Notas e Referências** (entradas 1–26, números conferidos contra arsenal) + **Sobre o Autor** (variante Personas, slots [CV] preenchidos) + Agradecimentos.
**21.** Sessão E12 — **Passada de costura**: ler o manuscrito inteiro em sequência; conferir pontes entre capítulos, ordem canônica das 3 métricas em toda menção, faixas de progresso 1–7, e que cada fechamento aponta para uma das duas metades do subtítulo. Rodar hunt_g2 no texto completo com a whitelist nova.

### FASE 5 · Evals de leitura (Sonnet prepara, Gemini Flash julga)
**22.** Trocar células 4/6/7b do book_evaluator (3 perfis: eng cético, dev-virou-AI-eng, PM técnico; 7b alinhada à lista de caça + G4 resultado-first).
**23.** Rodar subset por capítulo; manuscrito fechado roda o set completo. Reprovação do eng cético = prioridade máxima. *Teste:* todos os caps ≥ limiar nas 5 métricas.
**24.** Padrão de falha recorrente → patch na skill por evidência (única exceção ao congelamento) → re-rodar capítulos afetados.

### FASE 6 · Figuras (Gemini traço ∥ Sonnet plots)
**25.** Gerar os 20 assets hand-drawn com os prompts do §C (lote único, mesma sessão para manter o traço). Aceite por imagem: fundo branco puro, rótulos verbatim, 16:9, ≥1600px.
**26.** Exportar os 7 plots do corpus (PNG 300dpi, paleta petróleo/cinza, sem retoque).
**27.** Teste do arco: as figuras+plots em sequência contam o livro sem prosa. Reprova → regerar só as que quebram o arco.

### FASE 7 · Montagem e fechamento (Fable)
**28.** Inserções no docx em ordem decrescente de página.
**29.** `pack --original` + validação com delta justificado.
**30.** PDF das páginas tocadas → aprovação visual do Rafael.
**31.** Varredura FINAL: grep da lista de caça no texto plano + hunt_g2 + checagem de todo número contra corpus/arsenal. *Teste:* zero matches, zero número órfão.
**32.** TOC, metadados, subtítulo na capa e na página de KDP.
**33.** Publicação KDP + Hotmart (vídeo por sessão + link do Colab).

### PÓS (não bloqueia o lançamento)
**34.** Registrar o livro no Context Block da linha (book-context-block): âncoras usadas, refrões, estruturas de abertura por capítulo.
**35.** Rodar o Simulador do livro sobre o próprio material de vendas (dogfooding público — conteúdo de lançamento).
**36.** Retrospectiva da linha: o que este roteiro muda para o Livro 3 (Agent Evaluation).

---

## §B — PROTOCOLO-PADRÃO DA SESSÃO DE ESCRITA (aplica-se aos passos 10–21)
**Entradas obrigatórias abertas ao lado (bloqueiam o início):** (1) fichas do arsenal citadas pelo capítulo; (2) SAÍDA do corpus do capítulo; (3) slots de figura/plot confirmados no mapa; (4) o fechamento do capítulo anterior aprovado (para a ponte).
**Ordem de execução:**
1. Rascunho pela skill no esqueleto resultado-first (conceito → caixa PROMPT/CÓDIGO → caixa RESULTADO real → leitura → faixa Sua vez → linha do Laboratório → faixa de progresso).
2. Abertura conforme o mapa (Sinek ímpares / Clear pares); teoria dentro da história; um conceito por vez; definição de método SEMPRE verbatim do arsenal.
3. Checagem de paralelismo em toda enumeração 2+.
4. Sweep da lista de caça → tabela `padrão | trecho | reescrita` para todo match.
5. Gates G1–G8 + gate de domínio (5 critérios).
6. `book-editor-humanizer` → `guardian-conteudo`.
7. Proposta ao Rafael (propose-before-apply) → "siga" → docx (template, ordem decrescente, delta justificado, PDF das páginas tocadas).
**Teste de saída por sessão:** zero matches na caça; toda caixa de código/prompt seguida de SAÍDA real; fecha em descoberta (sem `?` na última frase); ponte para o próximo capítulo escrita.

---



*(§C removida — pipeline de figuras substituído por Excalidraw.)*
