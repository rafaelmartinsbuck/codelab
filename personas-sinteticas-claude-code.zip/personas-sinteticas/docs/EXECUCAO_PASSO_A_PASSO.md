# EXECUÇÃO — Personas Sintéticas, da primeira etapa ao arquivo na KDP
**Companheiro operacional do `PLANO_PRODUCAO_v2`.** Lá está o porquê; aqui está o que fazer, em ordem, com o modelo a selecionar e o teste que libera a etapa seguinte.

**48 etapas · ~38 sessões de modelo · 3 superfícies.**

---

## Como ler a coluna "onde"

| Sigla | Superfície | Por que ali |
|---|---|---|
| **CHAT** | claude.ai, dentro do Projeto | tem a pasta do projeto e a memória do Projeto; é onde a prosa e as decisões acontecem |
| **CODE** | Claude Code (terminal ou app) | precisa de sistema de arquivos: `exc2livro`, `arte-kdp`, os três `hunt`, unpack/pack do docx, `npm install roughjs` |
| **COLAB** | Google Colab | o Laboratório roda onde o leitor vai rodar; se não rodar lá, não entra no livro |

Etapas marcadas **RAFAEL** não têm modelo: são suas.

---

## Seletor de modelo — a regra em cinco linhas

| Modelo | Quando selecionar |
|---|---|
| **Opus 5** | prosa, julgamento editorial, especificação de prompt, leitura de resultado |
| **Fable 5** | as três etapas onde erro é irreversível: verificação do arsenal, Capítulo 1, parecer big five |
| **Sonnet 5** | tudo que é determinístico: código, docx, JSON do Excalidraw, montagem de pacote, execução |
| **Haiku 4.5** | compressão e varredura triviais: Context Block, grep, conferência de alt-text |
| **Gemini Flash** | só os evals de leitura — família diferente da de quem escreveu (§A21) |

Fable roda com salvaguardas conservadoras: em menos de 5% das sessões a resposta pode vir do Opus 5. Nas três etapas onde ele é indicado, isso é aceitável — a diferença de qualidade é marginal e o custo de repetir é zero.

**Três regras de higiene que valem mais que a escolha do modelo:**
1. **Uma conversa por capítulo.** Nunca continuar o Cap 3 na conversa do Cap 2 — o contexto acumulado empurra a voz para a média do que já foi escrito.
2. **Nunca trocar de modelo no meio de uma sessão de escrita.** Costura visível.
3. **O que um script resolve, nenhum modelo roda.**

---

## FASE 0 · Congelar (3 etapas · 1 sessão)

| # | Etapa | Onde | Modelo | Entrada | Saída | Teste de saída |
|---|---|---|---|---|---|---|
| 1 | As 12 decisões da F0 v2 | CHAT | **Opus 5** | `PLANO_PRODUCAO_v2` §4 | as 12 travadas, incluindo a F0-9 (multipersona) | zero `[DECISÃO]` aberto em qualquer arquivo |
| 2 | Instalar skill v4, ficha de voz, `hunt_g1_v2`, `hunt_g3` | CODE | **RAFAEL** | os 4 arquivos entregues | pasta e skills atualizadas | `python3 hunt_g3_voz.py pe.txt --ref` devolve APROVADO — prova que o ambiente está certo antes de escrever a primeira linha |
| 3 | Varredura de resíduo: subtítulo antigo, "12 capítulos", "Colab 08–12", "(Gemini)" | CODE | **Haiku 4.5** | pasta do projeto | arquivos limpos | `grep -ri "que não existem"` = zero fora de nota histórica |

---

## FASE 0.5 · O gabarito invisível (2 etapas · 2 sessões)

A fase de maior retorno por token do projeto. Sem ela, cada capítulo inventa as próprias âncoras e o parecer editorial encontra quatro canais que não convergem.

| # | Etapa | Onde | Modelo | Entrada | Saída | Teste de saída |
|---|---|---|---|---|---|---|
| 4 | Congelar o conjunto-âncora: 8 a 15 proposições que alguém que entendeu o livro obrigatoriamente diria | CHAT | **Opus 5** | estrutura + gabarito v3 + arsenal | lista numerada, com o capítulo de cada uma | cada proposição cabe em uma linha e nenhuma é genérica o bastante para valer para outro livro do nicho |
| 5 | Distribuir nos quatro canais | CHAT | **Opus 5** | conjunto-âncora | 28 mensagens-âncora candidatas (você escolhe 14) · 8 legendas afirmativas · mapa dos 7 prompts · plano do prefixo de 10% | toda proposição é recuperável por pelo menos dois canais; as 14 âncoras lidas em sequência resumem o método |

---

## FASE 1 · Fundações (3 etapas · 3 a 4 sessões · paralelizável)

| # | Etapa | Onde | Modelo | Entrada | Saída | Teste de saída |
|---|---|---|---|---|---|---|
| 6 | Arsenal N1: abrir as fontes primárias com `RE-VERIFICAR` e fixar números citáveis | CHAT com busca | **Fable 5** | lista de pendências do arsenal v2.3 | fichas N1, par original + tradução | zero `RE-VERIFICAR` aberto |
| 7 | Fichas novas §A39–§A42 (multipersona), só se a F0-9 aprovou | CHAT com busca | **Fable 5** | §2.2 do `PLANO_v2` | 4 fichas no padrão do arsenal | Tseng e PrefDisco abertos em PDF e subidos de N2 para N1 |
| 8 | `MASTER_TEMPLATE.docx` derivado do v49: paleta petróleo, 4 caixas, ordem de front matter do v131 | CODE | **Sonnet 5** | template v49 + `GUIA_FORMATACAO` | template validado | as 4 caixas renderizam no PDF de prova; Prefácio antes do Sumário; créditos no fim |

---

## FASE 2 · O corpus antes da prosa (6 etapas · 5 a 6 sessões)

Esta é a trava do "ultra convincente": nada será impresso que não tenha acontecido.

| # | Etapa | Onde | Modelo | Entrada | Saída | Teste de saída |
|---|---|---|---|---|---|---|
| 9 | Agente-exemplo (1 página, atendimento realista) + conversa-seed anonimizada | CHAT | **Sonnet 5** | sua decisão da F0 item 5 | os dois artefatos | a seed contém uma falha real e reproduzível |
| 10 | Construir o Laboratório: 7 blocos + `plots.py`, partições ≤25 linhas | COLAB | **Sonnet 5** | estrutura §7 + specs | notebook | `Runtime › Run all` sem erro, dependências fixadas |
| 11 | Rodar com a seed e arquivar tudo | COLAB | **Sonnet 5** | notebook + seed | transcrições + 7 PNGs a 300 dpi | cada capítulo tem uma SAÍDA real arquivada |
| 12 | Validar o Ensaio Manual nas duas variantes | CHAT | **RAFAEL** + 2 pessoas | a mecânica travada na F0 item 6 | transcrição produzida por quem não codifica | um PM e um vendedor produzem a conversa simulada em 10 minutos. Se falharem, o produto reprova antes de imprimir |
| 13 | Rodar os 7 prompts em cadeia, 3 perfis | CHAT | **Opus 5** especifica · **Sonnet 5** executa as 21 rodadas | prompts + perfis | saída bruta arquivada | o prompt do Cap N isolado, sem a Capacidade N-1, não reproduz o resultado |
| 14 | Regravar a PRÉVIA no esqueleto resultado-first | CHAT | **Opus 5** | corpus + paleta | prévia | vira o gabarito de voz vigente |

---

## FASE 3 · Gate de valor (1 etapa · 1 sessão)

| # | Etapa | Onde | Modelo | Entrada | Saída | Teste de saída |
|---|---|---|---|---|---|---|
| 15 | O Simulador passa nos 5 critérios de domínio + teste de valor | CHAT | **Opus 5** como eng sênior de evals | corpus completo | gate assinado | você tomou **uma decisão real** com o Simulador. Reprova → conserta o produto, não a prosa |

**Este é o ponto de não retorno.** Se o Simulador não passar aqui, escrever é desperdício.

---

## FASE 4 · Escrita (24 etapas · 24 sessões)

Padrão que se repete doze vezes: **Sonnet monta o Pacote de v0 → Opus escreve numa conversa nova → scripts auditam → você aprova.**

| # | Etapa | Onde | Modelo | Saída |
|---|---|---|---|---|
| 16 | Pacote de v0 do E1 | CHAT | **Sonnet 5** | os 7 itens + contrato do capítulo |
| 17 | **E1 · Prefácio + Antes de começar** | CHAT (conversa nova) | **Opus 5** | com a frase de dogfooding e a nota do autor |
| 18 | Pacote de v0 do E2 | CHAT | **Sonnet 5** | — |
| 19 | **E2 · Introdução** | CHAT | **Opus 5** | teto duro de 4-5 páginas |
| 20 | Pacote de v0 do E3 | CHAT | **Sonnet 5** | — |
| 21 | **E3 · Cap 1 — O teste que passa em tudo** | CHAT | **Fable 5** | a skill congela depois deste capítulo: é o artefato que define todos os outros |
| 22 | Pacote de v0 do E4 | CHAT | **Sonnet 5** | — |
| 23 | **E4 · Cap 2 — Os cinco jeitos de quebrar** | CHAT | **Opus 5** | abertura Clear |
| 24 | Pacote de v0 do E5 | CHAT | **Sonnet 5** | — |
| 25 | **E5 · Cap 3 — A persona que não desmonta** | CHAT | **Opus 5** | + parágrafo da taxonomia (§A39) |
| 26 | Pacote de v0 do E6 | CHAT | **Sonnet 5** | — |
| 27 | **E6 · Cap 4 — O painel que discorda** | CHAT | **Opus 5** | abertura Clear |
| 28 | Pacote de v0 do E7 | CHAT | **Sonnet 5** | — |
| 29 | **E7 · Cap 5 — As três perguntas** | CHAT | **Opus 5** | canon do Juiz completo + Matriz de Adaptação |
| 30 | Pacote de v0 do E8 | CHAT | **Sonnet 5** | — |
| 31 | **E8 · Cap 6 — Da falha ao conserto** | CHAT | **Opus 5** | antes/depois + heatmap pass^k |
| 32 | Pacote de v0 do E9 | CHAT | **Sonnet 5** | — |
| 33 | **E9 · Cap 7 — O Simulador** | CHAT | **Opus 5** | + linha "menor nota entre personas" |
| 34 | Pacote de v0 do E10 | CHAT | **Sonnet 5** | — |
| 35 | **E10 · Apêndice — O Laboratório** | CHAT | **Opus 5** | cada bloco com SAÍDA real |
| 36 | **E11 · O que o método não entrega + Notas + Sobre o Autor + Agradecimentos** | CHAT | **Opus 5** | 6 aprendizados; Sobre o Autor a partir do v3 |
| 37 | **E12 · Passada de costura** | CHAT | **Opus 5** | pontes, ordem das 3 métricas, faixas 1–7 |
| 38 | Context Block atualizado a cada capítulo aprovado | CHAT | **Haiku 4.5** | ≤300 tokens |

**O ciclo de cada sessão de escrita**, depois que o Opus entrega:
`hunt_g1_marcas_v2.py` → `hunt_g2_ecos.py` → `hunt_g3_voz.py --ref` (CODE, sem modelo) → gates G2–G8 (**Sonnet 5**) → `book-editor-humanizer` (**Opus 5**, só se algum score < 9) → proposta → seu "siga" → docx (**Sonnet 5**).

Regra: BLOQUEIO do g1 e falha do g3 voltam para o Opus. REVISAR é decisão sua, item a item.

---

## FASE 5 · Evals de leitura (2 etapas · 2 sessões)

| # | Etapa | Onde | Modelo | Teste de saída |
|---|---|---|---|---|
| 39 | Trocar células 4/6/7b do `book_evaluator` (perfis: eng cético, dev-virou-AI-eng, PM técnico) | COLAB | **Sonnet 5** | as 5 métricas rodam |
| 40 | Rodar por capítulo e no manuscrito fechado | COLAB | **Gemini Flash** | todos acima do limiar. Reprovação do eng cético é prioridade máxima — é problema de honestidade, não de estilo |

Padrão de falha recorrente vira patch na skill por evidência — única exceção ao congelamento.

---

## FASE 6 · Figuras (5 etapas · 3 sessões + sua passada)

| # | Etapa | Onde | Modelo | Teste de saída |
|---|---|---|---|---|
| 41 | Fichas das 26 figuras: o que cada uma afirma, rótulos verbatim, onde vai o acento | CHAT | **Opus 5** | as 8 legendas afirmam, não descrevem |
| 42 | Gerar a cena `.excalidraw` inteira em um lote: 26 frames 700×420, régua 24/32/40 px | CHAT ou CODE | **Sonnet 5** | nenhum desenho vaza do frame |
| 43 | Passada humana no Excalidraw | — | **RAFAEL** | layout gerado sai simétrico demais; esta passada é o que separa figura de livro de figura de slide |
| 44 | `exc2livro.py svg` → `mapa` → `aplicar`; travar `ESCALA_PADRAO` | CODE | **Sonnet 5** | a saída imprime `texto de 24px = X pt` com valor único |
| 45 | `arte-kdp auditar` no Kindle e `--tinta` no impresso | CODE | script + **Sonnet 5** para ler | zero figura abaixo de 300 DPI efetivo; cobertura de tinta abaixo de 15% (inverter as caixas de prompt só no build impresso) |

Os 7 plots já saíram na etapa 11 e não passam por aqui.

---

## FASE 7 · Fechamento (3 etapas · 4 sessões)

| # | Etapa | Onde | Modelo | Teste de saída |
|---|---|---|---|---|
| 46 | Montagem: inserções em ordem decrescente de offset, `pack --original`, delta justificado, PDF das páginas tocadas | CODE | **Sonnet 5** | validação passa; `docProps/core.xml` e `app.xml` presentes e registrados |
| 47 | `amostra-kindle` sobre o docx montado | CHAT | **Sonnet 5** | os 4 gates: promessa em página ≤4 · o Simulador nomeado a ≤60% da amostra · corte em valor · zero página de desperdício |
| 48 | Parecer `diretor-editorial-big-five`, três etapas | CHAT | **Fable 5** | os quatro canais acima de 0,40 de FRC contra o controle negativo; veredicto APROVAR ou REVISAR |

**Depois do parecer, e só se ele passar:**
- Protocolo Buck — leitura sintética integral por persona de head de engenharia cético (CHAT, **Opus 5**). Achados viram edições cirúrgicas, nunca regeneração.
- Capa (`capa-best-seller`, #0F4C5C + `circulos`) — CODE, **Sonnet 5**.
- TOC, metadados, subtítulo na capa e na página da KDP — CODE, **Sonnet 5**.
- Submissão KDP + Hotmart (vídeo por sessão + link do Colab) — **RAFAEL**.

**Pós-lançamento, não bloqueia:** registrar o livro no Context Block da linha · rodar o Simulador sobre o próprio material de vendas (dogfooding público) · retrospectiva do que este roteiro muda para o livro 3.

---

## Contagem por modelo

| Modelo | Sessões | Onde pesa |
|---|---|---|
| Opus 5 | ~19 | 11 sessões de escrita + gates de julgamento + fichas de figura |
| Sonnet 5 | ~15 | pacotes de v0, corpus, docx, Excalidraw, montagem |
| Fable 5 | 4 | arsenal (2), Capítulo 1, parecer big five |
| Haiku 4.5 | ~8 | Context Block por capítulo + varreduras |
| Gemini Flash | 2 | evals de leitura |
| Script puro | ~40 execuções | os três `hunt`, `arte-kdp`, `validate`, `exc2livro` |

---

## Os quatro pontos onde o livro morre, se morrer

1. **Etapa 15.** Simulador que não passa no gate de valor. Nenhuma prosa salva.
2. **Etapa 12.** Ensaio Manual que o não-técnico não consegue executar em 10 minutos. O livro promete um Simulador e entrega, para a maioria dos leitores, um gerador de personas que nunca conversa.
3. **Etapa 21.** Capítulo 1 fraco. A skill congela nele; tudo depois herda o que ele estabeleceu.
4. **Etapa 48.** Quatro canais abaixo de 0,40 com título reprovado na prateleira. Aí o problema é de concepção, e o parecer manda reescrever sem ir à etapa 3 dele.

Tudo o mais é conserto barato.
