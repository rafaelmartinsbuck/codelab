# PRONTIDÃO DE ESCRITA v1.3 — Personas Sintéticas
**Parecer final antes da F4. v1.3 verifica o encaixe do FRAMEWORK DE MÉTRICAS/GOVERNANÇA e das PLATAFORMAS de eval/observabilidade (LangSmith, Arize/Phoenix, Braintrust, Vertex, Azure, AWS), formaliza a FRONTEIRA Livro 2×3 e incorpora §A37–§A38. Data: 12/07/2026.**

---

## 1. VEREDITO EXECUTIVO
O projeto está a **uma sessão de decisões (F0) + o corpus (F2)** de poder escrever o Cap 1. A arquitetura editorial é a mais sólida da linha até aqui: os gates são executáveis (não opinativos), o esqueleto resultado-first obriga prova antes de prosa, e a pesquisa de julho ancorou o livro no estado da arte com fontes primárias. Existem, porém, **um gap de produto real** (§3.2) e **um risco narrativo estrutural** (§2.2) que custam quase nada para corrigir agora e custariam refação de três capítulos se descobertos na F5.

## 1b. VERIFICAÇÃO TEMÁTICA (a pergunta: o livro considerou adequadamente cada tema?)
Critério: cobertura CERTA para um livro de 7 capítulos cujo produto é o Simulador — nem buraco, nem inchaço. O que pertence ao Livro 3 (Agent Evaluation — a Pirâmide) fica no Livro 3, com ponte declarada.

| Tema | Situação | Onde vive no livro | Ação |
|---|---|---|---|
| Métricas de avaliação de agentes | COBERTO forte | 3 métricas canônicas (§A3) + pass^k (§A4) + agora o TRIO de plataformas: Microsoft + Google trajectory/final (§A32b) + OpenAI graders (§A33) | Cap 5 cita as três plataformas em 1 parágrafo (patch no slot da sessão E7) |
| LLM-as-judge e variações | COBERTO e fechado | §A21 (vieses+mitigações) + **§A35 novo**: pareada · single-answer com âncoras (a do livro) · por rubrica/grader (a das plataformas) · painel de juízes | 1 parágrafo das 4 formas no Cap 5 (patch E7) |
| Eval offline / online / runtime | agora NOMEADO | **§A34 novo** compõe fichas existentes: offline=CI (§A24e/§A25b), online=usuário simulado (§A29), runtime=monitoração/traces (§A24e/§A32b/§A33) | 1 parágrafo no Cap 7; o Simulador vive nos 2 primeiros tempos |
| Orquestração | COBERTO forte | orchestrator-worker (§A14), ReAct vs. ator+rastreador (§A18), persona control+state tracking (§A8), A2A (§A19) | nenhuma |
| Observabilidade de IA | COBERTO no nível certo | Queijo Suíço + monitoração de produção (§A24d/e); traces citados via §A32b/§A33 | 1 frase no Cap 7 nomeando o ciclo; profundidade é do Livro 3 |
| AgenticOps / LLMOps | citação nominal, sem seção | §A34 autoriza UMA frase ("os nomes que a indústria dá a esse ciclo") | ponte da linha: Cap 7 → Livro 3 |
| FinOps | lacuna REAL → coberta com honestidade | §A34: custo do Simulador ancorado no ~15x tokens (§A14); número final SÓ do corpus próprio | parágrafo "quanto custa rodar" no Cap 7 (patch E9) + medir custo na F2 |
| Anthropic (estado da arte) | COBERTO forte | Demystifying evals (§A24), multi-agente 90,2% (§A14), system prompts/persona vectors (§A10), CAI (§A22), siconfância (§A23) | nenhuma |
| Google (estado da arte) | ERA o ponto fraco → agora forte | **§A32 novo**: User Simulation OFICIAL no ADK — ConversationScenario + personas com `violation_rubrics` (o espelho de indústria das "réguas observáveis" do Cap 3) + Vertex agent evaluation | Cap 3 ganha 1 frase-troféu; Cap 5 ganha o trio (patches E5/E7) |
| OpenAI (estado da arte) | ERA fraco em avaliação → coberto | **§A33 novo**: AgentKit Evals — datasets, trace grading, automated prompt optimization (o Prompt 6 do leitor como produto de plataforma) | Cap 6 ganha 1 frase (patch E8) |
| Adoção por grandes organizações | COBERTO | Sierra 35k/dia em CI (§A25), BMW/ICSE (§A30), mercado ASAPP/Cognigy (§A31), Anthropic/Google/OpenAI/Microsoft shipping como feature (§A24/§A32/§A33/§A3) | nenhuma |

Síntese: nenhum buraco restante exige capítulo novo — os quatro achados (§A32–§A35) entram como parágrafos cirúrgicos nos slots existentes, e a disciplina de escopo (trajetória/ops/observabilidade profunda = Livro 3) fica declarada, o que é assinatura da linha, não omissão. O ganho editorial maior: o Cap 3 agora pode dizer que **Google formalizou as réguas observáveis como `violation_rubrics`** e o Cap 5 sai de "duas métricas da Microsoft" para "as três maiores plataformas nomeiam a mesma separação — e nenhuma mede a Resolutividade", o que deixa a contribuição do livro mais nítida, não menos.

### Patches decorrentes nas sessões do ROTEIRO (aplicar na F0, sem regravar o arquivo)
E5 (Cap 3): +1 frase §A32a (violation_rubrics) no slot do trio de specs · E7 (Cap 5): trio de plataformas (§A3+§A32b+§A33) + as 4 formas do juiz (§A35) · E8 (Cap 6): +1 frase §A33 (flywheel/prompt optimization) · E9 (Cap 7): +parágrafo custo (§A34/FinOps) e +parágrafo ciclo em três tempos com ponte ao Livro 3 · F2: medir e arquivar o CUSTO de uma rodada completa do gate (tokens e R$) — vira o número do parágrafo FinOps.

## 1c. AUDITORIA ANTIALUCINAÇÃO (o leitor mais difícil não pode pescar nada)
O perigo deste livro nunca foi fonte inventada — as travas já matam isso. O perigo residual é mais fino: **fonte verdadeira com claim deformado, número de memória, ou ID de arXiv que não abre.** A v2.2 do arsenal fecha esse flanco com quatro mecanismos:

**1. Níveis de verificação em toda ficha.** N1 (primária aberta em sessão: 13 fichas — §A1, §A3, §A4, §A10, §A11, §A14, §A15, §A24, §A25, §A26, §A30, §A32, §A33) imprime definição e número; N2 (existência confirmada: 12 fichas) imprime tese SEM número; N3 (treinamento: 7 fichas clássicas) imprime fato prudente sem ano/citação até a F1; COMPOSIÇÃO assina como tese do livro. A espinha citável do livro é 100% N1 — nenhum capítulo depende de número fora desse grupo.

**2. Lista FECHADA de números imprimíveis hoje** (90,2% · 15x · <50% · pass^8<25% · 35.000/dia · ~90% resolução · CSAT 4.5 · >80% coverage · escala 1-5). Fora dela, número só nascendo do corpus com log. Isso é verificável por grep na F7: todo dígito do manuscrito ou está na lista, ou está no corpus, ou reprova.

**3. Auditoria de IDs arXiv com clique** na F1 — os nove IDs de 2026 vieram de busca, mas ID trocado é o primeiro erro que revisor hostil pesca; até o clique, as Notas usam autor+título+ano.

**4. Contingência do risco nº 1:** §A8 (âncora do Cap 6, verificada só por título). Se não confirmar, o Cap 6 re-ancora em §A24c + §A33 (ambas N1) sem perder autoridade — o plano B já está escrito.

**Referência essencial faltante encontrada e adicionada:** §A36 (*Synthetic Users, Real Differences*, validade concorrente vs. de conteúdo do simulador) — é exatamente a pergunta que o leitor-pesquisador faria em "O que o método não entrega", e agora o livro responde declarando qual validade persegue. Fora ela, a varredura não achou lacuna essencial: linhagem pré-LLM (§A20), seminal LLM-as-judge (§A21), benchmarks (§A4/§A26), plataformas (trio §A3/§A32/§A33), specs de comportamento (§A10/§A17/§A22), escala (§A2), vieses (§A23/§A27), sim2real (§A28), indústria (§A25/§A30/§A31) — o mapa está completo para o escopo de 7 capítulos.

## 1d. VERIFICAÇÃO: FRAMEWORK DE MÉTRICAS + PLATAFORMAS DE OBSERVABILIDADE
Chegou material novo — um framework de governança/métricas por tipo de agente (RAG, transacional, multi-agente, transversal, guardrails, FinOps) + o pedido de considerar plataformas (LangSmith, Openlayer, Vertex, Azure, AWS, Arize/Phoenix, Braintrust). Veredito: **quase tudo isso é o Livro 3 (Agent Evaluation — a Pirâmide), não o Livro 2** — e tratar essa fronteira com disciplina é o que protege os 7 capítulos. As fichas §A37 (plataformas) e §A38 (framework do Rafael) entraram no arsenal com a regra de fronteira explícita.

**O que ENTRA no Livro 2 (parágrafos cirúrgicos, não seções):**
- **"O tipo de agente decide a métrica"** (§A38) → 1 parágrafo no Cap 5: antes de julgar, a persona precisa saber se o agente é informacional, transacional ou multi-agente — creditado ao "framework de governança que times maduros usam". Conecta o livro ao vocabulário corporativo (NIST, ISO 42001) sem virar manual de governança.
- **LLM-as-judge + ground truth congelado é padrão de indústria** (§A38, linhas SQL-02/SUM-01/CRT-01 do doc) → reforça o canon do Juiz no Cap 5, agora com quarta fonte independente.
- **A categoria "plataforma de eval + observabilidade"** (§A37) → substitui e amplia o parágrafo de mercado do Cap 7: o Simulador é **pré-produção proativa** (gera o usuário que ainda não reclamou); LangSmith/Arize/Braintrust/Vertex/Azure/AWS são majoritariamente **observabilidade** (olham o trace do que o agente já fez). Camadas complementares do Queijo Suíço, não concorrentes. Regra dura: nomear a categoria + 2-3 exemplos, **zero ranking, zero número de fornecedor** (comparativos são SEO enviesado).
- **A Resolutividade dialoga com NEG-01/RAG-08 do framework** (NPS/valor) → o Cap 5 pode dizer que a Resolutividade é a versão conversacional e preditiva do NPS que a governança já mede por survey — turno a turno, pelo Juiz, antes do deploy. Isso deixa a contribuição do livro legível para quem vem de um comitê de IA.

**O que NÃO ENTRA (é a Pirâmide do Livro 3 — 1 frase de ponte no Cap 7 e para):**
trajectory correctness, tool selection accuracy, loop rate, schema compliance ≥99%, RAG context precision/recall, guardrails/red-teaming, SLOs de produção, plano de monitoramento de 10 pontos, auditoria/logging, observabilidade profunda (tracing OTel, drift detection). Tentar cobrir isso aqui transformaria um livro de produto de 7 capítulos num tratado de MLOps — e mataria as duas coisas.

**Ganho editorial líquido:** o Cap 5 fica mais forte (quatro fontes independentes convergindo na separação de métricas, e a Resolutividade contrastada com o NPS da governança) e o Cap 7 ganha um mapa de mercado honesto que nenhum concorrente do nicho oferece — sem inchar. O FinOps já previsto (§A34) agora tem lastro no CON-01 do framework: o parágrafo "quanto custa rodar" cita que governança madura trata custo/token como métrica transversal, e o número final sai do corpus.

### Patches decorrentes (aplicar na F0, sem regravar o ROTEIRO)
E7 (Cap 5): +parágrafo "tipo de agente decide a métrica" (§A38) e +frase Resolutividade×NPS · E9 (Cap 7): trocar o parágrafo de mercado por §A37 (categoria plataforma, pré-produção vs. observabilidade) + a frase de ponte de escopo ao Livro 3 (§A38 fronteira) · Notas: +NIST AI RMF, ISO/IEC 42001, arXiv:2305.10468, RAGAS se citados (todos passam pela F1).

## 2. AVALIAÇÃO DE STORYTELLING E NARRATIVA

### 2.1 O que já envolve o leitor (e por quê)
A cena das 22h17 é o melhor ativo narrativo do livro: horário específico, três palavras de abertura ("meu pedido sumiu"), e a frase final que nenhum dashboard mede ("esquece, vou cancelar") — dor de negócio concreta, não conceito. O Prefácio abre em tensão Sinek legítima (dois times, mesmo agente, destinos opostos) e agora fecha com o argumento de autoridade industrial (Anthropic nomeia a técnica; Sierra roda 35 mil/dia; ICSE julga por diversidade), o que transforma "aposta de autor" em "rotina de indústria que eu vou te destravar". O esqueleto resultado-first é o mecanismo de engajamento mais forte: o leitor vê a prova ANTES de ser convidado a agir — inverte o contrato dos livros de método, que pedem fé primeiro. As faixas de progresso (N DE 7) criam psicologia de conclusão, o fechamento em descoberta proíbe o anticlímax da pergunta retórica, e o teste do arco das figuras garante que até quem folheia entende o livro. A alternância Sinek/Clear evita a monotonia de abertura que mata livro técnico no capítulo 4.

### 2.2 O risco estrutural: elenco descontínuo (correção proposta — decisão P0 nova)
Do jeito que o gabarito está, cada capítulo abre com uma cena NOVA (a pergunta feita de cinco jeitos, a persona que derrete, o dashboard de 40 indicadores...). Todas boas — mas sem um fio humano contínuo, o livro arrisca ler como **sete artigos excelentes em vez de UMA história**. A correção é barata porque já está implícita no desenho do corpus: a conversa das 22h17 É a seed que atravessa todos os Colabs. Proposta — promover isso a **regra narrativa declarada**: *a cliente das 22h17 atravessa o livro inteiro*. Ela vira persona mínima no Cap 1, revela seu arquétipo no Cap 2, ganha spec no Cap 3, entra no painel no Cap 4 (agora acompanhada de quatro que discordam dela), é julgada no Cap 5, o fix que a satisfaz é o exemplo do Cap 6, e no Cap 7 ela é a primeira linha do dashboard que libera o deploy. O leitor acompanha UM caso do bug ao gate — e a última página paga a primeira. As cenas novas de abertura continuam existindo (são o ar fresco de cada capítulo); a cliente é o baixo contínuo. **Custo: 1 linha de regra na estrutura + disciplina nas pontes entre capítulos. Não exige patch na skill.**

### 2.3 Dois riscos menores (disciplina, não mudança)
A Introdução carrega hoje 5 slots visuais + tabela + timeline: limite duro de 4-5 páginas, ou ela vira museu antes do leitor agir. E o Cap 7 acumulou funções na atualização (Sierra, Fronteira dupla, mercado, ritual, dashboard): o roteiro já limita a Fronteira a 1 página e o mercado a 1 parágrafo — manter esses tetos como pré-condição da sessão E9.

### 2.4 A dimensão AUTOR: a voz precisa ser assinável (nova decisão F0)
O storytelling está tecnicamente correto, mas há um flanco de autenticidade: a skill PROÍBE o Opus de inventar "vi equipes que..." — e não dá a ele nenhum material verdadeiro para usar no lugar. Resultado provável sem correção: uma prosa impessoal demais (segura, porém fria) ou a tentação da vinheta inventada (vetada). Correção em duas peças, ambas baratas:
**(a) Banco de Campo (F0, item 7 — 20 minutos do Rafael):** Rafael dita 5-8 observações VERDADEIRAS de campo, anonimizadas, uma frase cada ("num projeto de fintech, o agente aprovado em homologação caiu no primeiro cliente que respondia por áudio transcrito" — esse nível). Elas viram o único estoque autorizado de primeira pessoa; o Opus cita dali ou não cita. Cada uma sobrevive ao teste do LinkedIn: se alguém perguntar num comentário, o Rafael sustenta.
**(b) O dogfooding sobe para o Prefácio (1 frase):** o fato mais forte e 100% verdadeiro da linha — *este método audita os próprios livros: leitores sintéticos estressaram cada capítulo antes de você lê-lo* — hoje está escondido na bio. Uma frase no Prefácio transforma o autor de narrador em praticante, e é literalmente verificável (o book_evaluator existe). Nenhum concorrente do nicho pode escrever essa frase.
Com (a)+(b), a nota do autor (compostos ficcionais declarados) deixa de ser um disclaimer defensivo e vira moldura de honestidade em volta de experiência real — que é a assinatura da linha.

## 3. AVALIAÇÃO DE PRODUTO: O LIVRO CONSTRÓI ALGO USÁVEL?

### 3.1 A cadeia fecha
Sim — e é o ponto mais forte do projeto. O cadeado de valor é real: cada prompt ingere a Capacidade anterior; o prompt isolado é esqueleto incopiável. A saída final é tripla e endereça os três leitores: o **comando de Ativação** com os dados do leitor embutidos + ritual quinzenal (quem não codifica), o **notebook com gate()** plugável em CI (quem codifica), e o **dashboard de 1 página** (quem decide). O critério de aceite do Laboratório ("Run all reproduz todas as figuras") e o F3 ("Rafael tomou 1 decisão real com o Simulador") garantem que o produto existe antes da prosa — nenhum livro de prompt no mercado brasileiro tem essa trava.

### 3.2 O GAP CRÍTICO: a mecânica do Ensaio Manual (decisão P0 nova)
Há um elo não especificado que trava exatamente o leitor majoritário (não-técnico) no momento-clímax: **o Prompt 5 (Juiz) ingere "1 conversa simulada" — mas nenhum documento define COMO quem não codifica produz essa conversa.** A persona precisa conversar com o agente do leitor; em código isso é o Bloco 2, mas no caminho só-prompt a mecânica precisa ser desenhada. Proposta a travar na F0 — o **Ensaio Manual**, com duas variantes:
(a) **Duas janelas** — a spec da persona roda num chat; o leitor copia cada fala da persona para o SEU agente (o chat do produto, o WhatsApp do atendimento, o bot interno) e cola a resposta de volta; 6-8 turnos, 10 minutos; a transcrição resultante é a "conversa simulada" que alimenta o Juiz.
(b) **Janela única (quando o agente é colável)** — se o "agente" do leitor é um prompt/fluxo que cabe num chat, um comando único orquestra persona×agente na mesma conversa e devolve a transcrição pronta.
Onde entra: sub-seção curta no fim do Cap 3 ou abertura do Cap 4 ("como fazer sua persona conversar de verdade") + a faixa Sua vez dos Caps 4-6 referenciando a variante escolhida. **A F2 é obrigada a rodar o corpus dos 3 perfis USANDO essa mecânica** — se o PM e o vendedor do corpus não conseguirem produzir a conversa simulada em 10 minutos, o produto reprova antes de imprimir. Sem esse elo, o livro promete um Simulador e entrega, para 70% dos leitores, um gerador de personas que nunca conversa.

### 3.3 Reforço da verificação temática no produto
As fichas novas fortalecem o produto sem mudá-lo: as réguas observáveis do Prompt 3 agora têm espelho de indústria nomeado (violation_rubrics do ADK, §A32), e o Prompt 6 é o mecanismo manual do que a OpenAI automatizou como prompt optimization (§A33) — o leitor termina sabendo operar E auditar as plataformas. A Resolutividade segue sendo o que nenhuma das três plataformas mede: a tese do livro saiu da verificação mais forte.

### 3.4 Honestidades que já estão cobertas
O gate do não-codificador é ritual quinzenal, não CI — a frase-guarda ("o que escala é o par agente+gate") e o aprendizado 5 já enquadram isso sem inflar a promessa. O gap sim2real virou os cinco aprendizados com fonte. A promessa da capa passou no gate AB com as fichas novas.

## 4. INVENTÁRIO COMPLETO

### 4.1 Na pasta do projeto hoje
| Arquivo | Estado | Ação |
|---|---|---|
| personas-sinteticas-rewriter_SKILL.md (v2) | vigente | patch F0 (glossário +benevolence bias/Queijo Suíço; subtítulo no cabeçalho) e congelar |
| ARSENAL_VERIFICADO_v1.md | superado | **substituir pela v2.3** (manter v1 fora da pasta, como histórico) |
| LIVRO_ESTRUTURA_COMPLETA_v1.md | vigente | manter; lê-se junto com o Adendo v1.3 |
| MANIFESTO_E_PLANO_v3.md | vigente | manter |
| Personas_Sinteticas_GABARITO_MASTER_v2.docx | superado | **substituir pela v3** (binário editado por XML, estilo preservado) |
| SOBRE_O_AUTOR_LINHA_v2.md | vigente | manter; slots [CV] preenchem na F0 |
| SUBTITULOS_LINHA_v1.md | vigente | manter como registro da decisão de capa |
| SUBTITULOS_MW_v1.md | fora de escopo | **mover para o projeto do Modern Workflows** (ruído aqui) |
| hunt_g2_ecos.py | vigente | manter |

### 4.2 Gerados nesta conversa (prontos, ainda não estão na pasta)
| Arquivo | O que é |
|---|---|
| ARSENAL_VERIFICADO_v2.3.md | +§A24-§A38, auditoria antialucinação por níveis, e a fronteira de escopo Livro 2×3 (Anthropic evals, Sierra 35k/τ³, benevolence bias, sim2real 3 pernas, ICSE/BMW, mercado), gate AB da capa, pendências F1 recalculadas |
| ESTRUTURA_ADENDO_v1.3_SUBTITULO_E_STORYTELLING.md | subtítulo travado + cascata, storytelling por capítulo, os cinco aprendizados |
| ROTEIRO_PRODUCAO_v1_OPUS_E_GEMINI.md | 36 passos com dono e teste de saída; protocolo-padrão das 12 sessões Opus; 20 prompts Gemini com bloco de estilo |
| Personas_Sinteticas_GABARITO_MASTER_v3.docx | o binário v2 com as 10 mudanças aplicadas por edição cirúrgica; validado, +18 parágrafos, zero mudança de estilo |
| hunt_g1_marcas.py | **novo (hoje)** — o sweep grep-ável da lista de caça, citado em skill/estrutura/roteiro mas até agora inexistente |
| whitelist_ecos.txt | **novo (hoje)** — os ecos deliberados exigidos pelo hunt_g2 e pelo Adendo §3 |
| PRONTIDAO_ESCRITA_v1.3.md | este parecer (temática + antialucinação + autor-voz + fronteira de escopo/plataformas) |

### 4.3 Faltantes (não existem em lugar nenhum — bloqueiam fases específicas)
| Item | Bloqueia | Dono | Observação |
|---|---|---|---|
| **Conversa-seed real (anonimizada) OU decisão de usar a seed ficcional-composta** | F2 | Rafael | insumo nº 1 do corpus; a nota do autor precisa refletir a escolha |
| **Framework de métricas/governança do Rafael (§A38)** | Cap 5/7 (pontes) | Rafael | salvar na pasta como AI_METRICS_FRAMEWORK_ref.md — fonte da ficha §A38 e ponte declarada ao Livro 3 |
| **Agente-exemplo** (o agente que o corpus estressa: prompt de atendimento simples e realista) | F2 | Rafael especifica, Fable monta | 1 página; sem ele não há falha para exibir |
| book_evaluator.ipynb | F5 | Rafael copia do projeto PE | células 4/6/7b trocam na F5 |
| Bloco de estilo hand-drawn do PLANO_FIGURAS (PE) | F6 | Rafael copia do projeto PE | conferir contra o bloco do Roteiro §C e unificar |
| GUIA_FORMATACAO + template v49 (PE) | F1 | Rafael copia do projeto PE | base do MASTER_TEMPLATE; o gabarito v3 serve de referência de conteúdo, não de template |
| PREVIA_KINDLE | F2 | — | será regravada na F2; ok não existir hoje |

## 5. A PASTA NA SEGUNDA-FEIRA (lista definitiva — 13 itens)
1. personas-sinteticas-rewriter_SKILL.md (v2, patch F0 pendente)
2. **ARSENAL_VERIFICADO_v2.3.md**
3. LIVRO_ESTRUTURA_COMPLETA_v1.md
4. **ESTRUTURA_ADENDO_v1.3_SUBTITULO_E_STORYTELLING.md**
5. **ROTEIRO_PRODUCAO_v1_OPUS_E_GEMINI.md**
6. MANIFESTO_E_PLANO_v3.md
7. **Personas_Sinteticas_GABARITO_MASTER_v3.docx**
8. SOBRE_O_AUTOR_LINHA_v2.md
9. SUBTITULOS_LINHA_v1.md
10. **hunt_g1_marcas.py**
11. hunt_g2_ecos.py
12. **whitelist_ecos.txt**
13. **PRONTIDAO_ESCRITA_v1.3.md** (este arquivo)
Saem: ARSENAL v1, GABARITO v2, SUBTITULOS_MW. Entram do projeto PE (ação Rafael): book_evaluator.ipynb, bloco do PLANO_FIGURAS, GUIA_FORMATACAO/v49.

## 6. A F0 REVISADA (agora 7 decisões, 1 sessão)
1. Pergunta canônica da Resolutividade ("voltaria amanhã?" vs. "recomendaria?").
2. Nomes PT dos 5 arquétipos (proposta em pauta).
3. Texto exato da nota do autor (depende da decisão da seed, item 5).
4. Paleta (confirmar petróleo).
5. **NOVA — Seed do corpus:** conversa real anonimizada ou composto ficcional declarado.
6. **NOVA — Mecânica do Ensaio Manual** (§3.2): duas janelas como padrão + janela única como atalho, e em qual capítulo a sub-seção entra.
7. **NOVA — Banco de Campo + dogfooding no Prefácio** (§2.4): Rafael dita as 5-8 observações verdadeiras e aprova a frase do dogfooding.
Depois da F0: patch da skill (glossário/whitelist/subtítulo) → congela → F1/F2 em paralelo → Cap 1.
