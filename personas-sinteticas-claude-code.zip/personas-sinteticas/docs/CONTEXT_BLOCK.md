# CONTEXT BLOCK — memória viva do livro (≤300 tokens)
Atualizado ao fim de cada sessão de escrita. É o único resumo que entra nas sessões seguintes — o manuscrito inteiro nunca é relido.

## Cenas já usadas (não repetir)
- (vazio)

## Âncoras já gastas
- (vazio)

## Aberturas já usadas (Sinek/Clear alternando)
- (vazio)

## Promessa aberta para o próximo capítulo
- (vazio)

## Convenções fixadas em sessão
- (vazio)
