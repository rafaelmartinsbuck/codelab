# ARSENAL_VERIFICADO — Livro Personas Sintéticas (v2.3, plataformas de eval/obs + fronteira de escopo, 12/07/2026)
**Regra dura (inalterada):** capítulo só cita o que tem ficha aqui, letra por letra. Toda ficha carrega status.
**O que muda na v2.3:** fichas §A37 (plataformas de eval/observabilidade: LangSmith, Arize/Phoenix, Braintrust, Confident AI/DeepEval, Langfuse, W&B Weave, Vertex, Azure, AWS/Bedrock) e §A38 (framework de governança/métricas por tipo de agente — o material do Rafael); e a FRONTEIRA DE ESCOPO Livro 2 × Livro 3 formalizada. **O que mudou na v2.2:** (0) AUDITORIA ANTIALUCINAÇÃO — toda ficha agora carrega NÍVEL de verificação (tabela na seção nova abaixo) e a regra de impressão por nível vira gate; ficha §A36 adicionada. **O que mudou na v2.1:** fichas §A32–§A35 adicionadas (verificação temática: plataformas de avaliação Google e OpenAI, variações do juiz, ciclo offline/online/runtime); demais conteúdos da v2 preservados letra por letra. **O que mudou na v2:** (1) subtítulo oficial do livro atualizado — *"Encontre as falhas antes dos seus usuários — e entregue sistemas de IA que escalam."*; (2) fichas §A24–§A31 adicionadas (pesquisa de 11/07/2026, fontes primárias abertas nesta sessão); (3) a pendência nº 2 da v1 ("1 caso de indústria com fonte primária") está RESOLVIDA duas vezes (§A24 e §A25); (4) pendências recalculadas ao fim.

## FICHAS §A1–§A23 — mantidas integrais da v1 (não repetidas aqui; a v1 permanece válida como anexo)

---

## FICHAS ADICIONADAS NA 3ª RODADA (11/07/2026) — com DEFINIÇÕES DE MÉTODO
*Instrução antialucinação: ao citar qualquer item abaixo, usar a DEFINIÇÃO exatamente como escrita aqui.*

**§A24 — Anthropic, "Demystifying evals for AI agents" (fonte OFICIAL de engenharia — a validação de indústria do método inteiro).** anthropic.com/engineering/demystifying-evals-for-ai-agents (2025-26).
CLAIMS CITÁVEIS (paráfrase fiel, verificada nesta sessão):
(a) para agentes conversacionais, a qualidade da interação em si é parte do que se avalia, e as evals eficazes **"frequentemente exigem um segundo LLM para simular o usuário"** — ou seja: a técnica central do livro é recomendação oficial de engenharia da Anthropic, com esse nome;
(b) **o passo 1 recomendado é converter falhas reportadas por usuários reais em casos de teste** ("comece com o que você já testa manualmente; se já está em produção, olhe o bug tracker e a fila de suporte") — é EXATAMENTE a Capacidade 1 do livro (a conversa real que deu errado vira o primeiro caso de teste);
(c) critério de qualidade de tarefa: **dois especialistas do domínio chegariam independentemente ao mesmo veredito passa/reprova**;
(d) **modelo do Queijo Suíço** (Swiss Cheese, da engenharia de segurança): nenhuma camada de avaliação pega tudo — evals automatizadas pré-launch/CI + monitoração de produção + A/B + revisão de transcrições se sobrepõem para que a falha que escapa de uma camada seja pega por outra;
(e) mapeamento por estágio: evals automatizadas rodam a cada mudança do agente como primeira linha de defesa; monitoração de produção detecta drift pós-launch.
USO NO LIVRO: Cap 1 (b, abre o capítulo com autoridade), Cap 5 (a — "segundo LLM simulando o usuário" é nome de indústria), Cap 6 (c), Cap 7 e "O que o método não entrega" (d/e — o Simulador é UMA fatia do queijo, dita com fonte).
Status: **VERIFICADO** (fonte primária lida nesta sessão).

**§A25 — Sierra, "Simulations: the secret behind every great agent" (o caso de produção em escala — o número que sustenta o subtítulo).** sierra.ai/blog/simulations-the-secret-behind-every-great-agent (mai/2026).
CLAIMS CITÁVEIS: (a) clientes da Sierra rodam **mais de 35.000 testes simulados por dia** (e crescendo), atingindo taxas de resolução de até ~90% e CSAT acima de 4.5/5.0; (b) simulações plugam **direto no CI/CD** (GitHub Actions/linha de comando); (c) simulações não são só para engenheiros — times de CX criam e rodam cenários sem código, e mudanças em jornadas devem passar nas simulações antes de publicar; (d) a plataforma cria "usuários" que variam idioma, conforto com tecnologia e tom — ex.: o usuário que soletra o e-mail letra a letra vs. diz de uma vez; (e) variedade é a chave — cada cenário testa o agente "in the wild", não só o caso óbvio.
USO NO LIVRO: Prefácio (o método já é rotina industrial, não aposta), Cap 7 (o gate do leitor é a versão de 1 pessoa do que a Sierra opera em escala — é isto que "sistemas de IA que escalam" significa na capa), Cap 4 (d/e — variedade especificada).
Status: **VERIFICADO** (fonte primária lida nesta sessão).

**§A26 — τ³-Bench (Sierra, mai/2026): a fronteira é voz.** sierra.ai/blog/bench-advancing-agent-benchmarking-to-knowledge-and-voice + repo github.com/sierra-research/tau2-bench (que hoje suporta avaliação por voz full-duplex).
DEFINIÇÃO: extensão do τ-bench para **conhecimento e voz**: o usuário simulado fala, comete erros de áudio (soletra código de confirmação e o agente ouve uma letra errada), tem "sim" perdido no ruído de fundo, e **não espera passivamente o agente terminar — interrompe e avança, com parâmetros configuráveis de paciência, interruptividade e aversão a silêncio**.
LEITURA CANÔNICA: os "traços comportamentais" que o Cap 2 ensina a especificar em texto (impaciência, interrupção) já viraram **parâmetros de configuração** no benchmark líder — a spec de comportamento (Cap 3) é o formato para onde a indústria converge. τ³ também confirma a linha evolutiva τ → τ² → τ³ (estado final → dual-control → voz), que fecha a genealogia da engenharia (§A20).
USO NO LIVRO: seção "Fronteira" do Cap 7 ganha segundo item ao lado do A2A: **voz** (o Simulador do leitor é texto; a fronteira publicada é o mesmo desenho falando).
Status: **VERIFICADO** (fonte primária lida nesta sessão).

**§A27 — Benevolence bias (o nome de pesquisa para "persona ingênua não estressa nada").** *Efficient Agent Evaluation via Diversity-Guided User Simulation*, arXiv:2604.21480 (2026).
DEFINIÇÃO (verbatim-fiel): limitação-chave dos simuladores LLM padrão é o **"benevolence bias" — a tendência de serem cooperativos demais e, portanto, não representativos do comportamento real de usuários**; o paper propõe guiar a simulação por DIVERSIDADE para tornar a avaliação eficiente.
LEITURA CANÔNICA: fecha o triângulo do Cap 2 — siconfância do assistente (§A23, Sharma/Anthropic) + siconfância do usuário sintético ingênuo (§A11, NN/g) + agora o nome técnico do fenômeno no simulador (benevolence bias). O Cap 2 pode dizer: *o campo deu nome ao problema; a resposta é a mesma do livro — diversidade especificada, não pedida*.
Status: **VERIFICADO** como existente com o claim de definição (abstract/related work lidos nesta sessão); **RE-VERIFICAR na F1** números internos antes de citar qualquer resultado quantitativo.

**§A28 — O gap sim2real ganhou corpo (a seção de honestidade agora tem três pernas).**
(a) Zhou et al., *Mind the Sim2Real Gap in User Simulation for Agentic Tasks*, arXiv:2603.11245 (2026) — já era §A9;
(b) **NOVO:** *Lost in Simulation: LLM-Simulated Users are Unreliable Proxies for Human Users in Agentic Evaluations*, arXiv:2601.17087 (2026) — usa o próprio τ-bench como testbed e mostra que usuários simulados divergem de humanos em avaliações agênticas;
(c) **NOVO:** Zhu et al., *RealUser-Sim: Bridging the Reality Gap in Agent Benchmarking via Grounded User Simulation*, arXiv:2605.20204 (2026) — a resposta do campo: **ancorar o simulador em dados reais de usuário** (grounding) para fechar o gap.
LEITURA CANÔNICA para "O que o método não entrega": o campo já mediu que simulador ≠ humano (b), nomeou o gap (a) e está fechando-o com grounding em dado real (c) — que é exatamente a regra de ouro do livro (todo traço cita o trecho da conversa real que o sustenta). A honestidade do livro e a defesa do método são a MESMA frase: *o simulador só vale o quanto está ancorado em comportamento real — por isso a Capacidade 1 vem antes de todas*.
Status: (b) e (c) **VERIFICADOS** como existentes com claim de tese (títulos/abstracts nesta sessão); **RE-VERIFICAR na F1** conclusões e números exatos.

**§A29 — Survey canônico de avaliação de agentes (o guarda-chuva acadêmico).** Mohammadi et al., *Evaluation and Benchmarking of LLM Agents: A Survey*, arXiv:2507.21504 (2025); + Yehudai et al./Shmueli-Scheuer, *Survey on Evaluation of LLM-based Agents*, arXiv:2503.16416.
CLAIM CITÁVEL (2507.21504, verificado): avaliação **online/dinâmica** usa simulações e proxies de usuário reagindo em tempo real ao agente, e é crucial para achar problemas **que o teste estático não descobre**.
USO: Introdução/Cap 1 — a distinção estático × dinâmico com fonte de survey, em uma frase.
Status: **VERIFICADO** (trecho lido nesta sessão).

**§A30 — DeepTest/ICSE 2026 + BMW: teste de LLM virou competição de engenharia de software.** Sorokin, Vasilev, Pasini, *DeepTest Tool Competition 2026: Benchmarking an LLM-Based Automotive Assistant*, arXiv:2604.12615 (2026).
DEFINIÇÃO: primeira competição de testing de LLM (workshop DeepTest, ICSE 2026), com sistema real fornecido pela BMW (assistente de manual do carro); ferramentas competiram em **expor falhas** (inputs em que o sistema deixa de mencionar avisos de segurança do manual) e foram avaliadas por **efetividade E diversidade das falhas descobertas**.
LEITURA CANÔNICA: (i) a comunidade de engenharia de software (ICSE) adotou o problema — teste de agente é disciplina, não hack; (ii) o critério da competição é o conceito-âncora nº 1 do livro: não basta achar falhas, elas têm que ser **diversas** (cobertura). USO: Cap 4 (cobertura como critério de indústria E academia) ou Introdução.
Status: **VERIFICADO** (abstract da fonte primária lido nesta sessão).

**§A31 — O ecossistema de produto confirma a categoria (contexto de mercado, citar sem endosso).** ASAPP "Simulation Agent" (asapp.com/blog/prove-before-production..., 2026) — capacidade de simulação de clientes com personalidades/objetivos/edge cases integrada à plataforma de CX, criada porque "os times que configuram automação raramente são os que têm capacidade de engenharia para manter scripts de teste"; Cognigy "Simulator" (jan/2026); plataformas de eval (Confident AI/DeepEval, Maxim, LangWatch) vendendo simulação multi-turn com personas como recurso central em 2026.
USO NO LIVRO: 1 parágrafo no Cap 7 ou na Introdução — a categoria "simular o usuário antes da produção" virou feature de mercado em 2025-26; o livro ensina o leitor a TER o método (portável, seu), não a alugar a feature. Regra: citar como fenômeno de mercado, sem ranquear fornecedores.
Status: **VERIFICADO** (fontes primárias dos dois primeiros lidas nesta sessão).


---

## FICHAS ADICIONADAS NA VERIFICAÇÃO TEMÁTICA (12/07/2026)

**§A32 — Google: User Simulation OFICIAL no ADK + avaliação de agentes no Vertex (a validação mais forte do Cap 3).** (a) Google Developers Blog, *Announcing User Simulation in ADK Evaluation* (nov/2025) + docs oficiais google.github.io/adk-docs/evaluate/user-sim.
DEFINIÇÃO: o ADK (Agent Development Kit) gera dinamicamente o lado do usuário da conversa via modelo generativo; uma simulação é definida por um **ConversationScenario** = `starting_prompt` (abertura fixa) + `conversation_plan` (metas de alto nível) + `user_persona`. **A persona é definida por COMPORTAMENTOS, cada um com `violation_rubrics` — rubricas que o avaliador usa para verificar se o usuário simulado SEGUIU o comportamento declarado.** Personas pré-construídas: EXPERT, NOVICE, EVALUATOR. O blog declara a motivação: scripts fixos de user_input/expected_output são frágeis e quebram a cada mudança do agente; simulação orientada a metas testa a INTENÇÃO, não o caminho.
(b) Vertex AI Gen AI Evaluation Service — agent evaluation (blog oficial, jan/2025; docs 2026): duas categorias de métricas — **resposta final** (o agente atingiu a meta?) e **avaliação de TRAJETÓRIA** (o caminho: ferramentas certas, na ordem certa), com traces das interações no relatório.
LEITURA CANÔNICA: (i) as "réguas observáveis" do Cap 3 têm agora espelho de indústria com nome — `violation_rubrics`: a spec de comportamento verificável é o formato que o Google adotou; (ii) o Cap 5 ganha o TRIO de plataformas — Microsoft (Intent Resolution/Task Adherence, §A3) + Google (final response/trajectory, §A32b) + OpenAI (graders/trace grading, §A33) — as três nomeiam a mesma separação que o livro ensina; (iii) a linha de trajetória NÃO entra no produto deste livro (é a Pirâmide do Livro 3 — Agent Evaluation), entra como 1 frase de fronteira.
Status: **VERIFICADO** (blog oficial + docs oficiais lidos nesta sessão); RE-VERIFICAR na F1 os nomes exatos dos behaviors/personas na versão vigente dos docs.

**§A33 — OpenAI: AgentKit Evals (datasets · trace grading · otimização automática de prompt).** openai.com/index/introducing-agentkit (DevDay, out/2025) + developers.openai.com/api/docs/guides/trace-grading e agent-evals.
DEFINIÇÃO: **trace** = registro de ponta a ponta de UMA execução (chamadas de modelo, tool calls, guardrails, handoffs); **trace grading** = graders (critérios estruturados, LLM-avaliador) rodando sobre conjuntos de traces para achar regressões e failure modes em escala; **datasets** = casos de teste expandidos com graders automáticos + anotações humanas; **automated prompt optimization** = prompts melhorados gerados a partir das notas dos graders e do feedback humano; suporte a modelos de terceiros.
LEITURA CANÔNICA: o loop do Cap 6 (falha → fix → re-teste com registro) é exatamente o "flywheel" que a OpenAI vendeu como produto — com um detalhe a favor do livro: a otimização automática de prompt da OpenAI É o Prompt 6 do leitor executado por plataforma. O leitor aprende o mecanismo que a plataforma automatiza — e por isso sabe auditá-la.
Status: **VERIFICADO** (anúncio oficial + docs oficiais lidos nesta sessão); RE-VERIFICAR nomenclatura vigente na F1.

**§A34 — O ciclo de avaliação em três tempos: offline · online · runtime (nomear UMA vez, no Cap 7).**
DEFINIÇÃO COMPOSTA (todas as pernas já têm ficha): **offline/pré-deploy** — evals automatizadas rodando a cada mudança do agente, primeira linha de defesa em CI (§A24e; §A25b: simulações no GitHub Actions; §A3: batch via SDK); **online/dinâmica** — avaliação com usuário simulado reagindo em tempo real ao agente, acha o que o teste estático não acha (§A29, verbatim do survey); **runtime/produção** — monitoração contínua pós-deploy pega o drift que a simulação não previu (§A24e), com traces de execução (§A32b, §A33).
LEITURA CANÔNICA: o Simulador do livro vive nos DOIS primeiros tempos (é offline no gate, online na mecânica); o terceiro tempo é nomeado com fonte e apontado para o ritual quinzenal + o Livro 3. Os termos de disciplina (LLMOps/AgenticOps/observabilidade) podem ser citados em UMA frase como "os nomes que a indústria dá a esse ciclo" — sem virar seção. FinOps do Simulador: o custo é real (§A14: multiagente ~15x tokens de um chat) e vira 1 parágrafo honesto no Cap 7 ("quanto custa rodar") com número medido no corpus próprio, nunca estimado.
Status: composição de fichas verificadas; nada novo a re-verificar.

**§A35 — As variações do LLM-as-judge que o Cap 5 declara (fecha o §A21).**
DEFINIÇÃO DAS FORMAS: (a) **pareada** (A vs. B — a do MT-Bench/Arena; sofre position bias, §A21); (b) **single-answer com âncoras de escala** — a forma do Juiz do livro (mitiga position bias, §A21); (c) **por rubrica/grader** — critérios estruturados verificáveis por item, a forma que as plataformas adotaram (graders do AgentKit §A33; `violation_rubrics` do ADK §A32; evaluators 1-5 com threshold do Azure §A3); (d) **painel/júri de juízes** — múltiplos juízes agregados para reduzir viés de um único modelo, citada como variação existente sem virar método do livro.
LEITURA CANÔNICA (Cap 5, 1 parágrafo): o Juiz do livro é (b) com exigência de evidência — e as três réguas dele são rubricas no sentido de (c); quem quiser endurecer o gate agrega juízes (d). Dizer as quatro formas em um parágrafo é o que separa o capítulo de um tutorial.
Status: composição de §A21 + §A3 + §A32 + §A33; (d) é conhecimento estável de literatura — RE-VERIFICAR na F1 se citar paper específico de panel-of-judges.


---

## AUDITORIA ANTIALUCINAÇÃO — NÍVEIS DE VERIFICAÇÃO (a defesa contra o leitor mais difícil)
**O risco real deste livro não é citar fonte falsa — é citar fonte VERDADEIRA com claim deformado ou número de memória.** A partir da v2.2, toda ficha tem um nível, e o nível decide o que pode ser impresso:

**NÍVEL 1 — fonte primária ABERTA em sessão, claims/números fixados na ficha.** Pode imprimir: definição verbatim da ficha, números da ficha, aspas curtas traduzidas com par original arquivado na F1.
**NÍVEL 2 — existência e TESE confirmadas em sessão (título/abstract/secundária); números internos NÃO fixados.** Pode imprimir: a tese em paráfrase ("o campo mediu que...", "há trabalho mostrando que..."), a referência nas Notas. NÃO pode imprimir: número, percentual, aspas, detalhe de arquitetura.
**NÍVEL 3 — conhecimento de treinamento (literatura clássica estável), NADA aberto em sessão.** Pode imprimir: o fato histórico em uma frase prudente. NÃO pode imprimir: número, ano exato sem F1, citação textual, título de obra entre aspas sem F1.
**COMPOSIÇÃO — tese do próprio livro montada sobre fichas.** Imprime como tese do livro, nunca como achado externo.

| Nível | Fichas | Observação de risco |
|---|---|---|
| **N1** | §A1 · §A3 · §A4 · §A10 · §A11 · §A14 · §A15 · §A24 · §A25 · §A26 · §A30 · §A32 · §A33 | são a espinha citável do livro; nenhum capítulo deve depender de número fora deste grupo antes da F1 |
| **N2** | §A2 · §A5 · §A6 · §A7 · §A8 · §A9 · §A16 · §A27 · §A28b/c · §A29(exceto o claim já fixado) · §A31 · §A36 | **§A8 é o risco nº 1 do livro** (âncora do Cap 6 verificada só por título); ver contingência abaixo |
| **N3** | §A13 · §A17 · §A19 · §A20 · §A21 · §A22 · §A23 | clássicos estáveis, mas o % do MT-Bench (§A21), o ano da "Kathy" (§A13) e anos de Eckert/Schatzmann (§A20) NÃO imprimem antes da F1 |
| **COMP** | §A18 · §A34 · §A35 | sempre assinadas como análise do livro |

### NÚMEROS LIBERADOS PARA IMPRESSÃO HOJE (lista fechada — fora dela, número nenhum)
90,2% · ~80% da variância por tokens · ~15x tokens (§A14) · <50% das tarefas · pass^8 <25% em retail (§A4) · 35.000+ testes/dia · resolução até ~90% · CSAT 4.5+ (§A25) · >80% coverage no test set (§A1) · escala 1-5 com threshold (§A3). Todo número novo: ou entra numa ficha N1 na F1, ou nasce do corpus próprio com log arquivado.

### NÚMEROS E DETALHES BLOQUEADOS ATÉ A F1 (imprimir = alucinação em potencial)
Qualquer número interno de §A5/§A6/§A27/§A28; o % de concordância do MT-Bench (§A21); a arquitetura interna e nomes de componentes de §A8; anos exatos de Cooper/Kathy (§A13) e Eckert/Schatzmann (§A20); datas além das já fixadas em §A15/§A16; versão vigente da Model Spec (§A17); qualquer citação textual de N3.

### AUDITORIA DE IDs arXiv (obrigatória na F1, com clique)
Todos os IDs de 2026 (2601.15290 · 2601.17087 · 2602.03545 · 2603.11245 · 2604.12615 · 2604.21480 · 2605.02624 · 2605.20204 · 2606.11079) vieram de resultados de busca, não de digitação — ainda assim, a F1 abre CADA um e confirma título+autores+claim, porque ID trocado é o erro que o leitor difícil pesca primeiro. Regra de impressão: nas Notas, ID arXiv só aparece se clicado na F1; até lá, autor+título+ano bastam.

### CONTINGÊNCIA DO RISCO Nº 1 (§A8, âncora do Cap 6)
Se a F1 não confirmar a arquitetura exata de "Agentic Persona Control and Task State Tracking": o Cap 6 re-ancora em §A24c (critério dos dois especialistas, N1) + §A33 (flywheel de graders, N1) + a decomposição ator/rastreador apresentada como tese do livro (§A18, COMP) — o capítulo sobrevive sem perder autoridade, porque as duas fichas substitutas são primárias.

**§A36 — Validade do simulador de usuário (a referência que faltava para o leitor mais difícil).** *Synthetic Users, Real Differences: an Evaluation Framework for User Simulation in Multi-Turn Conversations* (arXiv:2605.02624, 2026): distingue **validade concorrente** (o benchmark com simulador chega às mesmas conclusões que diálogos reais) de **validade de conteúdo** (os diálogos simulados PARECEM interações reais) — e aponta que o campo quase só mede a primeira; cita ChatBench (Chang et al., 2025) como exemplo de validação limitada ao primeiro turno. USO: 1 parágrafo em "O que o método não entrega" — o livro declara qual validade o Simulador persegue (concorrente: decidir o deploy como decidiria com gente) e por que a regra de ouro (grounding na conversa real) ataca a de conteúdo. Status: **N2** (abstract/related work lidos em sessão); RE-VERIFICAR framework exato e a referência ChatBench na F1.


---

## FICHAS DE PLATAFORMA E ESCOPO (12/07/2026)

**§A37 — O ecossistema de plataformas de eval + observabilidade (contexto de mercado; citar como categoria, sem endosso).** Fontes secundárias comparativas lidas em sessão (Confident AI, Latitude, MLflow, Aiprosol — índices 2026).
FATOS CITÁVEIS COMO CATEGORIA: em 2026 há uma pilha madura de ferramentas que fazem tracing + LLM-as-judge + datasets + alertas de qualidade sobre tráfego de produção — **LangSmith** (nativo LangChain/LangGraph), **Arize/Phoenix** (OTel-native, open-source, 50+ métricas, drift detection), **Braintrust** (playground de eval + CI/CD, tier grátis generoso), **Confident AI/DeepEval** (eval-first, simulação multi-turn), **Langfuse** (open-source self-hosted), **W&B Weave**, além das nativas de nuvem — **Vertex Gen AI Evaluation Service** (§A32b), **Azure AI Foundry** (§A3), **AWS Bedrock** (guardrails/avaliação). DEFINIÇÃO-CHAVE que separa este livro delas: a maioria é **observabilidade (olha o que o agente JÁ fez em produção, via trace)**; o Simulador é **pré-produção proativa (gera o usuário que ainda não reclamou)**. As duas são camadas complementares do Queijo Suíço (§A24d), não concorrentes.
USO NO LIVRO: substitui e amplia o parágrafo de mercado §A31 no Cap 7 — o leitor sai com o método portável E com o mapa para escolher/auditar plataforma; regra: nomear a categoria e 2-3 exemplos, **nunca ranquear nem citar número de fornecedor** (os comparativos são SEO enviesado — N2 no máximo, e só como "existe a categoria").
Status: **N2** (fontes secundárias, categoria confirmada por múltiplas independentes); nomes de produto são N1 factual (existem), mas capacidades específicas NÃO imprimem número.

**§A38 — Framework de métricas por tipo de agente (o material de governança do Rafael — ponte para o Livro 3).** Documento do próprio Rafael: taxonomia (Informacional · Transacional · Multi-agente · Transversal) com thresholds (Groundedness ≥95%, Schema Compliance ≥99%, Task Completion ≥95%, Trajectory Correctness ≥90%, Loop Rate ≤2%, Guardrail Pass ≥99%) e catálogo de métricas (RAG, SQL/API, classificação, extração, orquestração, guardrails, FinOps, observabilidade). Fontes normativas citadas no doc: Google Cloud (tipos de agente), Confident AI/DeepEval, arXiv:2305.10468 (AI Agents vs. Agentic AI), RAGAS/Weaviate, NIST AI RMF + ISO/IEC 42001.
LEITURA CANÔNICA — FRONTEIRA DE ESCOPO (a decisão editorial mais importante desta ficha): este framework é **majoritariamente Livro 3 (Agent Evaluation — a Pirâmide)**. O Livro 2 (Personas Sintéticas) usa dele APENAS o que cabe no seu produto:
- **ENTRA no Livro 2:** a ideia de que **o tipo de agente decide a métrica** (a persona do leitor precisa saber se o agente dele é informacional/transacional/multi-agente para escolher o que o Juiz mede) — vira 1 parágrafo no Cap 5, creditado como "framework de governança que times maduros usam"; e a confirmação de que **LLM-as-judge + ground truth congelado** é padrão de indústria (linhas SQL-02/03, SUM-01, CRT-01 do doc) — reforça o Cap 5.
- **NÃO ENTRA (é Livro 3):** trajectory correctness, tool selection accuracy, loop rate, schema compliance, RAG context precision/recall, guardrails/red-teaming, SLOs de produção, o plano de monitoramento de 10 pontos, auditoria/logging. Esses são a Pirâmide do Livro 3 — o Cap 7 os NOMEIA em uma frase de ponte ("medir trajetória, tool use e guardrails é o próximo livro desta linha") e para aí.
- **A Resolutividade dialoga com o doc:** o framework tem NEG-01 (Valor: NPS/TMA) e RAG-08 (NPS/feedback) como métricas transversais — a Resolutividade do livro é a versão conversacional e preditiva disso ("voltaria amanhã?"), medida turno a turno pelo Juiz em vez de survey pós-hoc. Dizer isso conecta o livro ao vocabulário de governança que o leitor corporativo já conhece.
Status: **N1 factual** (documento primário do autor em mãos); os thresholds são do framework do Rafael (apresentar como "padrões que times de governança adotam", não como lei universal). As fontes normativas (NIST, ISO, arXiv:2305.10468, RAGAS) entram nas Notas se citadas — RE-VERIFICAR arXiv:2305.10468 na F1 (id de treinamento).

### REGRA DE FRONTEIRA LIVRO 2 × LIVRO 3 (nova — vale para toda decisão de escopo)
O Livro 2 constrói o **Simulador**: gerar o usuário sintético + julgar a conversa com 3 métricas + gate. Tudo que é **medir a mecânica interna do agente** (trajetória, tool calls, schema, RAG retrieval, guardrails, SLOs, observabilidade de produção) é o **Livro 3 (a Pirâmide)**. Quando uma ficha ou pedido tocar a fronteira, o default é: 1 frase de ponte no Cap 7, zero seção. Isto protege os 7 capítulos e vende o próximo livro — não é omissão, é arquitetura de coleção.

---

## IMPACTO DAS NOVAS FICHAS NO SUBTÍTULO (gate AB da capa)
Subtítulo novo: **"Encontre as falhas antes dos seus usuários — e entregue sistemas de IA que escalam."**
- "Encontre as falhas antes dos seus usuários" — coberto por §A24(b), §A25, §A30, §A4.
- "sistemas de IA que escalam" — coberto por §A25 (35.000 testes/dia como rotina de escala), §A14 (orchestrator-worker), §A2 (personas em escala 100k–1B). O gate escala porque é automatizável e roda em CI — a promessa é do MÉTODO que escala junto com o sistema, não mágica. Frase-guarda para o Cap 7: *o que escala não é o agente sozinho; é o par agente+gate*.
- AB ≥ 9 confirmado: nenhuma palavra da capa depende de ficha reprovada.

## FICHAS REPROVADAS — inalteradas (Toast Inc., framework NeurIPS 2025, lei de potência ~300 palavras, "2 dias para 8 minutos": continuam banidas).

## PENDÊNCIAS DE PESQUISA (F1 — recalculadas)
RESOLVIDAS pela v2: a antiga nº 2 (caso de indústria com fonte primária → §A24, §A25); parcialmente a nº 1 (§A4 já verificado em fonte primária na v1; §A6 ganhou reforço via §A28b).
1. Abrir §A5, §A8, §A9 nas fontes primárias e fixar claims/números exatos (mantida).
2. §A27: números internos do paper de diversity-guided simulation.
3. §A28(b)(c): conclusões exatas de Lost in Simulation e RealUser-Sim.
4. §A24: colar no arsenal os trechos exatos em inglês (par original+tradução) do post da Anthropic.
5. §A25/§A26: idem para os dois posts da Sierra (35.000/dia; parâmetros de paciência/interrupção do τ³).
6. §A32: nomes exatos de behaviors/personas do ADK na versão vigente; URL do blog e dos docs.
7. §A33: nomenclatura vigente do AgentKit Evals (datasets/graders/trace grading) e URLs.
8. §A35(d): decidir se painel-de-juízes cita paper específico; se sim, verificar fonte primária.
9. §A37: confirmar que nenhuma capacidade específica de plataforma será impressa com número (só categoria).
10. §A38: RE-VERIFICAR arXiv:2305.10468 e as fontes normativas (NIST AI RMF, ISO/IEC 42001, RAGAS) se citadas nas Notas.
11–15. Mantidas da v1: Cooper/Jansen (§A13) · Reuters/Meta (§A16) · Model Spec vigente (§A17) · A2A spec (§A19) · Eckert/Schatzmann (§A20) · % MT-Bench (§A21) · citações CAI/siconfância (§A22/23).
**Protocolo F1 (endurecido pela v2.2):** fonte primária aberta COM CLIQUE no ID, trecho exato em inglês + tradução arquivados, DOI/arXiv + data de acesso, e promoção explícita de nível (N2/N3 → N1) registrada na ficha. A F4 só começa quando toda ficha usada pelo Cap 1 for N1.
