# BANCO DE CAMPO — a única fonte autorizada de primeira pessoa
Cinco a oito observações verdadeiras, ditadas pelo Rafael. Fora daqui, o narrador não diz "eu".
Cada entrada: o que aconteceu, onde, o detalhe operacional que ninguém inventaria, e em qual capítulo pode ser usada.

## BC-1
- **O quê:** `[PREENCHER]`
- **Detalhe que ninguém inventaria:** `[PREENCHER]`
- **Capítulo autorizado:** `[PREENCHER]`
- **Anonimização:** `[o que foi trocado]`
