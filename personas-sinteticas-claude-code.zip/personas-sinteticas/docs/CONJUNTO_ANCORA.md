# CONJUNTO-ÂNCORA E OS QUATRO CANAIS
Congelado na F0.5. O Claude Code lê e não altera. É contra esta lista que o parecer editorial vai medir recall e FRC de cada canal.

## 1. As proposições (8 a 15)
Cada uma cabe em uma linha e é específica o bastante para não valer para outro livro do nicho.

| # | Proposição | Capítulo dono | Canais que a carregam |
|---|---|---|---|
| 1 | `[PREENCHER]` | | |

## 2. As 14 mensagens-âncora (2 por capítulo)
Frases exatas, para o Claude Code copiar — não inventar.

| Cap | Âncora 1 | Âncora 2 |
|---|---|---|
| 1 | `[PREENCHER]` | `[PREENCHER]` |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |

**Teste:** lidas em sequência, as 14 formam um resumo útil do método.

## 3. As 8 legendas afirmativas
Legenda afirma, nunca descreve. "Volume não é cobertura", não "As cinco personas".

| Figura | Legenda | Alt-text (≤140) |
|---|---|---|
| Fig 1 | `[PREENCHER]` | |

## 4. Prefixo de 10%
O Simulador nomeado antes de 60% da amostra. Ordem: capa · rosto · epígrafe · Prefácio · Sumário · Antes de começar · O que você vai construir · Introdução.
